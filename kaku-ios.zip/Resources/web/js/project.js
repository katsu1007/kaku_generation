/* 案件の画面：① 現場 → ② 部屋 → ③ 工事 → ④ 確認 → ⑤ 書類 */
import { state, registerView, setTop, go, touch, opts, findProject, masterItems, categories, removeProject, restoreProject, newProject, flush, trackUndo, paintUndo, stepUndo, rebaseUndo, resetUndo } from './app.js';
import { lineSource, SOURCE_LABEL, roomGeom, lineQty, netQty, totals, check, MEASURES, KINDS, isRoomBased, hatsuCalc, hatsuItem, cutItem, ZANDO_F, wallGroup, lineBasis, okState, okMark, hasCode, missingWaste, isDemoArea, wasteRows } from './calc.js';
import { workChecks } from './workcheck.js';
import { makerLinks } from './makers.js';
import { analyzeAll as analyzeFrame, VER as R2VER } from './reader2/index.js';
import { groupRoles, ROLE } from './reader2/lines.js';
import { modelFor, normalizeText } from './reader2/text.js';
import { SYS, MANY, sysOptions, rebuild, PIPE_LOSS } from './piping.js';
import { mergeSplitFaces, splitMerged, absorbBoxes } from './facemerge.js';
/* 読み込んだ図面のファイル（開いている間だけ）。「線を外す」で区画を作り直す時に、もう一度選ばなくてよいように */
const cadFiles = new Map();
import { importDrawing, groupGeom, roomHoles, planCH, orderFaces as orderFacesOf } from './drawing.js';
import { sheetsOf, fixturesInUse, fixturesInRegions } from './sheets.js';
export { sheetsOf, fixturesInUse };
import { readWithFixtures, oldFaceLights, roomOpenRuns, FIX_NAMES, FIX_ITEMS, FIX_WORDS } from './legacy.js';
import { planView, roomColor } from './planview.js';
import { classifyFixtureDisplay, classifyCluster, buildChairContexts, bareClusterFlags, nonObjectFlags, titleRegionFlags, slimSymFeat, SYM_VERDICTS, SYM_DICT } from './symdict.js';
import { detectFurniture } from './furndetect.js';
import { rescueFixtures, mergeFixtures } from './fixrescue.js';
import { applyEdgeFix, revertEdgeFix } from './facerepair.js';
import { createShapeIndex } from './fixshape.js';
import { judgeRooms, ROOM_JUDGE } from './roomjudge.js';
import { computeZones, splitFacesByLine, detectTableAreas } from './zones.js';
import { supplementFaces, polygonizeFaces } from './polygonize.js';
import { extractDxfDims, checkDimensions, dimCheckFor } from './dxf-dims.js';
import { estimateSymScale, symScaleFor, scaleCheck, scaleTargetFor, userCoef, scaleGeomBy } from './symscale.js';
import { correctFixtureTypes } from './typefix.js';
import { USES, DEF_LM, needCount, pitchFor, luxOf, wirePlan, cableQty, pip, polyD } from './lighting.js';
/* iPhone・iPad では、選べるファイルの種類を絞ると .jww・.jwc・.dxf が灰色になって選べない（iPhone がこの拡張子を知らないため）。
   なので iPhone・iPad では絞らない。何を選んでも、読み込む時に拡張子で見分けるので困らない */
const IOS = typeof navigator !== 'undefined' && (/iP(hone|ad|od)/.test(navigator.userAgent || '') || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1));
const DWG_ACCEPT = IOS ? '' : '.jww,.jwc,.dxf,.pdf,application/pdf,image/*';
import { uid } from './store.js';
import { openElec, elecLines } from './elec.js';
import { groupsOf, LABOR, COLORS, areaPts, linePts, placePts, placeCounts, symText } from './place.js';
import { open3D, applyWin3d } from './view3d.js';
import { openRoomFin, currentFin, SLOTS } from './roomfin.js';
import { openSketch } from './sketchui.js';
import { toPlan as sketchPlan, geomOf } from './sketch.js';
import { jww as jwwBytes, dxf as dxfBytes } from './cad.js';
import { icon, esc, yen, fmt, pct, toast, modal, ask, matchItem, showError, share, $, $$ } from './ui.js';
import { STATUS } from './home.js';
import { docsStep } from './docs.js';
/* むぎの sw.53 の数量の出どころ（js/provenance.js）は、こちらで先に入れた calc.js の lineSource・srcPill と重なるので画面には出していない（2026-11-23） */

const STEPS = [
  { n: 1, t: '現場', s: 'お客様と現場', lead: 'お客様の名前と現場の住所を入れてください。見積書にそのまま載ります。' },
  { n: 2, t: '部屋', s: '寸法を入れる', lead: '図面がある時は「図面を選ぶ」で読み込んで、区画をタップして部屋にしてください。図面が無い時は「部屋を足す」で幅と奥行（m）を入れてください。床・壁・天井の面積が自動で出ます。' },
  { n: 3, t: '工事', s: '品目を選ぶ', lead: '「一覧から選ぶ」で工事の品目を選んでください。床・壁・天井の品目は、部屋の寸法から数量が自動で入ります（材料はロス込み）。' },
  { n: 4, t: '確認', s: '検算と金額', lead: '計算をもう一度別の方法で確かめ、間違いやすい所を出します。赤い所を直してから書類を作ってください。' },
  { n: 5, t: '書類', s: '見積書を出す', lead: '見積書・請求書・内訳書を作ります。見積書を出すたびに「第○版」として記録が残り、前の版と比べられます。' }
];
const lastFocus = {};

function stepDone(p, n) {
  const o = opts();
  if (n === 1) return !!(p.name && p.customer);
  if (n === 2) return p.rooms.length > 0 && p.rooms.every(r => roomGeom(r, o).floor > 0);
  if (n === 3) return p.lines.length > 0;
  if (n === 4) return p.lines.length > 0 && !check(p, o).some(c => c.level === 'error');
  if (n === 5) return (p.history || []).length > 0;
  return false;
}

registerView('project', async (el, route) => {
  const p = findProject(route.id);
  if (!p) { el.innerHTML = `<div class="empty"><b>案件が見つかりません</b><a class="btn" href="#/projects">案件の一覧へ</a></div>`; setTop('案件'); return; }
  p.rooms = p.rooms || []; p.lines = p.lines || []; p.history = p.history || [];
  const step = Math.min(5, Math.max(1, route.step));
  trackUndo(p);
  setTop(p.name || '名前のない案件', `<button class="iconbtn" id="undoBtn" title="1つ前に戻す" aria-label="1つ前に戻す" disabled>${icon('undo')}</button><button class="iconbtn" id="redoBtn" title="やり直す" aria-label="やり直す" disabled>${icon('redo')}</button><button class="iconbtn" id="dupBtn" title="この案件を複製" aria-label="この案件を複製">${icon('copy')}</button>`);
  $('#dupBtn').onclick = () => duplicate(p);
  $('#undoBtn').onclick = () => stepUndo(p, true);
  $('#redoBtn').onclick = () => stepUndo(p, false);
  paintUndo();

  el.innerHTML = `
    <div class="phead">
      <button class="iconbtn" onclick="location.hash='#/projects'" aria-label="案件の一覧へ">${icon('back')}</button>
      <div class="t"><h2 data-out="pname">${esc(p.name || '名前のない案件')}</h2><div class="meta" data-out="pmeta"></div></div>
      <div class="grand"><div class="k">合計（税込）</div><div class="v money" data-out="grand"></div><div class="small muted" data-out="gross"></div></div>
    </div>
    <nav class="steps" id="steps"></nav>
    <div class="lead">${icon('info')}<span>${STEPS[step - 1].lead}</span></div>
    <div id="stepBody"></div>
    <div class="nextbar" id="nextbar"></div>`;

  const body = $('#stepBody');
  const ctx = { p, step, body, refresh: () => refresh(p, step) };
  if (step === 1) stepInfo(ctx);
  if (step === 2) stepRooms(ctx);
  if (step === 3) stepLines(ctx);
  if (step === 4) stepCheck(ctx);
  if (step === 5) docsStep(ctx);

  const nb = $('#nextbar');
  const prev = step > 1 ? `<a class="btn" href="#/p/${encodeURIComponent(p.id)}/${step - 1}">${icon('back')}戻る</a>` : '';
  const next = step < 5 ? `<a class="btn primary big" href="#/p/${encodeURIComponent(p.id)}/${step + 1}">次へ：${STEPS[step].t}${icon('next')}</a>` : '';
  nb.innerHTML = `${prev}<span class="spacer"></span>${next}`;
  refresh(p, step);
  if (lastFocus.id) {
    const t = document.querySelector(`[data-line="${lastFocus.id}"],[data-room="${lastFocus.id}"]`);
    if (t) { t.scrollIntoView({ block: 'center' }); t.style.boxShadow = '0 0 0 3px var(--accent)'; setTimeout(() => { t.style.boxShadow = ''; }, 2200); }
    lastFocus.id = null;
  }
});

function refresh(p, step) {
  const o = opts();
  const t = totals(p, o);
  const set = (k, v) => $$(`[data-out="${k}"]`).forEach(e => { e.innerHTML = v; });
  set('pname', esc(p.name || '名前のない案件'));
  const [lab, cls] = STATUS[p.status] || STATUS.draft;
  set('pmeta', `<span class="pill ${cls}">${lab}</span> ${esc(p.customer || 'お客様 未入力')}${p.address ? '・' + esc(p.address) : ''}${p.number ? '・No.' + esc(p.number) : ''}`);
  set('grand', yen(t.grand));
  set('gross', t.net > 0 ? `粗利 ${yen(t.gross)}（${pct(t.grossPct)}）` : '');
  const errs = check(p, o).filter(c => c.level === 'error').length;
  $('#steps').innerHTML = STEPS.map(s => {
    const done = stepDone(p, s.n);
    const err = s.n === 4 && p.lines.length && errs;
    return `<a class="step ${s.n === step ? 'on' : ''} ${done ? 'done' : ''} ${err ? 'err' : ''}" href="#/p/${encodeURIComponent(p.id)}/${s.n}">
      <span class="n">${done ? icon('check') : err ? '!' : s.n}</span><span><b>${s.t}</b><small>${err ? `要確認 ${errs}` : s.s}</small></span></a>`;
  }).join('');
  $$('.step .n svg').forEach(s => { s.style.width = '16px'; s.style.height = '16px'; });
  /* 部屋のチップ */
  p.rooms.forEach(r => {
    const g = roomGeom(r, o);
    set('room:' + r.id, (g.openAuto ? `<span class="chip" style="border-color:var(--info)">図面のドア ${g.openAuto.doors}・開口 ${g.openAuto.gaps} <b>−${fmt(g.openAuto.area)}</b>㎡</span>` : '') + `<span class="chip">床 <b>${fmt(g.floor)}</b>㎡</span><span class="chip">壁 <b>${fmt(g.wall)}</b>㎡</span><span class="chip">天井 <b>${fmt(g.ceil)}</b>㎡</span><span class="chip">周り <b>${fmt(g.perim)}</b>m</span><span class="chip">巾木 <b>${fmt(g.base)}</b>m</span>${Number(r.h) > 0 ? `<span class="chip">天井高 <b>${fmt(g.h)}</b>m</span>` : `<span class="chip" style="border-color:var(--warn);color:var(--warn)" title="天井高を入れていないので、標準の高さで壁の面積を計算しています">天井高 <b>${fmt(g.h)}</b>m（標準のまま・未入力）</span>`}`);
  });
  /* 明細の金額 */
  let mItems = null;
  p.lines.forEach((l, i) => {
    const q = t.lines[i].qty;
    set('amt:' + l.id, `<b>${yen(t.lines[i].amount)}</b><small>${fmt(q, 3)} ${esc(l.unit || '')} × ${yen(l.price)}</small>`);
    if (hasCode(l)) set('mk:' + l.id, makerLinks(l, l.itemId ? (mItems || (mItems = new Map(masterItems().map(x => [x.id, x])))).get(l.itemId) : null).map(x => `<a class="btn sm" target="_blank" rel="noopener" href="${esc(x.url)}">${icon('up')}${esc(x.label)}</a>`).join(''));
    const ok = okState(l, p.rooms, o, p.lines);
    set('ok:' + l.id, ok === 'ok' ? `<span class="pill ok">${icon('check')}確認済み</span>` : ok === 'changed' ? `<span class="pill warn">${icon('alert')}確認の後で変わりました</span>` : '');
    if (l.basis && l.basis.measure === 'waste') {
      const R = wasteRows(l, p.rooms, o, p.lines);
      set('qinfo:' + l.id, R.length ? '解体の量から：' + R.slice(0, 3).map(x => `${esc(x.name)} ${fmt(x.area, 2)}㎡×${fmt(x.t, 3)}m`).join(' ＋ ') + (R.length > 3 ? ` ほか${R.length - 3}行` : '') + ` → ${fmt(q, 2)}m³` : 'もとになる解体の行がありません（解体を入れると数量が入ります）');
      set('qty:' + l.id, fmt(q, 3));
      return;
    }
    if (l.basis && l.basis.measure === 'link') {
      const par = p.lines.find(x => x.id === l.basis.line);
      set('qinfo:' + l.id, par ? `${esc(l.why || '')}：${esc(par.name)} ${esc(par.spec || '')} の長さ ${fmt(netQty(par, p.rooms, o, p.lines), 3)}m → ${fmt(q, 3)}${esc(l.unit || '')}` : '元の配管の行がありません');
      set('qty:' + l.id, fmt(q, 3));
      return;
    }
    if (l.applyLoss && !isRoomBased(l)) {
      const loss = l.loss === '' || l.loss == null ? o.loss : Number(l.loss);
      set('qinfo:' + l.id, l.fromDemo ? `図面で入れた ${fmt(l.qty, 3)}${esc(l.unit || '')} ＋ ロス${fmt(loss, 1)}%${l.sheet > 0 ? `（${fmt(l.sheet, 3)}㎡/枚で枚数に切り上げ ${Math.round(q / l.sheet)}枚）` : ''} → ${fmt(q, 3)}`
        : Number(l.qty) > 0 ? `長さ ${fmt(l.qty, 3)}m ＋ ロス${fmt(loss, 1)}% → ${fmt(q, 3)}m` : '長さ（m）を入れてください');
    }
    const auto = isRoomBased(l);
    if (auto) {
      const net = netQty(l, p.rooms, o, p.lines);
      const loss = l.loss === '' || l.loss == null ? o.loss : Number(l.loss);
      const info = !p.rooms.length ? '部屋がまだありません。②部屋で寸法を入れると数量が入ります。'
        : l.kind === 'labor' ? `${MEASURES[l.basis.measure].label}：${fmt(net, 3)}${MEASURES[l.basis.measure].unit}（手間なので正味のまま）`
          : `${MEASURES[l.basis.measure].label} 正味 ${fmt(net, 3)}${MEASURES[l.basis.measure].unit} ＋ ロス${fmt(loss, 1)}%${l.sheet > 0 ? `（${fmt(l.sheet, 3)}㎡/枚で枚数に切り上げ ${Math.round(q / l.sheet)}枚）` : ''} → ${fmt(q, 3)}`;
      const g = l.basis.measure === 'wall' ? wallGroup(l.cat) : null, ids = l.basis.rooms === 'all' || !Array.isArray(l.basis.rooms) ? null : new Set(l.basis.rooms);
      const off = g ? p.rooms.filter(r => (!ids || ids.has(r.id)) && r.wallOff && r.wallOff[g] > 0).reduce((t, r) => t + r.wallOff[g], 0) : 0;
      set('qinfo:' + l.id, info + (off > 0 ? `（図面で壁ごとに入れた ${fmt(off, 3)}㎡ を引いています）` : ''));
      set('qty:' + l.id, fmt(q, 3));
    }
  });
  set('subtotal', yen(t.subtotal));
  set('linecount', String(p.lines.length));
}

/* ---------- ① 現場 ---------- */
function stepInfo({ p, body, refresh }) {
  const f = (k, label, ph = '', hint = '', type = 'text') => `<label class="f">${label}${hint ? `<span class="hint">${hint}</span>` : ''}<input class="in" data-k="${k}" type="${type}" value="${esc(p[k] ?? '')}" placeholder="${esc(ph)}"></label>`;
  body.innerHTML = `
    <div class="card"><div class="grid g2">
      ${f('name', '案件名（工事の名前）', '例：○○ビル 3階 事務所改修')}
      ${f('customer', 'お客様の名前', '例：株式会社○○', '見積書には「様」が付きます')}
      ${f('address', '現場の住所', '例：瀬戸市○○町1-2-3')}
      ${f('person', 'お客様の担当者', '例：○○ 様')}
      ${f('tel', 'お客様の電話', '', '', 'tel')}
      <label class="f">状態<select class="in" data-k="status">${Object.entries(STATUS).map(([k, [l]]) => `<option value="${k}" ${(p.status || 'draft') === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    </div>
    <details class="more" style="margin-top:12px"><summary>見積書の番号・有効期限・備考</summary>
      <div class="grid g2" style="margin-top:12px">
        ${f('number', '見積番号')}
        ${f('expiry', '有効期限', '発行日より30日')}
        <label class="f" style="grid-column:1/-1">備考（見積書に載ります）<textarea class="in" data-k="note" placeholder="例：駐車場代は別途とさせていただきます。">${esc(p.note || '')}</textarea></label>
        <label class="f" style="grid-column:1/-1">社内メモ（見積書には載りません）<textarea class="in" data-k="memo">${esc(p.memo || '')}</textarea></label>
      </div>
    </details></div>
    <div class="row" style="margin-top:14px"><span class="spacer"></span><button class="btn ghost danger" id="delP">${icon('trash')}この案件を消す</button></div>`;
  body.addEventListener('input', e => {
    const k = e.target.dataset.k; if (!k) return;
    p[k] = e.target.value; touch(p); refresh();
    if (k === 'name') { const h = document.querySelector('.top h1'); if (h) h.textContent = p.name || '名前のない案件'; }
  });
  body.addEventListener('change', e => { if (e.target.dataset.k === 'status') { p.status = e.target.value; touch(p); refresh(); } });
  $('#delP').onclick = async () => {
    if (!(await ask('案件を消しますか？', `「${p.name || '名前のない案件'}」を消します。`, { ok: '消す', danger: true }))) return;
    const copy = JSON.parse(JSON.stringify(p));
    await removeProject(p);
    go('#/projects');
    toast('案件を消しました', { action: '元に戻す', onAction: async () => { await restoreProject(copy); go('#/p/' + encodeURIComponent(copy.id) + '/1'); } });
  };
  if (!p.name) setTimeout(() => { const i = body.querySelector('[data-k="name"]'); if (i && matchMedia('(min-width:900px)').matches) i.focus(); }, 50);
}

/* ---------- ② 部屋 ---------- */
/* 部屋のカードに、決めてある仕上げを出す（③工事の行から） */
function finChips(p, r) {
  const f = currentFin(p, r.id), M = masterItems(), nm = id => (M.find(i => i.id === id) || {}).name || '';
  const list = SLOTS.filter(s => f[s.k]).map(s => `<span class="chip">${s.part}${s.role ? s.role === '仕上げ' ? '' : s.role : ''} <b>${esc(nm(f[s.k]))}</b></span>`);
  return `<div class="chips" style="margin-bottom:8px">${list.length ? list.join('') : `<span class="small muted">仕上げはまだです。「仕上げ」で床・壁・天井・巾木を選べます。</span>`}</div>`;
}
function roomCard(r, i, p) {
  const free = r.shape === 'free';
  const num = (k, label, unit, hint = '', step = '0.01') => `<label class="f">${label}${hint ? `<span class="hint">${hint}</span>` : ''}<div class="unitwrap"><input class="in num" inputmode="decimal" type="number" step="${step}" min="0" data-rk="${k}" value="${esc(r[k] ?? '')}"><span>${unit}</span></div></label>`;
  return `<div class="roomc" data-room="${r.id}">
    <div class="head"><span class="pill" ${r.src === 'plan' ? `style="background:${roomColor(r.color)};color:#111"` : ''}>${i + 1}</span>${r.src === 'plan' ? `<span class="pill info" title="図面の区画 ${(r.faces || []).length} つから作った部屋">図面</span>` : ''}<input class="in" data-rk="name" value="${esc(r.name)}" aria-label="部屋の名前" style="flex:1">
      <button class="btn sm" data-act="roomFin">仕上げ</button>
      <button class="iconbtn" data-act="dupRoom" title="同じ部屋をもう1つ">${icon('copy')}</button>
      <button class="iconbtn" data-act="delRoom" title="この部屋を消す">${icon('trash')}</button></div>
    ${finChips(p, r)}
    ${r.src === 'plan' && r.holes && r.holes.area > 0 ? `<div class="row small" style="margin-bottom:8px;gap:8px;flex-wrap:wrap;align-items:center"><span class="${r.noHoles ? 'muted' : ''}">机・棚などで囲まれた所 ${r.holes.area}㎡ を床に${r.noHoles ? '足していません' : '足しています（図面では部屋の色で塗っています）'}</span><button class="btn sm" data-act="holeToggle" style="min-height:36px">${r.noHoles ? '床に足す' : '足さない'}</button></div>` : ''}
    ${r.src === 'plan' && r.out ? `<div class="small" style="margin-bottom:8px;color:var(--warn)">工事対象外の範囲：床・天井から ${r.out.area}㎡、壁・巾木から 長さ ${r.out.perim}m を引いています（図面の「線を外す・対象外」で直せます）</div>` : ''}
    <div class="row" style="margin-bottom:10px"><span class="small muted">形</span><div class="seg"><button data-shape="rect" class="${free ? '' : 'on'}">四角（幅×奥行）</button><button data-shape="free" class="${free ? 'on' : ''}">面積で入れる（L字など）</button></div></div>
    <div class="rfields">
      ${free ? num('area', '床の面積', '㎡') + num('perim', '周りの長さ', 'm') : num('w', '幅', 'm', '例 3.64') + num('d', '奥行', 'm')}
      ${num('h', '天井高', 'm', `空なら ${opts().ceilH}m`)}
      ${num('qty', '同じ部屋の数', '室', '', '1')}
      ${num('doors', 'ドア', 'か所', '1か所 1.6㎡', '1')}
      ${num('winCount', '窓（数だけ）', 'か所', '1か所 1.6㎡', '1')}
    </div>
    ${free ? '' : `<div class="parts">${(r.parts || []).map((x, pi) => `<div class="partrow">
        <select class="in" data-pk="s" data-pi="${pi}" style="min-height:44px">${[['1', '＋ 足す（出っ張り）'], ['-1', '－ 引く（角を欠く・L字）'], ['-1w', '－ 引く（壁際の柱・へこみ）'], ['-1c', '－ 引く（部屋の中の柱）']].map(([v, l]) => `<option value="${v}" ${(x.s < 0 ? '-1' + (x.k === 'wall' ? 'w' : x.k === 'col' ? 'c' : '') : '1') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <label class="f">幅<div class="unitwrap"><input class="in num" type="number" inputmode="decimal" step="0.01" data-pk="w" data-pi="${pi}" value="${esc(x.w ?? '')}"><span>m</span></div></label>
        <label class="f">奥行<div class="unitwrap"><input class="in num" type="number" inputmode="decimal" step="0.01" data-pk="h" data-pi="${pi}" value="${esc(x.h ?? '')}"><span>m</span></div></label>
        <button class="iconbtn" data-act="delPart" data-pi="${pi}" aria-label="この寸法を消す">${icon('x')}</button></div>`).join('')}
      <button class="btn sm ghost" data-act="addPart">${icon('plus')}寸法を足す・引く（L字・出っ張り・柱など）</button></div>`}
    <details class="more" ${(r.windows || []).length ? 'open' : ''}><summary>窓を寸法で入れる（mm）</summary>
      <p class="small muted" style="margin:6px 0">寸法を入れた窓がある部屋は、その面積を壁から引きます。上の「窓（数だけ）」の数は使いません。</p>
      <div class="wins">${(r.windows || []).map((w, wi) => `<div class="winrow">
        <label class="f">幅<div class="unitwrap"><input class="in num" type="number" inputmode="numeric" data-wk="w" data-wi="${wi}" value="${esc(w.w)}"><span>mm</span></div></label>
        <label class="f">高さ<div class="unitwrap"><input class="in num" type="number" inputmode="numeric" data-wk="h" data-wi="${wi}" value="${esc(w.h)}"><span>mm</span></div></label>
        <label class="f">枚数<input class="in num" type="number" inputmode="numeric" data-wk="n" data-wi="${wi}" value="${esc(w.n)}"></label>
        <button class="iconbtn" data-act="delWin" data-wi="${wi}" aria-label="この窓を消す">${icon('x')}</button></div>`).join('')}
        <div><button class="btn sm" data-act="addWin">${icon('plus')}窓を足す</button></div></div>
    </details>
    ${(r.openRuns || []).length ? `<label class="row small muted" style="gap:8px;margin-top:10px"><input type="checkbox" data-open-toggle ${r.openOff ? '' : 'checked'} style="width:20px;height:20px">図面で見つけたドア・開口を壁の面積から引く（引く時は、上の「ドア」の数は使いません）</label>` : ''}
    <div class="chips" data-out="room:${r.id}"></div>
  </div>`;
}

/* 電気の図面を数える（JWW・DXF の電気図から器具の数と配線の長さ） */
function elecRow(p) {
  const E = p.elec;
  return `<div class="row small" style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line);gap:8px"><button class="btn sm" data-act="elec">${icon('spark')}電気の図面を数える</button>
    <span class="muted" style="flex:1;min-width:200px">${E && E.summary ? `${esc(E.file)} から ${esc(E.summary)} を入れています。` : '電気屋さんが書き込んだ JWW・DXF から、照明・コンセント・スイッチなどの数と配線の長さを出します。'}</span>
    ${E && E.summary ? '<button class="btn sm ghost danger" data-act="elecOff">入れた分を外す</button>' : ''}</div>`;
}
/* 図面を全画面で編集する（プレビューの右上のボタン）。描き直しても全画面のまま */
let dwgFs = false;
/* 図面の作業の状態（モード・照明の道具・拡大）。上の矢印（案件全体の元に戻す・やり直す）は画面を作り直すので、
 * 作り直した後も同じモード・同じ拡大のまま続けられるように、作り直す前の状態をここから読む（かつ「照明で戻す・進むを押すと全体に戻る」） */
let workNow = null;
function drawingCard(p) {
  const d = p.drawing;
  if (!d || !d.plan) return `<div class="card" style="margin-bottom:14px"><div class="row"><div style="flex:1;min-width:220px"><h2>図面から部屋を作る</h2>
      <div class="sub" style="margin:0">JWW・DXF・PDF の図面を読み込むと、部屋の区画が自動で見つかります。区画をタップして部屋にしてください。写真やスキャンしたPDFは、下に敷いて角をなぞって拾えます。</div></div>
      <label class="btn primary" style="cursor:pointer">${icon('up')}図面を選ぶ<input type="file" id="dwgFile" accept="${DWG_ACCEPT}" hidden></label>
      <button class="btn" data-act="sketch">${icon('grid')}寸法・なぞって間取りを作る</button></div>
      <div class="small muted" style="margin-top:6px">図面ファイルが無い時は「寸法・なぞって間取りを作る」：四角の寸法・向きと長さ・PDFや写真の角をなぞって、間取りを作れます。</div>
      <div class="small muted" id="dwgStatus" style="margin-top:8px"></div>${elecRow(p)}</div>`;
  return `<div class="card" style="margin-bottom:14px">
    <div class="row" style="margin-bottom:10px"><div style="flex:1;min-width:200px"><h2>${icon('layers').replace('<svg', '<svg style="width:18px;height:18px;vertical-align:-3px"')} ${esc(d.fileName || '図面')}</h2>
      <div class="sub" style="margin:0">区画 ${d.plan.faces.length} 個${planCH(d.plan) ? `・図面の天井高 ${planCH(d.plan)}m` : ''}。区画をタップして選び、下のボタンで部屋にしてください。</div></div>
      ${d.fixtures ? `<button class="btn sm primary" data-act="open3d">${icon('cube')}3Dで見る</button>` : ''}
      ${d.sketch ? `<button class="btn sm" data-act="sketch">${icon('grid')}間取りを直す</button>` : ''}
      <button class="btn sm" data-act="cadOut">${icon('down')}JWW・DXF</button>
      <label class="btn sm" style="cursor:pointer">${icon('up')}読み直す<input type="file" id="dwgFile" accept="${DWG_ACCEPT}" hidden></label>
      <button class="btn sm ghost danger" data-act="dwgClear">${icon('trash')}図面を消す</button></div>
    <div id="dwgEdit" class="${dwgFs ? 'dwg-fs' : ''}"><div class="dwg-fs-head"><b class="small" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(p.name || '図面')}</b><button class="btn sm" data-act="dwgFs">${icon('shrink')}全画面をやめる</button></div>
    ${dwgFs ? '' : `<button class="btn fs-open" data-act="dwgFs">${icon('full')}図面を画面いっぱいにして編集する</button>`}
    <div class="seg" id="dwgMode" style="margin-bottom:8px">${dwgFs ? `<button class="fs-exit" data-act="dwgFs" title="全画面をやめる">${icon('shrink')}戻る</button>` : ''}<button data-mode="room">部屋を作る</button><button data-mode="fix">器具を直す</button><button data-mode="wall">壁の解体・仕上げ</button><button data-mode="cut">カッター</button><button data-mode="light">照明・配線</button><button data-mode="place">器具を置く</button><button data-mode="meas">測る</button><button data-mode="lineoff">線を外す・対象外</button></div>
    ${oldReadRow(d)}${sheetRow(d)}<div id="dwgView"></div>${sheetNotes(d)}${titleRow(p)}
    <div class="addbar" style="margin-top:10px" id="dwgBar"></div></div>
    <div id="dwgDemo"></div>
    <div id="dwgFix">${fixSummary(d)}</div><div id="dwgSym">${symSummary(d)}</div><div id="dwgRoom">${roomSummary(d)}</div><div id="dwgDim">${dimSummary(d)}</div>${elecRow(p)}
    <details class="more"><summary>区画の一覧から選ぶ（図面で押しにくい小さい区画など）</summary><div class="facelist" id="dwgFaces"></div></details>
    ${r2row(d)}
    <div class="small muted" id="dwgStatus" style="margin-top:6px"></div></div>`;
}

/* 新しい読み取りで分かったことの続き：つないだ文字・名前の提案・器具ではない物・表の設備機器 */
function r2more(A, on) {
  const o = [], n = Object.keys(A.names || {}).length, t = A.text || {};
  if (t.joined) o.push(`1文字ずつの文字 ${t.parts} 個を ${t.joined} 個の言葉につなぎました`);
  if (n) o.push(`名前の無い区画 ${n} 個に、中の文字から名前を付けられます${on ? '（部屋にする時に入ります）' : ''}`);
  if ((A.fxOut || []).length) o.push(`表題欄・表の中の「器具」${A.fxOut.length} 個は、会社のマークなどの見間違いと見ています${on ? '（器具の数から外しました）' : ''}`);
  if ((A.equip || []).length) o.push(`表の設備機器：${A.equip.slice(0, 8).map(e => `${esc(e.name)} ${esc(e.model)}`).join('／')}${A.equip.length > 8 ? ` ほか${A.equip.length - 8}件` : ''}`);
  const ti = A.title || {};
  if ((ti.project || []).length || (ti.sheet || []).length) o.push(`表題欄：${(ti.project || []).length ? `工事の名前「${esc(ti.project[0])}」` : ''}${(ti.sheet || []).length ? ` 図面の名前「${ti.sheet.slice(0, 4).map(esc).join('」「')}」` : ''}${(ti.scale || []).length ? ` 縮尺 ${esc(ti.scale[0])}` : ''}${(ti.date || []).length ? ` 日付 ${esc(ti.date[0])}` : ''}`);
  return o.length ? '<br>' + o.join('<br>') : '';
}

/* 段階3：壁ではなさそうな線を外して区画を探し直した結果の一行 */
function r2lines(d, on) {
  const v = d.v2; if (!v || !v.faces) return '';
  const rs = Object.keys(v.roles || {}).map(k => `${ROLE[k] || k} ${v.roles[k].toLocaleString()}本`)
    .concat(v.single ? [`机・椅子・テーブルなどの1本線 ${v.single.toLocaleString()}本`] : []).join('・');
  const n1 = (d.v1 ? d.v1.faces : d.plan.faces).length, n2 = (d.v1 ? d.plan.faces : v.faces).length;
  return `<br>壁ではなさそうな線（${rs}）を外して、区画を探し直しました：区画 ${n1} → ${n2} 個${on ? '（探し直した区画を出しています。印を外すと今までの区画に戻ります）' : '（印を付けると、探し直した区画に入れ替わります）'}${v.openDrop ? `。形が壁の線に合っていない区画 ${v.openDrop} 個は、扉の無い開口を壁から引いていません` : ''}`;
}

/* 1枚の図面に図がいくつも並んでいる時（1階の今・1階の改修・2階の改修 など）、使う図を選ぶ。
   図は図枠ごと（解析の sheets）。選んだ結果は drawing.sheetUse に図枠の位置をキーにして覚える。
   覚えていない時は、改修の図と今の図が両方ある図面だけ、今の図を使わない（それ以外は全部使う） */
/* 使わない図の中の区画（区画の真ん中が図枠の中）に「除外」の印 */
export function sheetMarks(d) {
  const out = {}, off = sheetsOf(d).filter(x => !x.use);
  if (!off.length) return out;
  (d.plan.faces || []).forEach(f => { const x = f.cx, y = f.cy; const sh = off.find(o => x >= o.box[0] && x <= o.box[2] && y >= o.box[1] && y <= o.box[3]); if (sh) out[f.i] = { s: 'out', type: 'sheet', why: `使わない図（${sh.title || `図 ${sh.k + 1}`}）の中です` }; });
  return out;
}
/* 表題欄の工事名称（どちらの読み取りでも出す）。案件の名前と違う時だけ「案件の名前に入れる」 */
/* 文字を覚えていない前の版の図面：図の分け方・工事名称は読み直さないと出ない。その事を先に知らせる（後で気付かないように） */
function oldReadRow(d) {
  if (!d || !d.analysis || d.src2 || d.analysis.ver === R2VER) return '';
  return `<div class="small dwg-oldread" style="margin-top:8px;padding:8px 10px;border-radius:8px;background:rgba(255,176,32,.12);color:#ffb020">⚠ この図面は前の版で読み込んだため、図の分け方（今の図・改修の図）や工事名称がまだ出ていません。上の「読み直す」で同じ図面を選び直すと出ます（一度読み直せば、次からは開くだけで新しくなります）。</div>`;
}
function titleRow(p) {
  const d = p.drawing, v = ((((d && d.analysis) || {}).title || {}).project || [])[0];
  if (!v) return '';
  const same = (p.name || '').trim() === v;
  return `<div class="row dwg-fs-hide" style="margin-top:10px;gap:8px;flex-wrap:wrap;align-items:center"><span class="small">図面の工事名称：<b>${esc(v)}</b></span>${same ? '<span class="small muted">（案件の名前と同じです）</span>' : `<button class="btn sm" data-act="r2name" style="min-height:40px">案件の名前に入れる</button>`}</div>`;
}
function sheetRow(d) {
  const S = sheetsOf(d); if (!S.length) return '';
  const kindTag = x => x.kind === 'now' ? '今の図' : x.kind === 'plan' ? '改修' : x.kind === 'table' ? '表' : '';
  return `<div style="margin-top:8px"><div class="small dwg-fs-hide" style="margin-bottom:4px"><b>この図面の中の図</b><span class="muted">（名前を押すとその図を大きく出します。印は使う図です）</span></div>
    <div class="row dwg-sheets" style="gap:6px;flex-wrap:wrap">
      <button class="btn sm" data-sheetzoom="" style="min-height:40px">全体</button>
      ${S.map(x => `<span class="row" style="gap:0;border:1px solid ${x.use ? 'var(--accent)' : 'var(--line)'};border-radius:10px;overflow:hidden;background:${x.use ? 'rgba(255,138,61,.10)' : 'transparent'}">
        <label style="display:flex;align-items:center;padding:0 8px;min-height:40px;cursor:pointer"><input type="checkbox" data-sheet="${x.key}" ${x.use ? 'checked' : ''} style="width:20px;height:20px" aria-label="${esc(x.title || `図 ${x.k + 1}`)}を使う"></label>
        <button data-sheetzoom="${x.key}" style="border:0;background:none;color:${x.use ? 'var(--text)' : 'var(--faint)'};padding:0 10px 0 2px;min-height:40px;font-size:13px;cursor:pointer">${esc(x.title || `図 ${x.k + 1}`)}${kindTag(x) ? `<span style="opacity:.7">（${kindTag(x)}）</span>` : ''}</button></span>`).join('')}
    </div></div>`;
}
function sheetNotes(d) {
  const S = sheetsOf(d); if (!S.length) return '';
  const alts = S.filter(x => x.use && x.alt);
  return `<div class="dwg-fs-hide" style="margin-top:8px">
    <span class="small muted">印を外した図の区画は灰色になり、「全部選ぶ」や照明の自動配置に入りません。${S.some(x => x.kind === 'now') && S.some(x => x.kind === 'plan') ? '今の図は、最初は使わないにしてあります（改修の図と同じ所を二重に数えないため）。' : ''}${S.some(x => x.kind === 'table') ? '表の図は、最初は使わないにしてあります。' : ''}</span>
    ${S.some(x => /（\dつ目）$/.test(x.title)) ? `<div class="small" style="margin-top:6px;padding:8px 10px;border-radius:8px;background:rgba(255,176,32,.12);color:#ffb020">⚠ 同じ名前の図が2つ以上あります。名前からは今の図か改修の図か分からないので、全部使うにしてあります。図面を見て、使わない方の印を外してください（そのままだと同じ所を二重に数えます）。</div>` : ''}
    ${alts.length >= 2 ? `<div class="small" style="margin-top:6px;padding:8px 10px;border-radius:8px;background:rgba(255,176,32,.12);color:#ffb020">⚠ 改修の案が ${alts.length} つとも使うになっています（${alts.map(x => esc(x.title)).join('・')}）。同じ所の別の案なので、見積もりに使う案だけに印を付けてください（そのままだと同じ所を二重に数えます）。</div>` : ''}
    <div class="small muted" style="margin-top:6px">※ 印を外すと、その図の中に自動で並べた照明も消えます（知らせの「照明を戻す」で戻せます）。</div></div>`;
}
/* 図面の上に、図の範囲の枠と名前を出す（使う図は橙の枠、使わない図は灰色の点線） */
function sheetOverlay(d, lw, texts = []) {
  const S = sheetsOf(d); if (!S.length) return '';
  /* 図の名前は、図面の文字とかぶらない所に置く（かつ「両方見えるように少しずらす」）。枠の上の辺に沿って左から、次に枠のすぐ外の上を探す。どこも空いていなければ左上 */
  const wOf = v => [...String(v)].reduce((a, c) => a + (/[\x20-\x7e\uff61-\uff9f]/.test(c) ? 0.6 : 1), 0);
  const TB = texts.map(q => [q.x, q.y - q.h * 0.25, q.x + wOf(q.s) * q.h, q.y + q.h]);
  const hit = (x0, y0, x1, y1) => TB.some(t => t[0] < x1 && t[2] > x0 && t[1] < y1 && t[3] > y0);
  return S.map(x => { const [a, b, c, e] = x.box, col = x.use ? 'var(--accent)' : '#8a93a0', fz = Math.max(0.2, Math.min((c - a) * 0.02, (e - b) * 0.035, 1.2));
    const label = (x.use ? '✓ ' : '× ') + (x.title || `図 ${x.k + 1}`), w = wOf(label) * fz;
    let at = null;
    for (const base of [e - fz * 1.15, e + fz * 0.3]) {   // 文字の下の線：枠の内側の上の帯、枠のすぐ外の上
      for (let x0 = a + fz * 0.4; x0 + w <= c - fz * 0.2 && !at; x0 += fz) if (!hit(x0 - fz * 0.2, base - fz * 0.3, x0 + w + fz * 0.2, base + fz * 0.95)) at = [x0, base];
      if (at) break; }
    if (!at) at = [a + fz * 0.4, e - fz * 1.15];
    return `<rect x="${a}" y="${-e}" width="${c - a}" height="${e - b}" fill="none" stroke="${col}" stroke-width="2.5" vector-effect="non-scaling-stroke" ${x.use ? '' : 'stroke-dasharray="8 6"'} pointer-events="none"/><text x="${at[0]}" y="${-at[1]}" font-size="${fz}" fill="${col}" font-weight="700" stroke="var(--bg)" stroke-width="${fz * 0.15}" paint-order="stroke" pointer-events="none">${esc(label)}</text>`; }).join('');
}

/* 新しい読み取り（試し）の切り替えと、見つけた図枠・表の数。解析の結果がある図面（JWW・DXF を読み込んだ時に作る）だけ出す */
function r2row(d) {
  const A = d.analysis; if (!A || !A.stats) return '';
  const st = A.stats, on = d.reader === 'v2', any = st.out || st.hold;
  return `<div class="row" style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line)"><label class="row" style="gap:8px;min-height:44px;cursor:pointer"><input type="checkbox" data-reader2 ${on ? 'checked' : ''} style="width:22px;height:22px"><b class="small">新しい読み取り（試し）：図枠・表を部屋にしない</b></label>
    <span class="small muted">${any ? `図枠 ${st.frames}・表 ${st.tables} を見つけました。部屋ではないと見た区画 ${st.out}・決めきれない区画 ${st.hold}` : st.frames ? `図枠 ${st.frames} を見つけました。印を付ける区画はありませんでした` : '図枠・表は見つかりませんでした（今までの読み取りと同じです）'}${on && any ? '。灰色＝部屋ではない、点線＝決めきれない。タップすると理由が出ます' : ''}${r2lines(d, on)}${r2more(A, on)}</span></div>`;
}

/* 自分の辞書：拾ったシンボルの寸法と「これは何か」を覚える（この端末の中だけ。寸法と名前と、
 * 測れた時は形の署名（円弧の割合などの特徴量）だけを持ち、図形そのものは持たない） */
const USER_SYM_KEY = 'kakugen-symdict-user';
let symVer = 0;
function userSyms() { try { return JSON.parse(localStorage.getItem(USER_SYM_KEY) || '[]').filter(u => u && u.id && u.name && u.short > 0 && u.long > 0).map(u => { if (!u.feat) return u; const f = slimSymFeat(u.feat); return f ? { ...u, feat: f } : { ...u, feat: undefined }; }); } catch (e) { return []; } }
function saveUserSyms(list) { try { localStorage.setItem(USER_SYM_KEY, JSON.stringify(list)); } catch (e) { /* 保存できなくても続ける */ } symVer++; }
/* 「これは何ですか」の編集画面。entry = { id?, name, short, long, feat? }。同じ寸法の登録があれば入れ替える。
 * feat（形の署名）が取れたシンボルでは、寸法と一緒に形も覚え、次からは
 * 「寸法＋形がほぼ同じ」シンボルにだけ当てる（寸法だけだと別の物にも当たるため） */
function openSymEditor(entry, onDone) {
  const m = modal({ title: 'これは何ですか', body: `
    <p class="small muted" style="margin-top:0">拾ったシンボルの寸法 <b>${entry.short}×${entry.long}mm</b> と、この名前を自分の辞書に覚えます。次からは、同じ寸法のシンボルがこの名前で「検出」になります。${entry.feat ? 'このシンボルは形（円弧の割合・閉じた輪郭など）も測れたので、形も一緒に覚えます。寸法が同じでも形の違うシンボルには当たりません。' : ''}</p>
    <label class="f">名前<input class="in" id="symName" type="text" value="${esc(entry.name || '')}" placeholder="例：大便器"></label>
    <div class="row" style="margin-top:8px;flex-wrap:wrap;gap:6px">${SYM_DICT.map(e => `<button class="btn sm" data-cat="${esc(e.category)}">${esc(e.category)}</button>`).join('')}</div>`,
    foot: `<button class="btn" data-close>やめる</button><button class="btn primary" data-save>覚える</button>` });
  const input = m.el.querySelector('#symName');
  m.el.querySelectorAll('[data-cat]').forEach(b => b.onclick = () => { input.value = b.dataset.cat; input.focus(); });
  m.el.querySelector('[data-save]').onclick = () => {
    const name = input.value.trim(); if (!name) { toast('名前を入れてください', { bad: true }); return; }
    const list = userSyms().filter(u => u.id !== entry.id && !(Math.abs(u.short - entry.short) <= Math.max(18, entry.short * 0.05) && Math.abs(u.long - entry.long) <= Math.max(18, entry.long * 0.05)));
    list.push({ id: entry.id || ('u' + Date.now().toString(36)), name, short: entry.short, long: entry.long, at: Date.now(), ...(entry.feat ? { feat: entry.feat } : {}) });
    saveUserSyms(list); m.close(); toast(`「${name}」として自分の辞書に覚えました`); onDone && onDone();
  };
  setTimeout(() => { try { input.focus(); } catch (e) { /* そのまま */ } }, 60);
}

/* 拾った器具をシンボル辞書で判定し直した結果（基本は外形の寸法だけの判定。
 * 輪郭の形の特徴が取れた器具は、決着した物だけ形の判定も使う＝sw.49）。
 * 机・椅子などの家具は、線の集まりから切り出した候補（d.furn）を形の特徴で判定し、検出・類似だけを足す。
 * 結果は図面ごとに覚える） */
const symCache = new WeakMap();
/* 根拠ボード（js/board.js・js/docs.js）からも同じ判定を読むため export する（中身は変えない） */
export function symList(d) {
  const fx = (d && d.fixtures) || [];
  const fu = (d && d.furn) || [];
  if (!fx.length && !fu.length) return [];
  /* 椅子の文脈判定はゾーン・区画・文字も根拠にするので、それらが変わったら判定し直す */
  const zsig = (d.zones || []).map(z => `${z.id || ''}|${z.name || ''}|${(z.faces || []).length}`).join(';');
  const faces = (d.plan && d.plan.faces) || [];
  const src2 = (d && d.src2) || null;
  /* 寸法の自動補正（js/symscale.js）：図面の証拠から推定した倍率。辞書の寸法判定だけに効かせる */
  const ss = symScaleFor(d);
  const scale = (ss && ss.factor > 0) ? ss.factor : 1;
  const plan = (d && d.plan) || null;
  /* 抽出強化ステップ1・層Aの材料（reader2 の frame 解析）。無い図面では層Aは効かない */
  const analysis = (d && d.analysis) || null;
  const c = symCache.get(d);
  if (c && c.from === fx && c.fu === fu && c.ver === symVer && c.zsig === zsig && c.faces === faces && c.src2 === src2 && c.ss === ss && c.plan === plan && c.ana === analysis) return c.list;
  const mine = userSyms();
  /* 器具の形の特徴：読み込み時に付け足した物（x.sf）を使う。無い図面（この機能より
   * 前に保存した案件）は plan の線からその場で取り出す。器具のレイヤーがグループから
   * 外れている図面では plan の線に輪郭が無いので、その場合は特徴なし（従来どおり
   * 寸法だけの表示）になる。利用者が直した器具には形の判定を使わない */
  let lazyIdx = null;
  const featOf = x => {
    if (!x || x.edited || !x.b) return null;
    if (x.sf) return x.sf;
    if (!plan || !(plan.segs || []).length) return null;
    if (!lazyIdx) lazyIdx = createShapeIndex([...(plan.segs || []), ...(plan.dsegs || [])]);
    try { return lazyIdx.featuresFor(x.b); } catch (e) { return null; }
  };
  /* 器具の表示判定は classifyFixtureDisplay：寸法だけが根拠の器具の確定は表示では
   * 「類似」までに落とす（sw.46）。生の判定は rawVerdict に残り、タイプ補正が使う。
   * 形の特徴が決着した物（オフィス什器＝むぎの sw.49、タンク帯の裏付けが取れた便器＝sw.50）だけ、形の「検出」にする。
   * 器具の救済が線の形で決めた器具（how）は、それより先に救済の判定を出す（拾い方と符の表示を揃える。2026-11-22）。
   * 表・表題欄の中の器具は、図面にも出さないので一覧にも並べない（fixturesInRegions＋むぎの sw.52 の titleRegionFlags） */
  const HOW = { jbowl: '和式便器', detail: '洋式大便器', sk: '流し・SK', bowlrow: '洗面器', bowls: '洗面器', basin: '洗面器' };
  const inReg = fixturesInRegions(d);
  const titleFlags = analysis ? titleRegionFlags(fx.map(x => x && x.b), analysis.regions || [], faces, analysis.marks || {}) : fx.map(() => false);
  const list = fx.map((x, k) => { if (!x || !x.b || inReg[k] || titleFlags[k]) return { k };
    const ft = featOf(x), learnFeat = slimSymFeat(ft);   /* learnFeat：「これは何？」で教える時に一緒に覚える形の署名（むぎの sw.53） */
    if (x.how && HOW[x.how]) { const r = classifyFixtureDisplay(x.b, mine, scale); if (!r.mine) return { k, b: x.b, t: x.t, ...r, verdict: 'hit', rawVerdict: 'hit', category: HOW[x.how], shape: x.how, capped: false, sizeVeto: null, learnFeat }; return { k, b: x.b, t: x.t, ...r, learnFeat }; }
    return { k, b: x.b, t: x.t, ...classifyFixtureDisplay(x.b, mine, scale, ft), learnFeat }; }).filter(s => s.b);
  /* 素の四角ガード・物でない物の除外（むぎの sw.52。実測の根拠は js/symdict.js の bareClusterFlags・nonObjectFlags） */
  const bareFlags = bareClusterFlags(fu, (src2 && src2.texts) || []);
  const poolBoxes = [...fx.map(x => x && x.b), ...fu.map(x => x && x.b)].filter(Boolean);
  const exclFlags = nonObjectFlags(fu, (src2 && src2.texts) || [], poolBoxes);
  const baseFu = fu.map((x, j) => (x && x.b) ? classifyCluster(x, mine, null, scale, bareFlags[j]) : null);
  let ctxs = [];
  try { ctxs = buildChairContexts(fu, baseFu, { zones: d.zones || [], faces, fixtures: fx, texts: (src2 && src2.texts) || [] }, scale); } catch (e) { ctxs = []; }
  fu.forEach((x, j) => {
    if (!x || !x.b) return;
    if (exclFlags[j]) return; /* 層B：物ではない物は一覧に出さない */
    const r = ctxs[j] ? classifyCluster(x, mine, ctxs[j], scale, bareFlags[j]) : baseFu[j];
    if (!r || r.verdict === 'unknown') return; /* 家具の候補は「不明」を並べない（線の集まりは数が多く、判定できた物だけ出す） */
    list.push({ k: 10000 + j, b: x.b, t: null, furn: true, ...r, learnFeat: slimSymFeat(x) });
  });
  symCache.set(d, { from: fx, fu, ver: symVer, zsig, faces, src2, ss, plan, ana: analysis, list });
  return list;
}
/* 器具のタイプ補正（js/typefix.js）：保存してある器具の種類は変えず、辞書の判定と
 * 寸法の参照基準と図面の文脈で照合して「表示する種類」だけを決める。結果は器具の
 * 並びと同じ順で返る（補正なしは null、{ shown, rule, reason, confirm }）。
 * 利用者が種類を直した器具は補正しない（typefix 側でも edited を見ている） */
const tfCache = new WeakMap();
export function typeFixMap(d) {
  const fx = (d && d.fixtures) || [];
  if (!fx.length) return [];
  const S = symList(d);
  const tsig = fx.map(x => `${x.t}:${x.edited ? 1 : 0}`).join(',');
  const zsig = (d.zones || []).map(z => z.name || '').join(';');
  const c = tfCache.get(d);
  if (c && c.S === S && c.tsig === tsig && c.zsig === zsig && c.psegs === ((d.plan && d.plan.segs) || null)) return c.map;
  const byK = new Map(S.filter(s => !s.furn).map(s => [s.k, s]));
  /* タイプ補正には表示用に落とす前の生の判定（rawVerdict）を渡す（sw.46）。
   * カテゴリ・スコア・寸法制限も、形の表示判定（sw.49）に替わる前の寸法だけの
   * 生判定（boxCat・boxScore・boxVeto）を渡す。タイプ補正の入力は従来と同一に保つ */
  const verdicts = fx.map((x, k) => { const s = byK.get(k); return s ? { verdict: s.rawVerdict || s.verdict, category: s.boxCat !== undefined ? s.boxCat : s.category, score: s.boxScore != null ? s.boxScore : s.score, sizeVeto: s.boxVeto !== undefined ? s.boxVeto : (s.sizeVeto || null) } : null; });
  const ss = symScaleFor(d);
  const scale = (ss && ss.factor > 0) ? ss.factor : 1;
  /* 幾何チェック（sw.45・46）の材料：面と線は、要る器具がある図面でだけ用意する。
   * 面の輪郭化は図面全体にかかるので、浴槽型が無い図面では計算しない。
   * 線は sw.46 で、タンク帯の裏付けが要る候補（小便器の列・個室の便器）にも渡す */
  const psegs = (d.plan && d.plan.segs) || null;
  const needFaces = fx.some(x => x.t === 'bath');
  const needSegs = needFaces
    || fx.some((x, k) => (x.t === 'counter' || x.t === 'kitchen') && verdicts[k] && (verdicts[k].category === '洋式大便器' || verdicts[k].category === '小便器'))
    || fx.some(x => x.t === 'toilet')
    || fx.some((x, k) => (x.t === 'counter' || x.t === 'kitchen') && verdicts[k] && verdicts[k].verdict === 'hit' && (verdicts[k].category === 'キッチン・洗濯設備' || verdicts[k].category === '椅子'));
  let faces = null, segs = null;
  if (needSegs && psegs && psegs.length) {
    segs = psegs;
    if (needFaces) { try { faces = polygonizeFaces(psegs); } catch (e) { faces = null; } }
  }
  let map = fx.map(() => null);
  /* 線の形で決めた器具（how）は、種類の直し（寸法と文脈の補正）の対象にしない＝手で直した器具と同じ扱い */
  const fxT = fx.map(x => (x && x.how && !x.edited) ? { ...x, edited: true } : x);
  try { map = correctFixtureTypes(fxT, { verdicts, texts: (d.src2 && d.src2.texts) || [], zoneNames: (d.zones || []).map(z => z.name).filter(Boolean), scale, faces, segs }); }
  catch (e) { console.warn('器具のタイプ補正に失敗', e); }
  tfCache.set(d, { S, tsig, zsig, psegs, map });
  return map;
}
/* 器具の「表示する種類」（補正があれば補正後、無ければ保存してある種類） */
const shownFixType = (TF, x, k) => (TF[k] && TF[k].shown) || x.t;

/* 図面の器具の種類ごとの数（fixLinesDialog と同じ数え方）。数量の出どころ表示
 * （js/provenance.js）の材料。器具が無い・図面が無い案件では null（数え比べができない） */
function fixCountsOf(p) {
  const fx = (p.drawing && p.drawing.fixtures) || [];
  if (!fx.length) return null;
  const TF = typeFixMap(p.drawing), c = {};
  fx.forEach((x, k) => { const t = shownFixType(TF, x, k); c[t] = (c[t] || 0) + 1; });
  return c;
}

/* シンボルの判定の一覧：行を押すと図面のその場所へ飛ぶ */
function symSummary(d, selK = -1) {
  const S = symList(d);
  if (!S.length) return '';
  const TF = typeFixMap(d);
  const cnt = { hit: 0, near: 0, unknown: 0 }; S.forEach(s => cnt[s.verdict]++);
  const label = s => s.verdict === 'hit' ? s.category : s.verdict === 'near' ? `類似：${s.category || '不明'}` : '不明';
  const tfSpan = s => { if (s.furn) return ''; const tf = TF[s.k]; if (!tf) return '';
    if (tf.shown) return `<span style="color:var(--warn)">（タイプ補正：${esc(FIX_NAMES[tf.shown] || tf.shown)}として表示。${esc(tf.reason)}）</span>`;
    if (tf.confirm) return `<span style="color:var(--warn)">（要確認：${esc(tf.reason)}）</span>`; return ''; };
  const rows = S.slice(0, 150).map(s => `<div class="row" style="gap:6px;flex-wrap:nowrap"><button class="btn sm" data-sym="${s.k}" style="justify-content:flex-start;gap:8px;min-height:40px;flex:1;text-align:left${s.k === selK ? ';border-color:var(--accent);background:rgba(255,138,61,.10)' : ''}"><span style="width:12px;height:12px;border-radius:3px;background:${SYM_VERDICTS[s.verdict].color};flex:none"></span><b>${esc(label(s))}</b><span class="muted">${Math.round(s.short)}×${Math.round(s.long)}mm</span>${s.furn ? '<span class="muted">（線から検出）</span>' : ''}${s.capped ? '<span class="muted">（寸法のみの判定）</span>' : ''}${s.tankBand != null ? '<span class="muted">（形とタンク帯で判定）</span>' : s.shapeBased ? '<span class="muted">（形で判定）</span>' : s.shape ? '<span class="muted">（線の形で拾った器具）</span>' : ''}${s.context ? '<span class="muted">（文脈で確定）</span>' : ''}${s.mine ? '<span class="muted">（自分の辞書）</span>' : s.t && FIX_NAMES[s.t] ? `<span class="muted">（今の判定：${esc(FIX_NAMES[s.t])}）</span>` : ''}${tfSpan(s)}</button><button class="btn sm" data-symreg="${s.k}" style="min-height:40px;flex:none">${s.mine ? '直す' : 'これは何？'}</button></div>`).join('');
  const mine = userSyms();
  const mineHtml = mine.length ? `<div style="margin-top:10px"><b class="small">自分の辞書（${mine.length}件）</b><div style="display:grid;gap:6px;margin-top:6px">${mine.map(u => `<div class="row" style="gap:6px"><span class="pill" style="border:1px solid ${SYM_VERDICTS.hit.color};color:${SYM_VERDICTS.hit.color}">${esc(u.name)}</span><span class="small muted">${u.short}×${u.long}mm</span>${u.feat ? '<span class="small muted">（形つき：寸法と形が合う物だけに当たります）</span>' : ''}<span class="spacer"></span><button class="btn sm" data-symedit="${u.id}">名前を直す</button><button class="btn sm ghost danger" data-symdel="${u.id}">消す</button></div>`).join('')}</div></div>` : '';
  return `${(d.dims && d.dims.length) ? '' : symScaleLine(d)}<div class="row" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)"><b class="small">シンボルの判定（辞書）</b>
    ${['hit', 'near', 'unknown'].map(v => `<span class="pill" style="border:1px solid ${SYM_VERDICTS[v].color};color:${SYM_VERDICTS[v].color}">${SYM_VERDICTS[v].name} ${cnt[v]}</span>`).join('')}
    <span class="small muted">器具は寸法だけの判定では「類似」までにしています（寸法だけの確定は実測で正解率が低いため）。器具の輪郭の形が読み取れて、机・椅子と決着した物と、タンク帯の裏付けが取れた便器だけ「検出」にしています。机・椅子などの家具は線の形から判定しています。行を押すと図面のその場所へ飛びます。色は図面の「符」ボタンで消せます</span></div>
    <div style="margin-top:8px;display:grid;gap:6px;max-height:320px;overflow:auto">${rows}${S.length > 150 ? `<div class="small muted">ほか ${S.length - 150} 件（先頭150件だけ出しています）</div>` : ''}</div>${mineHtml}`;
}

/* 部屋の見分け（現段階）：今の読み取り・解析が持っている根拠で区画を色分けする（表示だけ。部屋・見積は変えない） */
const rjCache = new WeakMap();
/* 見分けの対象：エンジンの区画＋補足区画（js/polygonize.js。線から作った候補）。
 * 補足区画は読み取り直した区画（v2）に差し替えている間は対象にしない（補足は元の区画に対して作ってあるため） */
const judgeFacesOf = d => [...(d.plan.faces || []), ...(d.reader === 'v2' ? [] : (d.polyFaces || []))];
function roomJudge(d) {
  if (!d || !d.plan || !d.plan.faces) return null;
  const c = rjCache.get(d);
  /* ゾーンは名前の付け替え等でその場で書き換わるので、配列の同一性ではなく署名で比べる */
  const zsig = (d.zones || []).map(z => `${z.id || ''}|${z.name || ''}|${(z.faces || []).length}`).join(';');
  if (c && c.faces === d.plan.faces && c.poly === d.polyFaces && c.reader === d.reader && c.analysis === d.analysis && c.fixtures === d.fixtures && c.doors === d.doors && c.src2 === d.src2 && c.zsig === zsig) return c.r;
  const A = d.analysis || {};
  const r = judgeRooms(judgeFacesOf(d), { marks: A.marks || {}, names: A.names || {}, fixtures: d.fixtures || [], doors: d.doors || [], zones: d.zones || [], texts: (d.src2 && d.src2.texts) || [] });
  rjCache.set(d, { faces: d.plan.faces, poly: d.polyFaces, reader: d.reader, analysis: d.analysis, fixtures: d.fixtures, doors: d.doors, src2: d.src2, zsig, r });
  return r;
}
function roomJudgeEntries(d) {
  const r = roomJudge(d); if (!r) return [];
  const style = { room: { op: 0.06, so: 0.95 }, hold: { op: 0.05, so: 0.9, dash: true }, out: { op: 0.10, so: 0.7 }, unknown: { op: 0, so: 0.35 } };
  return judgeFacesOf(d).filter(f => f && f.poly && r.map[f.i]).map(f => ({ poly: f.poly, color: ROOM_JUDGE[r.map[f.i]].color, ...(style[r.map[f.i]] || {}) }));
}
function roomSummary(d) {
  const r = roomJudge(d); if (!r || !r.counts.total) return '';
  const c = r.counts;
  return `<div class="row" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)"><b class="small">部屋の見分け（現段階）</b>
    ${['room', 'hold', 'out', 'unknown'].map(k => `<span class="pill" style="border:1px solid ${ROOM_JUDGE[k].color};color:${ROOM_JUDGE[k].color}">${ROOM_JUDGE[k].name} ${c[k]}</span>`).join('')}
    <span class="small muted">全 ${c.total} 区画。緑は名前・器具・ドア・ゾーンの根拠がある区画です。${d.reader !== 'v2' && (d.polyFaces || []).length ? `うち ${(d.polyFaces || []).length} 件は、区画として拾えなかった床を線から作った補足区画です。` : ''}色は図面の「室」ボタンで消せます。部屋・見積には影響しません</span></div>`;
}

function fixSummary(d) {
  const fx = d.fixtures || [];
  if (!fx.length) return d.fixtures ? '<div class="small muted" style="margin-top:8px">器具は見つかりませんでした。</div>' : '';
  const TF = typeFixMap(d);
  const c = {}; let nCorr = 0, nMark = 0, nOff = 0; const use = fixturesInUse(d);
  fx.forEach((x, k) => { if (!use[k]) { nOff++; return; } const t = shownFixType(TF, x, k); c[t] = (c[t] || 0) + 1; const tf = TF[k]; if (tf) { if (tf.shown) nCorr++; else if (tf.confirm) nMark++; } });
  const note = (nCorr || nMark) ? `<div class="small muted" style="flex-basis:100%">辞書と寸法の照合による${[nCorr ? `表示の補正 ${nCorr} 件` : '', nMark ? `要確認 ${nMark} 件` : ''].filter(Boolean).join('・')}があります（保存してある判定そのものは変えていません。理由は下のシンボル判定の一覧で見られます）</div>` : '';
  return `<div class="row" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)"><b class="small">図面の器具</b>
    ${Object.entries(c).map(([t, n]) => `<span class="pill ${t === 'unknown' ? 'warn' : t === 'other' ? '' : 'info'}">${esc(FIX_NAMES[t] || t)} ${n}</span>`).join('')}
    <span class="spacer"></span><button class="btn sm primary" data-act="fixLines">${icon('list')}器具を明細に入れる</button>${note}${nOff ? `<div class="small muted" style="flex-basis:100%">使わない図・表・表題欄の中の器具 ${nOff} 個は数えていません（図の印で変えられます）</div>` : ''}</div>`;
}

/* ゾーン分け（部屋の候補）：色はゾーンの並び順で決める */
const ZONE_COLORS = ['#f2789f', '#f2a541', '#7bc950', '#4cc3d9', '#9b7bde', '#e5635c', '#5b8def', '#d9c84a', '#43b581', '#c86dd7', '#f08c4a', '#6fc7a5'];
const zoneColor = k => ZONE_COLORS[k % ZONE_COLORS.length];

/* 図面に出すゾーンの色塗り（区画の形をゾーンの色で薄く塗る＋名前）。選んだゾーンは濃くする */
export function zoneEntries(d, selId = '') {
  const Z = (d && d.zones) || [];
  if (!Z.length || !d.plan) return [];
  const byI = new Map(d.plan.faces.map(f => [f.i, f]));
  const out = [];
  Z.forEach((z, k) => {
    const color = zoneColor(k);
    z.faces.forEach(i => { const f = byI.get(i); if (f) out.push({ poly: f.poly, color, op: z.id === selId ? 0.34 : 0.15 }); });
    if (z.name) out.push({ label: z.name, lx: z.x, ly: z.y, color });
  });
  return out;
}

/* ゾーンの一覧：選ぶと、部屋にする・線で分ける・名前・合体・消すが出る */
function zoneSummary(d, selId = '') {
  if (!d || !d.plan) return '';
  const Z = d.zones;
  if (!Z) return `<div class="card" style="margin-top:10px"><div class="row"><b>ゾーン分け</b><span class="spacer"></span><button class="btn sm" data-zmake="1">ゾーン分けする</button></div><div class="small muted" style="margin-top:4px">開けた場所を、部屋の候補の範囲に分けます（壁で囲まれた部屋は、今の区画のままで大丈夫です）。</div></div>`;
  if (!Z.length) return '';
  const rows = Z.map((z, k) => {
    const sel = z.id === selId;
    let h = `<div class="row" style="gap:6px;flex-wrap:nowrap"><button class="btn sm" data-zsel="${z.id}" style="justify-content:flex-start;gap:8px;min-height:40px;flex:1;text-align:left${sel ? ';border-color:var(--accent);background:rgba(255,138,61,.10)' : ''}"><span style="width:12px;height:12px;border-radius:3px;background:${zoneColor(k)};flex:none"></span><b>${esc(z.name || '名前なし')}</b><span class="muted">約${z.area}㎡・区画${z.faces.length}件</span>${z.fixed ? '<span class="muted">（手直し済み）</span>' : ''}</button>`;
    if (selId && !sel) h += `<button class="btn sm" data-zmerge="${z.id}" style="min-height:40px;flex:none" title="選んでいるゾーンと合体します">合体</button>`;
    h += '</div>';
    if (sel) h += `<div class="row" style="gap:6px;margin:2px 0 8px;flex-wrap:wrap"><button class="btn sm primary" data-zroom="${z.id}" ${z.faces.length ? '' : 'disabled'}>この範囲を部屋にする</button><button class="btn sm" data-zsplit="${z.id}" ${z.faces.length ? '' : 'disabled'}>線で分ける</button><button class="btn sm" data-zname="${z.id}">名前を付ける</button><button class="btn sm ghost danger" data-zdel="${z.id}">消す</button></div>`;
    return h;
  }).join('');
  return `<div class="card" style="margin-top:10px"><div class="row"><b>ゾーン分け（部屋の候補）</b><span class="muted small">${Z.length}件</span><span class="spacer"></span><button class="btn sm ghost" data-zmake="1">分け直す</button></div><div class="small muted" style="margin:4px 0 6px">自動で分けた下書きです。面積は目安です。違う所は、ゾーンを選んで「線で分ける」「合体」で直せます。手直ししたゾーンは、分け直しても残ります。</div>${rows}</div>`;
}

/* 図面の寸法（DXF から別に拾った物。エンジンは寸法を拾わないので、読み込みの時に
 * js/dxf-dims.js で抜いて d.dims に覚えている。表示だけで、区画・部屋・見積には使わない。
 * 古い保存には dims が無いので、その時は出さない） */
/* 倍率の表示（有効数字3桁まで。50.0 → 50、0.0200 → 0.02） */
const fmtFactor = v => String(Number(v.toPrecision(3)));
/* シンボルの大きさの自動補正（js/symscale.js の推定）の表示。補正が効いている時だけ出す。
 * 倍率は「測った寸法に掛けると実寸になる値」（1 ÷ factor）で出す。根拠も添える。
 * 寸法のある図面では寸法の答え合わせの隣（dimSummary）に、無い図面では
 * シンボルの判定の所（symSummary）に出す（二重には出さない） */
function symScaleLine(d) {
  const ss = symScaleFor(d);
  if (!ss || !(ss.factor > 0) || Math.abs(ss.factor - 1) <= 0.01) return '';
  const basis = ss.source === 'dims' ? `寸法${ss.n}件で照合` : ss.source === 'user' ? '手入力' : `便器${ss.n}件の大きさから推定`;
  return `<div class="small" style="margin-top:6px">シンボルの大きさを${ss.source === 'user' ? '' : '自動'}補正 ×${fmtFactor(1 / ss.factor)}（${basis}）</div>`;
}
/* 縮尺・換算係数の検証（js/symscale.js の scaleCheck）の表示と、要確認リスト。
 * 寸法の答え合わせの行（dimSummary の check）と二重に出さないよう、寸法で状態が
 * 出ている時（寸法で確認済み・寸法との比率のずれ）はここでは状態の行を出さない。
 * 未検証の値は赤で出す。値そのものはタップできない（誤タップ防止・2026-11-24）：
 * 直す入口は要確認リストだけで、タップすると図面の場所へ飛んでから編集が開く */
function scaleBlock(d) {
  if (!d || !d.plan) return '';
  const sc = scaleCheck(d);
  let line = '';
  if (sc.state === 'unverified') {
    line = `<div class="small" style="margin-top:6px">換算係数 <b style="color:var(--bad)">×${fmtFactor(sc.coef)}（未検証）</b></div><div class="small muted" style="margin-top:2px">${esc(sc.why)}。係数 1（実寸どおり）とみなしています。違う時は、下の要確認リストから直してください</div>`;
  } else if (sc.state === 'manual') {
    line = `<div class="small" style="margin-top:6px">換算係数 <b>×${fmtFactor(sc.coef)}</b> <span class="pill">手入力</span></div><div class="small muted" style="margin-top:2px">シンボルの大きさの判定と、区画から作る部屋の広さ・周りに使います${sc.autoCoef !== null ? `。自動の値は ×${fmtFactor(sc.autoCoef)} でした` : ''}</div>`;
  } else if (sc.state === 'verified' && sc.source === 'symbols') {
    line = `<div class="small muted" style="margin-top:6px">便器の大きさから縮尺を確認済み（${sc.n}件で照合）</div>`;
  }
  let list = '';
  if (sc.state === 'unverified' || sc.state === 'mismatch' || sc.state === 'manual') {
    const val = sc.state === 'manual' ? `<b>×${fmtFactor(sc.coef)}</b><span class="pill">手入力</span>`
      : `<b style="color:var(--bad)">×${fmtFactor(sc.coef)}${sc.state === 'mismatch' ? '（寸法との比率）' : '（未検証）'}</b>`;
    const why = sc.state === 'mismatch' ? '寸法と図形の比率が 1 から 1% を超えてずれています' : sc.state === 'manual' ? '手入力で決めた係数です。確かめる・自動に戻す時はタップ' : esc(sc.why);
    list = `<div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line)"><div class="row"><b class="small">要確認</b><span class="small muted">タップすると、図面の場所へ飛んで直せます</span></div>
    <button class="btn sm" data-scalecheck="1" style="justify-content:flex-start;gap:8px;min-height:40px;width:100%;text-align:left;margin-top:6px"><span>縮尺・換算係数</span>${val}<span class="muted" style="flex:1">${why}</span></button></div>`;
  }
  return line + list;
}

function dimSummary(d) {
  const dims = (d && d.dims) || [];
  const scale = scaleBlock(d);
  if (!dims.length) return scale;
  const chips = dims.slice(0, 60).map(x => `<span class="pill">${esc(x.text)}</span>`).join('');
  /* 寸法の答え合わせ（読み込み時に集計した d.dimCheck。表示だけで、縮尺を自動で直すことはしない。
   * dimCheck が無い保存でも、寸法に定義点が残っていれば dimCheckFor がその場で作り直す。
   * 定義点も無い古い保存（.28 以前）の時は、寸法の一覧だけ出す） */
  let check = '';
  const chk = dimCheckFor(d);
  if (chk && chk.n >= 1 && typeof chk.median === 'number') {
    const outliers = chk.outliers || [], edited = chk.edited || [];
    if (Math.abs(chk.median - 1) > 0.01) {
      check += `<div class="small" style="margin-top:6px;color:var(--bad)">寸法と図形の比率が約${fmtFactor(chk.median)}倍です。用紙mmの図面かもしれません（自動では直しません）</div>`;
    } else if (!outliers.length) {
      check += `<div class="small muted" style="margin-top:6px">寸法で縮尺を確認済み（${chk.n}件で照合）</div>`;
    }
    const flagged = [...outliers, ...edited.filter(x => !outliers.includes(x))];
    if (flagged.length) {
      const fchips = flagged.slice(0, 60).map(x => `<span class="pill warn">${esc(x.text)}</span>`).join('');
      check += `<div class="row" style="gap:6px;margin-top:8px"><b class="small">要確認の寸法</b>${fchips}${flagged.length > 60 ? `<span class="small muted">ほか ${flagged.length - 60} 件</span>` : ''}</div>`;
    }
  }
  return `<div class="row" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line)"><b class="small">寸法</b>
    <span class="pill info">${dims.length}件</span>
    <span class="small muted">図面に書かれていた寸法です（mm）。見積には入りません</span></div>${check}${symScaleLine(d)}
    <div class="row" style="gap:6px;margin-top:8px">${chips}${dims.length > 60 ? `<span class="small muted">ほか ${dims.length - 60} 件</span>` : ''}</div>${scale}`;
}

/* ゾーンの名前を付ける・直す */
function openZoneEditor(zone, onDone) {
  const m = modal({ title: 'ゾーンの名前', body: `
    <p class="small muted" style="margin-top:0">この範囲の名前です。部屋にする時は、この名前が部屋の名前になります。</p>
    <label class="f">名前<input class="in" id="zoneName" type="text" value="${esc(zone.name || '')}" placeholder="例：事務室"></label>`,
    foot: `<button class="btn" data-close>やめる</button><button class="btn primary" data-save>決める</button>` });
  const input = m.el.querySelector('#zoneName');
  m.el.querySelector('[data-save]').onclick = () => {
    zone.name = input.value.trim();
    zone.fixed = true;
    m.close(); onDone && onDone();
  };
  setTimeout(() => { try { input.focus(); } catch (e) { /* そのまま */ } }, 60);
}

/* 換算係数を人が決める（要確認リストから開く）。自動の値と根拠を見せてから決める。
 * 決めた値は drawing.scaleUser に覚える（出どころは手入力）。効くのは symScaleFor
 * （辞書の寸法判定）と geoOf（区画から作る部屋の広さ・周り）。「自動の値に戻す」で
 * scaleUser を消すと、自動の推定に戻る。図面の線そのものは変えない */
function openScaleEditor(p, onDone) {
  const d = p.drawing, sc = scaleCheck(d);
  const autoTxt = sc.autoCoef === null ? '自動では決められていません（証拠が足りません）'
    : `×${fmtFactor(sc.autoCoef)}（${sc.autoSource === 'dims' ? `寸法${sc.n}件で照合` : sc.autoSource === 'symbols' ? `便器${sc.n}件の大きさから推定` : '自動'}）`;
  const m = modal({ title: '換算係数を決める', body: `
    <p class="small muted" style="margin-top:0">図面で測った長さに、この係数を掛けると実寸になります（面積は係数の2乗で直ります）。決めた係数は、シンボルの大きさの判定と、これから区画から作る部屋の広さ・周りに使います。すでに作った部屋と、図面の線そのものは変えません。</p>
    <div class="small" style="margin-bottom:8px">今の値：<b>×${fmtFactor(sc.coef)}</b>${sc.state === 'manual' ? ' <span class="pill">手入力</span>' : sc.state === 'unverified' ? ' <span style="color:var(--bad)">（未検証）</span>' : ''}<br>自動の値：${autoTxt}</div>
    <label class="f">換算係数<input class="in num" id="scaleCoef" type="number" inputmode="decimal" step="any" min="0" value="${sc.coef}"></label>
    <div class="row" style="gap:6px;margin-top:8px;flex-wrap:wrap">
      <button class="btn sm" data-k="1">実寸のまま ×1</button>
      <button class="btn sm" data-k="10">cmで書かれた図面 ×10</button>
      <button class="btn sm" data-k="50">用紙mm・1/50 ×50</button>
      <button class="btn sm" data-k="100">用紙mm・1/100 ×100</button>
    </div>`,
    foot: `${userCoef(d) !== null ? '<button class="btn ghost" data-auto>自動の値に戻す</button>' : ''}<button class="btn" data-close>やめる</button><button class="btn primary" data-save>決める</button>` });
  const input = m.el.querySelector('#scaleCoef');
  m.el.querySelectorAll('[data-k]').forEach(b => b.onclick = () => { input.value = b.dataset.k; input.focus(); });
  const autoBtn = m.el.querySelector('[data-auto]');
  if (autoBtn) autoBtn.onclick = () => { delete d.scaleUser; delete d.symScale; touch(p); m.close(); onDone && onDone(); toast('換算係数を自動の値に戻しました'); };
  m.el.querySelector('[data-save]').onclick = () => {
    const v = parseFloat(input.value);
    if (!(Number.isFinite(v) && v > 0 && v <= 100000)) { toast('係数は 0 より大きい数字で入れてください', { bad: true }); return; }
    d.scaleUser = v; delete d.symScale;
    touch(p); m.close(); onDone && onDone();
    toast(`換算係数を ×${fmtFactor(v)} にしました（手入力）`);
  };
  setTimeout(() => { try { input.focus(); input.select(); } catch (e) { /* そのまま */ } }, 60);
}

function fixLinesDialog(p, after) {
  const fx = (p.drawing && p.drawing.fixtures) || [];
  /* 種類はタイプ補正後の表示で数える（保存してある判定は変えない。js/typefix.js） */
  const TF = typeFixMap(p.drawing);
  const c = {}; const corrIn = {}; let nCorr = 0; const use = fixturesInUse(p.drawing); let nOff = 0;
  fx.forEach((x, k) => { if (!use[k]) { nOff++; return; } const t = shownFixType(TF, x, k); c[t] = (c[t] || 0) + 1; if (TF[k] && TF[k].shown) { corrIn[t] = (corrIn[t] || 0) + 1; nCorr++; } });
  const items = masterItems();
  const types = Object.keys(c).filter(t => FIX_ITEMS[t]);
  const opts2 = (t, kind, def) => {
    const words = FIX_WORDS[t] || [];
    const list = items.filter(i => words.some(w => i.name.includes(w)) && (kind === 'labor' ? i.kind === 'labor' : i.kind !== 'labor'));
    return `<option value="">入れない</option>` + list.map(i => `<option value="${esc(i.id)}" ${i.id === def ? 'selected' : ''}>${esc(i.name)}${i.spec ? ' ' + esc(i.spec) : ''}（${yen(i.price)}）</option>`).join('');
  };
  const skip = (c.unknown || 0) + (c.other || 0);
  /* 新しい読み取りを選んだ図面で、図面の表（設備機器）に品番が書いてあれば、本体の行の品番に入れる */
  const eq = (p.drawing && p.drawing.reader === 'v2' && p.drawing.analysis && p.drawing.analysis.equip) || [];
  const codeOfType = t => modelFor(t, eq);
  const m = modal({
    title: '図面の器具を明細に入れる', wide: true,
    body: `<p class="small muted" style="margin-top:0">種類ごとに、入れる品目と数を確かめてください。前に入れた器具の行は入れ直します。${skip ? `「判定保留」「器具ではない」の ${skip} 個は入れません。` : ''}${nOff ? `使わない図・表・表題欄の中の ${nOff} 個は入れません。` : ''}${nCorr ? `種類は辞書と寸法で照合した補正後の表示です（補正 ${nCorr} 件。理由は図面タブのシンボル判定の一覧で見られます）。` : ''}</p>
      <div class="grid" style="gap:10px">${types.map(t => `<div class="card" style="padding:12px" data-ft="${t}"><div class="row" style="margin-bottom:8px"><b>${esc(FIX_NAMES[t])}</b><span class="pill info">図面で ${c[t]} 個</span>${corrIn[t] ? `<span class="pill warn">うち補正 ${corrIn[t]} 件</span>` : ''}${codeOfType(t) ? `<span class="pill ok">図面の品番 ${esc(codeOfType(t))}</span>` : ''}</div>
        <div class="grid g3"><label class="f">本体<select class="in" data-k="body">${opts2(t, 'mat', FIX_ITEMS[t][0])}</select></label>
        <label class="f">取付の手間<select class="in" data-k="labor">${opts2(t, 'labor', FIX_ITEMS[t][1])}</select></label>
        <label class="f">数<input class="in num" type="number" inputmode="numeric" data-k="n" value="${c[t]}"></label></div></div>`).join('') || '<p class="muted">明細に入れられる器具がありません。</p>'}</div>`,
    foot: `<button class="btn" data-close>やめる</button><button class="btn primary" id="fxGo">明細に入れる</button>`
  });
  $('#fxGo', m.el).onclick = () => {
    let added = 0;
    $$('[data-ft]', m.el).forEach(row => {
      const t = row.dataset.ft, n = Number($('[data-k=n]', row).value) || 0;
      p.lines = p.lines.filter(l => l.fromFix !== t);
      if (!(n > 0)) return;
      ['body', 'labor'].forEach(k => {
        const id = $(`[data-k=${k}]`, row).value; const it = id && items.find(i => i.id === id); if (!it) return;
        /* ステンレス流しは寸法で作ってもらう物なので、図面の大きさ（長さ×奥行）を規格に書いておく */
        const dim = t === 'trough' && k === 'body' ? [...new Set(fx.filter((x, xi) => shownFixType(TF, x, xi) === t && x.b).map(x => { const a = Math.abs(x.b[2] - x.b[0]), b2 = Math.abs(x.b[3] - x.b[1]); return `長さ${fmt(Math.max(a, b2), 2)}m×奥行${fmt(Math.min(a, b2), 2)}m`; }))].join('・') : '';
        p.lines.push({ id: uid('l'), itemId: it.id, name: it.name, spec: [it.spec, dim].filter(Boolean).join(' '), unit: it.unit, kind: it.kind, price: it.price || '', cost: '', loss: '', sheet: 0, cat: it.cat, qty: n, basis: null, fromFix: t, ...(k === 'body' && codeOfType(t) ? { code: codeOfType(t) } : {}) });
        added++;
      });
    });
    touch(p); m.close(); after && after();
    toast(added ? `器具の行を ${added} 行入れました（③工事で確かめてください）` : '入れる行がありませんでした');
  };
}

/* 一番近い線（壁の解体で線をタップした時） */
function nearestSeg(plan, x, y, tol) {
  let best = -1, bd = tol;
  plan.segs.forEach((s, i) => {
    const dx = s[2] - s[0], dy = s[3] - s[1], L2 = dx * dx + dy * dy; if (!L2) return;
    const t = Math.max(0, Math.min(1, ((x - s[0]) * dx + (y - s[1]) * dy) / L2));
    const d = Math.hypot(s[0] + t * dx - x, s[1] + t * dy - y);
    if (d < bd) { bd = d; best = i; }
  });
  return best;
}
const segLen = s => Math.hypot(s[2] - s[0], s[3] - s[1]);

/* 選んだ壁がどの部屋の壁か：壁の上に点を並べ、部屋の形の辺から6cm以内に来る点が多い順（半分以上の部屋だけ）。
 * 寸法で作った間取りの間仕切りのように両側の部屋に当たる時は、両方を候補にして先頭を選んでおく */
export function wallRooms(p, w) {
  const d = p.drawing, plan = d.plan; if (!plan) return [];
  const runs = w.pts && w.pts.length > 1 ? w.pts.slice(1).map((q, i) => [w.pts[i][0], w.pts[i][1], q[0], q[1]]) : (w.segs || []).map(i => plan.segs[i]).filter(Boolean);
  const pts = []; runs.forEach(s => { const L = segLen(s), n = Math.max(2, Math.ceil(L / 0.25)); for (let k = 0; k <= n; k++) { const t = (k + 0.5) / (n + 1); pts.push([s[0] + (s[2] - s[0]) * t, s[1] + (s[3] - s[1]) * t]); } });
  if (!pts.length) return [];
  const edgeD = (q, P) => { let m = 1e9; for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length], dx = b[0] - a[0], dy = b[1] - a[1], L2 = dx * dx + dy * dy, t = L2 ? Math.max(0, Math.min(1, ((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) / L2)) : 0; m = Math.min(m, Math.hypot(a[0] + t * dx - q[0], a[1] + t * dy - q[1])); } return m; };
  return p.rooms.filter(r => r.src === 'plan').map(r => {
    const F = (r.faces || []).map(i => plan.faces.find(f => f.i === i)).filter(Boolean);
    const hit = pts.filter(q => F.some(f => edgeD(q, f.poly) < 0.06)).length;
    return { r, k: hit / pts.length };
  }).filter(x => x.k >= 0.5).sort((a, b) => b.k - a.k).map(x => x.r);
}
const r3 = v => Math.round(v * 1000) / 1000;
/* 角の点で囲んだ広さ（㎡） */
export const polyArea = P => Math.abs(P.reduce((s, a, k) => { const b = P[(k + 1) % P.length]; return s + a[0] * b[1] - b[0] * a[1]; }, 0)) / 2;

/* 解体の行があれば、廃材処分の行を足す（前のKAKUと同じ：解体の面積×厚みから m³ を数える行。数量は解体が変わると付いて変わる）。足した行の数を返す */
export function syncWaste(p) {
  const add = missingWaste(p, masterItems());
  add.forEach(l => p.lines.push({ id: uid('l'), ...l }));
  return add.length;
}

/* 図面の壁の解体・カッターから、明細の行を作り直す（単価を変えていた行は単価を引き継ぐ） */
export function syncDemoLines(p) {
  const items = masterItems(), it = id => items.find(i => i.id === id);
  const old = new Map(p.lines.filter(l => l.fromDemo).map(l => [l.fromDemo, l]));
  p.lines = p.lines.filter(l => !l.fromDemo);
  const add = (key, id, qty, note, x = {}) => {
    const m = it(id); if (!m || !(qty > 0)) return;
    const o = old.get(key);
    p.lines.push({ id: o ? o.id : uid('l'), itemId: m.id, name: m.name, spec: [m.spec, note].filter(Boolean).join(' '), unit: m.unit, kind: m.kind, cat: m.cat, price: o ? o.price : (m.price || ''), cost: '', loss: o ? o.loss : '', sheet: m.sheet || 0, qty: r3(qty), basis: null, fromDemo: key, ...(x.loss ? { applyLoss: true } : {}) });
  };
  const d = p.drawing || {};
  /* 壁ごとに入れた分を、その部屋の壁の行（同じ種類）から引くための量 */
  p.rooms.forEach(r => { delete r.wallOff; });
  (d.walls || []).forEach(w => {
    const r = w.room && p.rooms.find(x => x.id === w.room); if (!r) return;
    const a = Math.max(0, w.len * w.h - (Number(w.open) || 0)), o = r.wallOff || (r.wallOff = {});
    if (w.itemId) o.demo = r3((o.demo || 0) + a);
    (w.more || []).filter(Boolean).forEach((id, k) => { const key = 'demo' + (k + 2); o[key] = r3((o[key] || 0) + a); });
    if (w.baseId) o.base = r3((o.base || 0) + a);
    if (w.finId) o.fin = r3((o.fin || 0) + a);
  });
  (d.walls || []).forEach(w => {
    const a = Math.max(0, w.len * w.h - (Number(w.open) || 0)), note = `長さ${r3(w.len)}m×高さ${r3(w.h)}m${Number(w.open) > 0 ? `−開口${r3(w.open)}㎡` : ''}${w.name ? '（' + w.name + '）' : ''}`;
    if (w.itemId) add('w|' + w.id, w.itemId, a, note);
    (w.more || []).filter(Boolean).forEach((id, k) => add(`wm|${w.id}|${k}`, id, a, note + `・下の層${k + 1}`));
    if (w.baseId) add('wb|' + w.id, w.baseId, a, note, { loss: true });
    if (w.finId) add('wf|' + w.id, w.finId, a, note, { loss: true });
  });
  const H = (d.hatsu || []).map(h => ({ h, c: hatsuCalc(h) })).filter(x => x.c.a > 0);
  if (H.length) {
    const cuts = {}, hz = {}, sum = { gara: 0, dig: 0, zando: 0, back: 0 };
    H.forEach(({ h, c }) => { if (c.cut > 0) cuts[cutItem(h.t)] = (cuts[cutItem(h.t)] || 0) + c.cut; hz[hatsuItem(h.t)] = (hz[hatsuItem(h.t)] || 0) + c.a; ['gara', 'dig', 'zando', 'back'].forEach(k => { sum[k] += c[k]; }); });
    if (Object.keys(cuts).length) add('h|base', 'w-cutBase', 1, 'カッター屋さんの出張・最低料金');
    Object.keys(cuts).sort().forEach(k => add('h|' + k, k, cuts[k], '切る所の周りの長さ'));
    Object.keys(hz).sort().forEach(k => add('h|' + k, k, hz[k], 'カッターの内側をはつる面積'));
    add('h|gara', 'w-gara', sum.gara, '幅×長さ×コンクリートの厚み');
    add('h|dig', 'w-kussaku', sum.dig, '幅×長さ×掘る深さ');
    add('h|zando', 'w-zando', sum.zando, `掘った量×${ZANDO_F}`);
    add('h|back', 'w-ume', sum.back, '掘った所を埋め戻す量');
  }
  /* 電気の図面から数えた物 */
  elecLines(p, add, it);
  /* 図面に置いた器具（1個ずつ・並べた物）：品目の数と取付手間 */
  const PC = placeCounts(d.places);
  Object.keys(PC).sort().forEach(k => { add('pl|' + k, k, PC[k], '図面に置いた物'); const lb = LABOR[k], m = lb && it(lb); if (m && m.kind === 'labor') add('pl|on|' + k, lb, PC[k], '図面に置いた物の取付'); });
  /* 照明・スイッチ・配線・分電盤 */
  const L = d.lights || [], O = d.outlets || [];
  if (O.length) {
    const byO = {}; O.forEach(x => { byO[x.item] = (byO[x.item] || 0) + 1; });
    Object.keys(byO).sort().forEach(k => add('o|' + k, k, byO[k], '図面のコンセント'));
    add('o|on', 'w-eDev', O.length, 'コンセントの取付');
  }
  if (L.length || O.length) {
    const byItem = {}; L.forEach(x => { byItem[x.item] = (byItem[x.item] || 0) + 1; });
    Object.keys(byItem).sort().forEach(k => { add('l|' + k, k, byItem[k], '図面の照明'); add('l|on|' + k, /^e-dl/.test(k) ? 'w-eDL' : 'w-eLight', byItem[k], '図面の照明'); });
    const W = lightWires(p);
    if (W.sw) { add('l|sw', W.ws.sw, W.sw, W.booths ? `入口のそばに1つ（トイレのブース ${W.booths} か所は外の部屋のスイッチで点ける）` : '照明のある区画ごとに入口のそばに1つ'); add('l|swOn', 'w-eDev', W.sw, 'スイッチの取付'); }
    add('l|vvf16', W.ws.cL, W.mL, `スイッチ→照明（縦横にたどった長さ＋立ち下がり＋1台0.2m、余り${W.extra}%）`);
    if (W.mH) add('l|vvf20', W.ws.cO, W.mH, `${O.length && W.ws.out ? 'コンセントの線（近い順に縦横の長さ＋立ち下がり）' : ''}${O.length && W.ws.out && panelsOf(d).length ? '・' : ''}${panelsOf(d).length ? '分電盤→各部屋（縦横の長さ＋立ち下がり。いちばん近い分電盤から）' : ''}、余り${W.extra}%`);
    { const np = panelsOf(d).length; if (np) { add('l|panel', 'e-panel', np, '図面で置いた分電盤'); add('l|panelOn', 'w-ePanel', np, ''); } }
    add('l|wire', 'w-eWire', W.mL + W.mH, 'ケーブルの合計');
  }
  syncWaste(p);
}

/* 配線の設定（前のKAKUの KW_set と同じ項目。移し忘れていた）：照明の線・コンセントと分電盤からの線のケーブル、自動で置くスイッチ、コンセントの線を長さに入れるか */
export const wireSetOf = d => ({ cL: 'e-v16-2', cO: 'e-v20-2', sw: 'e-sw1', out: true, ...((d && d.wireSet) || {}) });
/* 分電盤の一覧。前の版は1つだけ（drawing.panel = [x, y]）だったので、書き換える時は drawing.panels に移す */
export function panelsOf(d, write = false) {
  if (!d) return [];
  if (!d.panels && d.panel) { const P = [{ id: 'P1', x: d.panel[0], y: d.panel[1] }]; if (!write) return P; d.panels = P; }
  if (write) { d.panels = d.panels || []; d.panel = null; }
  return d.panels || [];
}
/* 配線：前のKAKUと同じ計算（js/lighting.js wirePlan）。区画ごとにスイッチを入口のそばに置き、縦横にたどった長さを出す */
export function lightWires(p) {
  const d = p.drawing || {}, ch0 = planCH(d.plan) || opts().ceilH;
  const chOf = fi => { const r = p.rooms.find(rr => rr.src === 'plan' && (rr.faces || []).includes(fi)); return (r && Number(r.h) > 0) ? Number(r.h) : ch0; };
  const W = wirePlan({ plan: d.plan || { faces: [] }, doors: d.doors || [], fixtures: d.fixtures || [], lights: (d.lights || []).map(x => ({ key: x.id, l: [x.x, x.y] })),
    outlets: (d.outlets || []).map(x => ({ key: x.id, l: [x.x, x.y] })), switches: (d.switches || []).map(x => ({ key: x.id, l: [x.x, x.y] })), link: d.link || {}, via: d.linkVia || {}, sheets: ((d.analysis && d.analysis.sheets) || []).filter(x => x && x.box && x.kind !== 'table'), panels: panelsOf(d).map(q => [q.x, q.y]), chOf });
  const extra = d.wireExtra ?? 10;
  const ws = wireSetOf(d);
  return { ...W, sw: W.sws.length, mL: cableQty(W.lenL, extra), mH: cableQty((ws.out ? W.lenO : 0) + W.lenH, extra), extra, ws };
}

/* 測る時のくっつき：線の端（近い順）→ 線の上 → そのまま（1mm単位） */
function snapPt(plan, x, y, tol) {
  let best = null, bd = tol;
  const segs = plan.segs;
  for (const s of segs) for (const q of [[s[0], s[1]], [s[2], s[3]]]) { const d = Math.hypot(q[0] - x, q[1] - y); if (d < bd) { bd = d; best = q; } }
  /* 線と線の交わる所（交点）にも吸い付く：近くの線どうしだけ調べる */
  const near = segs.filter(s => { const dx = s[2] - s[0], dy = s[3] - s[1], L2 = dx * dx + dy * dy; if (!L2) return false; const t = Math.max(0, Math.min(1, ((x - s[0]) * dx + (y - s[1]) * dy) / L2)); return Math.hypot(s[0] + t * dx - x, s[1] + t * dy - y) < tol; }).slice(0, 60);
  for (let i = 0; i < near.length; i++) for (let j = i + 1; j < near.length; j++) {
    const a = near[i], b = near[j], d1x = a[2] - a[0], d1y = a[3] - a[1], d2x = b[2] - b[0], d2y = b[3] - b[1], den = d1x * d2y - d1y * d2x;
    if (Math.abs(den) < 1e-12) continue;
    const t = ((b[0] - a[0]) * d2y - (b[1] - a[1]) * d2x) / den, u = ((b[0] - a[0]) * d1y - (b[1] - a[1]) * d1x) / den;
    if (t < -1e-9 || t > 1 + 1e-9 || u < -1e-9 || u > 1 + 1e-9) continue;
    const q = [a[0] + t * d1x, a[1] + t * d1y], d = Math.hypot(q[0] - x, q[1] - y);
    if (d < bd) { bd = d; best = q; }
  }
  if (best) return [Math.round(best[0] * 1e4) / 1e4, Math.round(best[1] * 1e4) / 1e4];
  bd = tol * 0.7;
  for (const s of segs) {
    const dx = s[2] - s[0], dy = s[3] - s[1], L2 = dx * dx + dy * dy; if (!L2) continue;
    const t = Math.max(0, Math.min(1, ((x - s[0]) * dx + (y - s[1]) * dy) / L2));
    const px = s[0] + t * dx, py = s[1] + t * dy, d = Math.hypot(px - x, py - y);
    if (d < bd) { bd = d; best = [px, py]; }
  }
  if (best) return best;
  return [Math.round(x * 1000) / 1000, Math.round(y * 1000) / 1000];
}

function stepRooms(ctx) {
  const { p, body, refresh } = ctx;
  const sel = new Set();
  let view = null;
  let mode = 'room', fsel = -1, symSel = -1, addAt = null, cutA = null, ltool = 'light', linkSel = null;
  let zoneSel = '', zsplit = null;   // ゾーン分け：選んでいるゾーン／線で分ける途中（{id, pts}）
  let zoneNameOnce = '';   // ゾーンから部屋を作る時、そのゾーンの名前を部屋の名前にする
  let holesOn = true, selGeoKey = '', selGeo = null;   // 選んでいる区画の中の「囲まれた所」を床に入れるか（部屋にする前に決める）
  let sheetZoom = '';   // 大きく出している図（図枠・段の位置のキー）。'' は全体
  const lset = state.lightSet || (state.lightSet = { room: 'all', use: '', item: 'e-dl100', lm: 800 });
  const wsel = new Set(), wpts = []; let wway = 'seg';
  let loway = 'line', loSel = -1, outA = null;   // 線を外す・工事対象外：選んだ線（plan.segs の番号）・範囲の1つ目の角
  const pset = state.placeSet || (state.placeSet = { item: 'e-hwh', where: 'pt', how: 'grid', cols: 2, rows: 2, gap: 1800, edge: '', n: 2 });
  const pfaces = new Set(), psegs = new Set(); let psel = null;
  const placeColor = id => { const ids = [...new Set((p.drawing.places || []).map(x => x.item))]; const k = ids.indexOf(id); return COLORS[(k < 0 ? ids.length : k) % COLORS.length]; };
  const itemName = id => { const m = masterItems().find(i => i.id === id); return m ? m.name + (m.spec ? ' ' + m.spec : '') : id; };
  const pOpts = () => ({ how: pset.how, cols: pset.cols, rows: pset.rows, gap: pset.gap, edge: pset.edge, n: pset.n });
  const pPreview = () => { const plan = p.drawing.plan; if (pset.where === 'line') return linePts([...psegs].map(i => plan.segs[i]).filter(Boolean), pOpts());
    if (pset.where === 'area') { const F = [...pfaces].map(i => plan.faces.find(f => f.i === i)).filter(Boolean).map(f => f.poly); return F.length ? areaPts(F, pOpts()) : []; } return []; };
  /* 照明・スイッチ・コンセント・置いた器具の印の大きさ。図面の大きさで決まる太さ（view.lw）を使うと、広い図面（3つの図が並ぶ物）で
     照明1つが直径2m 以上になり図面が埋まる。図面の縮尺に合わせ、1単位を 3cm までにする（照明の丸は直径 約54cm） */
  const symLw = () => Math.min(view.lw, 0.03);
  const placeOverlay = () => {
    const d = p.drawing, lw = symLw(), R = lw * 13;
    const sym = (id, q, c, rot, cls) => { const t = symText(id, itemName(id)); return `<g${cls ? ` class="${cls}"` : ''}${rot ? ` transform="rotate(${-rot} ${q[0]} ${-q[1]})"` : ''}><circle cx="${q[0]}" cy="${-q[1]}" r="${R}" fill="${c}" fill-opacity="${cls === 'new' ? .25 : .85}" stroke="${cls === 'new' ? '#fff' : c}" stroke-width="${lw * 1.6}"${cls === 'new' ? ` stroke-dasharray="${lw * 3} ${lw * 2}"` : ''}/><text x="${q[0]}" y="${-q[1]}" font-size="${R * (t.length > 2 ? .62 : t.length > 1 ? .8 : 1.05)}" text-anchor="middle" dominant-baseline="central" fill="#fff" font-weight="800">${esc(t)}</text>${rot ? `<line x1="${q[0]}" y1="${-q[1] - R}" x2="${q[0]}" y2="${-q[1] - R * 1.5}" stroke="${c}" stroke-width="${lw * 2}"/>` : ''}</g>`; };
    let h = '';
    if (mode === 'place') {
      pfaces.forEach(i => { const f = d.plan.faces.find(z => z.i === i); if (f) h += `<polygon points="${f.poly.map(q => `${q[0]},${-q[1]}`).join(' ')}" fill="var(--accent)" fill-opacity=".18" stroke="var(--accent)" stroke-width="${lw * 2}"/>`; });
      psegs.forEach(i => { const s0 = d.plan.segs[i]; if (s0) h += `<line x1="${s0[0]}" y1="${-s0[1]}" x2="${s0[2]}" y2="${-s0[3]}" stroke="var(--accent)" stroke-width="${lw * 7}" stroke-linecap="round"/>`; });
    }
    (d.places || []).forEach(x => { const c = placeColor(x.item); placePts(x).forEach(q => { if (x.id === psel) h += `<circle cx="${q[0]}" cy="${-q[1]}" r="${R * 1.8}" fill="none" stroke="var(--accent)" stroke-width="${lw * 3}"/>`; h += sym(x.item, q, c, +x.rot || 0); }); });
    if (mode === 'place') pPreview().forEach(q => { h += sym(pset.item, q, '#e65c32', 0, 'new'); });
    return h;
  };
  const prevWork = workNow && workNow(); let keep0 = null;
  if (prevWork && prevWork.pid === p.id) { mode = prevWork.mode; ltool = prevWork.ltool; wway = prevWork.wway; sheetZoom = prevWork.sheetZoom; keep0 = prevWork.v; }
  workNow = () => ({ pid: p.id, mode, ltool, wway, sheetZoom, v: view && view.keep ? view.keep() : keep0 });
  const meas = { pts: [], cont: false, redo: [] };   // redo：「1つ戻す」で消した点（「1つ進む」で戻す。新しく点を打つと消える）
  /* 新しい読み取りの印（「新しい読み取り」を選んだ図面だけ。選んでいなければ今まで通り何も出さない） */
  const r2marks = () => (p.drawing && p.drawing.reader === 'v2' && p.drawing.analysis && p.drawing.analysis.marks) || null;
  /* 区画の印：新しい読み取りの印（選んだ図面だけ）＋使わない図の中の区画（どちらの読み取りでも） */
  /* 今の読み取りでも、表題欄・表と言い切れる区画（解析の「除外」）は灰色にする（決めきれない「保留」は新しい読み取りの時だけ） */
  const outMarks = () => { const M = (p.drawing && p.drawing.analysis && p.drawing.analysis.marks) || {}, o = {}; Object.keys(M).forEach(k => { if (M[k] && M[k].s === 'out' && (M[k].type === 'title' || M[k].type === 'table')) o[k] = M[k]; }); return o; };
  /* 人が決めた印：「区画ではない」（drawing.faceOff）と「隣にまとめた」（drawing.faceJoin：区画 → まとめ先の区画）。いちばん強い */
  const handMarks = () => { const d = p.drawing || {}, o = {}, F = (d.plan && d.plan.faces) || [];
    Object.keys(d.faceOff || {}).forEach(k => { o[k] = { s: 'out', type: 'off', why: '「区画ではない」にした所です。もう一度選んで「元に戻す」で戻せます' }; });
    Object.entries(d.faceJoin || {}).forEach(([k, b]) => { const t = F.find(f => f.i === b); o[k] = { s: 'join', type: 'join', why: `区画${t ? t.no : ''} にまとめた所です。もう一度選んで「元に戻す」で戻せます` }; });
    return o; };
  /* 表・表題欄・「区画ではない」にした所は区画として出さず、図面に書いてある文字をその場所にそのまま出す（かつ「区画じゃないから文字出してもらいたい」）。
     文字は含む一番小さい区画に入れる。字の高さは図面から来ないので、同じ区画の中の行の間かくから決める */
  const TXT_TYPES = new Set(['table', 'title', 'off']);
  let ftKey = null, ftMap = null;
  const faceTexts = () => { const d = p.drawing || {}, F = (d.plan && d.plan.faces) || [], T = (d.src2 && d.src2.texts) || [];
    if (ftKey === F && ftMap) return ftMap; ftKey = F; ftMap = new Map(); if (!T.length || !F.length) return ftMap;
    T.forEach(t => { const s = normalizeText(t.t).trim(); if (!s) return; let best = null;
      F.forEach(f => { if (!f.poly || f.poly.length < 3 || (best && f.area >= best.area)) return; if (pip(t.x, t.y, f.poly)) best = f; });
      if (best) { const L = ftMap.get(best.i) || []; L.push({ s, x: t.x, y: t.y }); ftMap.set(best.i, L); } });
    ftMap.forEach((L, k) => { const f = F.find(z => z.i === k), xs = f.poly.map(q => q[0]), ys = f.poly.map(q => q[1]), x1 = Math.max(...xs), fh = Math.max(...ys) - Math.min(...ys);
      const rows = [...new Set(L.map(q => Math.round(q.y / 0.02)))].sort((a, b) => a - b); let gap = Infinity; for (let i = 1; i < rows.length; i++) gap = Math.min(gap, (rows[i] - rows[i - 1]) * 0.02);
      const h0 = Math.max(0.05, Math.min(0.4, isFinite(gap) ? gap * 0.7 : fh * 0.45));
      L.forEach(q => { const room = x1 - q.x; q.h = Math.max(0.03, Math.min(h0, room > 0 ? room / Math.max(1, wOf(q.s)) : h0)); }); });
    return ftMap; };
  /* 図面に書いてある文字を、元の図面と同じ場所に全部出す（かつ「あると元図面みたく使いやすくなる」）。表・表題欄の中は範囲のふちを越えないように。
     字の高さは図面から来ないので、近くの行（左右 2m 以内）との上下の間かくの7割（0.05〜0.4m）。右のとなりの文字を越えない（半角は幅0.6とみる） */
  let rtKey = null, rtList = null;
  const wOf = v => [...v].reduce((a, c) => a + (/[\x20-\x7e\uff61-\uff9f]/.test(c) ? 0.6 : 1), 0);
  const allTexts = () => { const d = p.drawing || {}, A = d.analysis || {}, T = (d.src2 && d.src2.texts) || [];
    if (rtKey === T && rtList) return rtList; rtKey = T; rtList = [];
    if (!T.length) return rtList;
    const B = (A.regions || []).filter(r => r && (r.type === 'table' || r.type === 'title') && r.box).map(r => r.box);
    const L = T.map(t => ({ s: normalizeText(t.t).trim(), x: +t.x, y: +t.y })).filter(q => q.s && isFinite(q.x) && isFinite(q.y));
    /* 2m のマス目に分けて、近くの文字だけ見る */
    const G = new Map(), key = (i, j) => i + ',' + j; L.forEach(q => { const k = key(Math.floor(q.x / 2), Math.floor(q.y / 2)); (G.get(k) || G.set(k, []).get(k)).push(q); });
    L.forEach(q => { const b = B.find(b => q.x >= b[0] && q.x <= b[2] && q.y >= b[1] && q.y <= b[3]);
      let gap = Infinity, right = b ? b[2] - q.x : Infinity; const gi = Math.floor(q.x / 2), gj = Math.floor(q.y / 2);
      for (let i = gi - 1; i <= gi + 1; i++) for (let j = gj - 1; j <= gj + 1; j++) (G.get(key(i, j)) || []).forEach(o => { if (o === q) return; const dy = Math.abs(o.y - q.y), dx = o.x - q.x; if (dy > 0.02 && Math.abs(dx) <= 2) gap = Math.min(gap, dy); if (dy <= 0.05 && dx > 0.02) right = Math.min(right, dx); });
      q.g = isFinite(gap) ? Math.max(0.05, Math.min(0.4, gap * 0.7)) : 0; q.r = right; });
    /* 近くに行が無い文字（寸法の数字など）は、図面の字の高さの真ん中にする。どの字も真ん中の2倍まで */
    const H = L.filter(q => q.g).map(q => q.g).sort((a, b) => a - b), med = H.length ? H[H.length >> 1] : 0.2;
    L.forEach(q => { const h0 = Math.min(q.g || med, med * 2); q.h = Math.max(0.03, Math.min(h0, isFinite(q.r) ? q.r / Math.max(1, wOf(q.s)) : h0)); delete q.g; delete q.r; });
    rtList = L; return rtList; };
  const textMarksOf = () => allTexts();
  const faceMarks = () => { const a = r2marks() || outMarks(), b = p.drawing ? sheetMarks(p.drawing) : {}, h = handMarks(); if (!(Object.keys(a).length || Object.keys(b).length || Object.keys(h).length)) return null;
    const o = { ...a, ...b, ...h };
    Object.keys(o).forEach(k => { if (o[k] && o[k].s === 'out' && TXT_TYPES.has(o[k].type)) o[k] = { ...o[k], hide: true }; });
    return o; };
  /* 区画のまとまりを決め直した部屋の広さ・周り・開口 */
  /* 区画のまとまりの広さ・周り。まとまりの中の穴（机などで切れてどの区画にも入らなかった所）も床の広さに足す（drawing.js の roomHoles） */
  const geoOf = (ids) => { const plan = p.drawing.plan, S = new Set(ids), F = ids.map(i => plan.faces.find(f => f.i === i)).filter(Boolean), g = groupGeom(F);
    let h = { area: 0, runs: [] }; try { h = roomHoles(F, plan.faces.filter(f => !S.has(f.i)), plan.segs || [], fxList()); } catch (e) { console.warn('穴を数えられませんでした', e); }
    const o = outOf(F);
    const out = { area: Math.round((g.area + h.area - o.area) * 100) / 100, perim: Math.round((g.perim - o.perim) * 100) / 100, holes: h.area > 0 ? { area: h.area, cs: h.cs, runs: h.runs } : null, out: o.area > 0 || o.perim > 0 ? o : null };
    /* 手入力の換算係数がある時だけ、広さ・周り（工事対象外の分も）を実寸に直す（自動の値では直さない。
     * 座標（holes.runs）は絵の位置なので変えない。むぎの sw.56 と工事対象外の範囲を合わせた） */
    const k = userCoef(p.drawing);
    if (!k) return out; const sg = scaleGeomBy(out, k); if (sg.out) sg.out = { ...sg.out, area: Math.round(sg.out.area * k * k * 100) / 100, perim: Math.round(sg.out.perim * k * 100) / 100 }; return sg; };
  /* 工事対象外の範囲（drawing.outZones）：部屋の区画と重なる広さ（床・天井から引く）と、部屋のまわりの線のうち範囲の中にある長さ（壁・巾木から引く）。
   * 10cm のマスと 5cm ごとの点で数える。区画どうしが接する所（両側とも部屋の区画）は、まわりに数えない（かつ・2026-11-24） */
  const outOf = (F) => { const Z = (p.drawing && p.drawing.outZones) || [], r = { area: 0, perim: 0 }; if (!Z.length || !F.length) return r;
    const inF = (x, y) => F.some(f => f.poly && pip(x, y, f.poly)), inZ = (x, y) => Z.some(z => pip(x, y, z.poly));
    Z.forEach(z => { let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity; z.poly.forEach(q => { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); });
      const st = 0.1; for (let y = y0 + st / 2; y < y1; y += st) for (let x = x0 + st / 2; x < x1; x += st) if (pip(x, y, z.poly) && inF(x, y)) r.area += st * st; });
    F.forEach(f => { const P = f.poly || []; for (let k = 0; k < P.length; k++) { const a = P[k], b = P[(k + 1) % P.length], L = Math.hypot(b[0] - a[0], b[1] - a[1]); if (L < 1e-6) continue;
      const nx = -(b[1] - a[1]) / L, ny = (b[0] - a[0]) / L, n = Math.max(1, Math.round(L / 0.05));
      for (let j = 0; j < n; j++) { const t = (j + 0.5) / n, x = a[0] + (b[0] - a[0]) * t, y = a[1] + (b[1] - a[1]) * t; if (!inZ(x, y)) continue;
        if (inF(x + nx * 0.15, y + ny * 0.15) && inF(x - nx * 0.15, y - ny * 0.15)) continue; r.perim += L / n; } } });
    r.area = Math.round(r.area * 100) / 100; r.perim = Math.round(r.perim * 100) / 100; return r; };
  const setGeo = (r) => { const g = geoOf(r.faces); r.area = r.noHoles && g.holes ? Math.round((g.area - g.holes.area) * 100) / 100 : g.area; r.perim = g.perim; if (g.holes) r.holes = g.holes; else delete r.holes; if (g.out) r.out = g.out; else delete r.out; };
  const regeo = (r) => { const plan = p.drawing.plan; setGeo(r); if (p.drawing.open) r.openRuns = roomOpenRuns(r.faces, plan, p.drawing.open); };
  const outRegeo = () => { p.rooms.forEach(r => { if (r.src === 'plan' && r.faces && r.faces.length) setGeo(r); }); };
  /* ある区画の隣の区画（接している長さがいちばん長い物）。辺の両側 20cm の点を調べる */
  /* ほかの区画を2つ以上中に含む区画（図枠の内側・建物の外まわり）。まとめ先にしない */
  const wrapsF = (f, F) => { if (!f.poly || f.poly.length < 3) return false; let k = 0; for (const o of F) { if (o !== f && o.area < f.area && pip(o.cx, o.cy, f.poly) && ++k >= 2) return true; } return false; };
  const nbOf = (f) => { const F = p.drawing.plan.faces, off = p.drawing.faceOff || {}, cnt = new Map(), P = f.poly, mk = faceMarks() || {}, W = new Map(), isW = o => { if (!W.has(o.i)) W.set(o.i, wrapsF(o, F)); return W.get(o.i); };
    for (let k = 0; k < P.length; k++) { const a = P[k], b = P[(k + 1) % P.length], L = Math.hypot(b[0] - a[0], b[1] - a[1]); if (L < 1e-6) continue;
      const nx = -(b[1] - a[1]) / L, ny = (b[0] - a[0]) / L, n = Math.max(1, Math.round(L / 0.15));
      for (let j = 0; j < n; j++) { const t = (j + 0.5) / n, x = a[0] + (b[0] - a[0]) * t, y = a[1] + (b[1] - a[1]) * t;
        for (const sg of [1, -1]) { const qx = x + nx * 0.2 * sg, qy = y + ny * 0.2 * sg; if (pip(qx, qy, P)) continue;
          /* その点を含む区画のうち一番小さい物（図枠の内側のような、全部を囲む大きい区画を選ばない） */
          let g = null; for (const o of F) if (o !== f && !off[o.i] && !(mk[o.i] && mk[o.i].s === 'out') && o.poly && (!g || o.area < g.area) && pip(qx, qy, o.poly) && !isW(o)) g = o;
          if (g) cnt.set(g.i, (cnt.get(g.i) || 0) + L / n); } } }
    let best = null, bl = 0; cnt.forEach((v, i) => { if (v > bl) { bl = v; best = i; } }); return best; };
  /* まとめ先をたどった先（まとめ先がさらにまとめられている時） */
  const joinRoot = (i) => { const J = p.drawing.faceJoin || {}; let k = 0; while (J[i] != null && k++ < 20) i = J[i]; return i; };
  /* 部屋の区画に、そこへまとめた区画を足す */
  const withJoined = (ids) => { const J = p.drawing.faceJoin || {}, S = new Set(ids); let more = true; while (more) { more = false; Object.entries(J).forEach(([a, b]) => { if (S.has(b) && !S.has(+a)) { S.add(+a); more = true; } }); } return [...S]; };
  const FIX_SIZE = { toilet: [0.46, 0.8], urinal: [0.4, 0.36], counter: [1.2, 0.5], sink: [0.45, 0.36], slop: [0.8, 0.52], trough: [3.6, 0.6], bath: [1.6, 1.6], kitchen: [2.55, 0.65] };
  const BACKS = [['N', '上'], ['E', '右'], ['S', '下'], ['W', '左']];
  const fxList = () => (p.drawing && p.drawing.fixtures) || [];
  /* 図面に出す器具：タイプ補正がある物は補正後の種類で描く（保存データはそのまま。
   * 並びと数は fxList と同じなので、タップの番号もそのまま合う） */
  const fxDisplayList = () => { const fx = fxList(); if (!p.drawing) return fx; const TF = typeFixMap(p.drawing), inReg = fixturesInRegions(p.drawing); return fx.map((x, k) => inReg[k] ? { ...x, t: 'other', ot: x.t } : (TF[k] && TF[k].shown) ? { ...x, t: TF[k].shown, ot: x.t } : x); };
  const owner = () => { const m = new Map(); p.rooms.forEach(r => (r.faces || []).forEach(i => m.set(i, r.color)));
    /* 隣にまとめた区画は、まとめ先の部屋の色で出す */
    Object.entries((p.drawing && p.drawing.faceJoin) || {}).forEach(([a, b]) => { if (!m.has(+a) && m.has(b)) m.set(+a, m.get(b)); });
    return m; };
  /* 線を外す：選んだ線と同じ種類の線（橙）、外すことにした線（赤の点線）、もう外した線（灰の点線）。工事対象外の範囲（斜線） */
  const loOverlay = () => {
    const d = p.drawing; if (!d || !d.plan) return '';
    const lw = view ? view.lw : 0.02, ln = (q, c, w, dash) => `<line x1="${q[0]}" y1="${-q[1]}" x2="${q[2]}" y2="${-q[3]}" stroke="${c}" stroke-width="${w}" vector-effect="non-scaling-stroke" ${dash ? 'stroke-dasharray="6 4"' : ''} stroke-linecap="round"/>`;
    let h = '';
    if (mode === 'lineoff') {
      (d.plan.offSegs || []).forEach(q => { h += ln(q, '#9aa0a6', 1.5, true); });
      const LO = d.lineOff || {}, K = new Set(LO.keys || []);
      if (K.size && d.plan.gk && d.plan.sg) d.plan.segs.forEach((q, i) => { if (K.has(d.plan.gk[d.plan.sg[i]])) h += ln(q, '#d93025', 2.5, true); });
      (LO.segs || []).forEach(q => { h += ln(q, '#d93025', 3, true); });
      if (loSel >= 0 && d.plan.segs[loSel]) { const k = d.plan.sg ? d.plan.sg[loSel] : -1; if (k >= 0) d.plan.segs.forEach((q, i) => { if (d.plan.sg[i] === k && i !== loSel) h += ln(q, '#f29900', 2.5); }); h += ln(d.plan.segs[loSel], '#e8710a', 5); }
      if (outA) h += `<circle cx="${outA[0]}" cy="${-outA[1]}" r="${lw * 6}" fill="#d93025"/>`;
    }
    (d.outZones || []).forEach((z, k) => { const pts = z.poly.map(q => `${q[0]},${-q[1]}`).join(' '); let x0 = Infinity, y1 = -Infinity, x1 = -Infinity; z.poly.forEach(q => { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); });
      h += `<polygon points="${pts}" fill="url(#outHatch)" stroke="#d93025" stroke-width="2" vector-effect="non-scaling-stroke" stroke-dasharray="8 4"/><text x="${x0 + 0.15}" y="${-y1 + Math.min(0.5, (x1 - x0) / 8) + 0.1}" font-size="${Math.min(0.5, Math.max(0.15, (x1 - x0) / 10))}" fill="#d93025">工事対象外 ${k + 1}</text>`; });
    return h ? `<defs><pattern id="outHatch" width="0.3" height="0.3" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="0.3" stroke="#d93025" stroke-width="0.03" opacity="0.5"/></pattern></defs>` + h : '';
  };
  const demoOverlay = () => {
    const lw = symLw(), plan = p.drawing.plan, d = p.drawing;
    let h = '';
    /* 部屋の床に足した穴（机などの所）も、部屋の色で塗る（どこを部屋にしたか分かるように） */
    p.rooms.forEach(r => { if (!r.holes || !r.holes.runs || !r.holes.runs.length || r.src !== 'plan' || r.noHoles) return; const cs = r.holes.cs;
      h += `<path d="${r.holes.runs.map(q => `M${q[0]} ${-(q[2] + cs)}H${q[1]}V${-q[2]}H${q[0]}Z`).join('')}" fill="${roomColor(r.color)}" fill-opacity=".22" stroke="none" pointer-events="none"/>`; });
    (d.walls || []).forEach(w => (w.segs || []).forEach(i => { const s = plan.segs[i]; if (s) h += `<line x1="${s[0]}" y1="${-s[1]}" x2="${s[2]}" y2="${-s[3]}" stroke="#ff6b6b" stroke-width="${lw * 7}" stroke-linecap="round" opacity=".75"/>`; }));
    wsel.forEach(i => { const s = plan.segs[i]; if (s) h += `<line x1="${s[0]}" y1="${-s[1]}" x2="${s[2]}" y2="${-s[3]}" stroke="var(--accent)" stroke-width="${lw * 7}" stroke-linecap="round"/>`; });
    (d.walls || []).forEach(w => { if (w.pts && w.pts.length > 1) h += `<polyline points="${w.pts.map(q => `${q[0]},${-q[1]}`).join(' ')}" fill="none" stroke="${w.itemId ? '#ff6b6b' : '#5ab7ff'}" stroke-width="${lw * 7}" stroke-linecap="round" stroke-linejoin="round" opacity=".75"/>`; });
    if (mode === 'wall' && wpts.length) { h += `<polyline points="${wpts.map(q => `${q[0]},${-q[1]}`).join(' ')}" fill="none" stroke="var(--accent)" stroke-width="${lw * 7}" stroke-linecap="round" stroke-linejoin="round"/>`; wpts.forEach(q => { h += `<circle cx="${q[0]}" cy="${-q[1]}" r="${lw * 6}" fill="var(--accent)"/>`; }); }
    (d.hatsu || []).forEach(x => { if (!x.rect) return; const [a, b, c, e] = x.rect; h += `<rect x="${a}" y="${-e}" width="${c - a}" height="${e - b}" fill="#ff8a3d" fill-opacity=".18" stroke="#ff8a3d" stroke-width="${lw * 3}" stroke-dasharray="${lw * 6} ${lw * 4}"/>`; });
    if (cutA) h += `<circle cx="${cutA[0]}" cy="${-cutA[1]}" r="${lw * 6}" fill="var(--accent)"/>`;
    if (zsplit && zsplit.pts.length) { h += `<polyline points="${zsplit.pts.map(q => `${q[0]},${-q[1]}`).join(' ')}" fill="none" stroke="var(--accent)" stroke-width="${lw * 7}" stroke-linecap="round" stroke-linejoin="round"/>`; zsplit.pts.forEach(q => { h += `<circle cx="${q[0]}" cy="${-q[1]}" r="${lw * 6}" fill="var(--accent)"/>`; }); }
    if ((d.lights || []).length || panelsOf(d).length || (d.outlets || []).length || (d.switches || []).length) {
      const W = lightWires(p);
      const pd = pts => 'M' + pts.map(q => `${q[0]} ${-q[1]}`).join('L');
      W.paths.forEach(w => { h += `<path d="${pd(w.pts)}" fill="none" stroke="#f3c04f" stroke-width="${lw * 1.6}" stroke-dasharray="${lw * 5} ${lw * 3}" opacity=".8"/>`; });
      W.home.forEach(w => { h += `<path d="${pd(w.pts)}" fill="none" stroke="#c084fc" stroke-width="${lw * 1.6}" stroke-dasharray="${lw * 5} ${lw * 3}" opacity=".8"/>`; });
      const swAll = [...W.sws, ...(d.switches || []).filter(x => !W.sws.some(s0 => s0.key === x.id)).map(x => ({ key: x.id, l: [x.x, x.y] }))];
      swAll.forEach(s0 => { const q = s0.l, mine = !s0.auto; h += `<rect x="${q[0] - lw * 7}" y="${-q[1] - lw * 7}" width="${lw * 14}" height="${lw * 14}" fill="${mine ? '#5ab7ff' : '#f3c04f'}"/><text x="${q[0]}" y="${-q[1]}" font-size="${lw * 10}" text-anchor="middle" dominant-baseline="central" fill="#111" font-weight="800">S</text>`; });
      (d.lights || []).forEach(x => { const on = linkSel === x.id; h += `<circle cx="${x.x}" cy="${-x.y}" r="${lw * (on ? 13 : 9)}" fill="#f3c04f" fill-opacity=".35" stroke="${on ? 'var(--accent)' : '#f3c04f'}" stroke-width="${lw * (on ? 3.5 : 2.2)}"/><circle cx="${x.x}" cy="${-x.y}" r="${lw * 3}" fill="#f3c04f"/>`; });
      (d.outlets || []).forEach(x => { h += `<circle cx="${x.x}" cy="${-x.y}" r="${lw * 7}" fill="#3ccf8e" fill-opacity=".3" stroke="#3ccf8e" stroke-width="${lw * 2}"/><line x1="${x.x - lw * 2.5}" y1="${-x.y - lw * 3}" x2="${x.x - lw * 2.5}" y2="${-x.y + lw * 3}" stroke="#3ccf8e" stroke-width="${lw * 1.6}"/><line x1="${x.x + lw * 2.5}" y1="${-x.y - lw * 3}" x2="${x.x + lw * 2.5}" y2="${-x.y + lw * 3}" stroke="#3ccf8e" stroke-width="${lw * 1.6}"/>`; });
      /* 分電盤：長方形を対角線で分けて片側を塗る（前のKAKUと同じ形）。向き（rot）で回す。字は回さない */
      panelsOf(d).forEach(q => { const w2 = lw * 12, h2 = lw * 7; h += `<g transform="rotate(${-(q.rot || 0)} ${q.x} ${-q.y})"><rect x="${q.x - w2}" y="${-q.y - h2}" width="${w2 * 2}" height="${h2 * 2}" fill="#fff" stroke="#c084fc" stroke-width="${lw * 1.5}"/><path d="M${q.x - w2} ${-q.y + h2} L${q.x + w2} ${-q.y - h2} L${q.x + w2} ${-q.y + h2} Z" fill="#c084fc"/></g><text x="${q.x}" y="${-q.y - h2 - lw * 4}" font-size="${lw * 7}" text-anchor="middle" fill="#c084fc" font-weight="800" stroke="var(--bg)" stroke-width="${lw * 1.2}" paint-order="stroke">分電盤</text>`; });
    }
    return h;
  };
  const measOverlay = () => {
    if (!view) return '';
    const lw = view.lw, P = meas.pts;
    if (!P.length) return '';
    /* 線・点・長さの字は、拡大しても画面で同じ大きさ（かつ「字が大きすぎて次押したいところ見れない」）。長さの字は線の少し上に小さく出す（下の欄にも出ている） */
    let h = `<polyline points="${P.map(q => q[0] + ',' + -q[1]).join(' ')}" fill="none" stroke="var(--accent)" stroke-width="3" vector-effect="non-scaling-stroke"/>`;
    P.forEach(q => { h += `<circle cx="${q[0]}" cy="${-q[1]}" r="${lw * 5}" data-r="5" fill="var(--accent)"/>`; });
    if (P.length > 1) { const a = P[P.length - 2], b = P[P.length - 1]; h += `<text x="${(a[0] + b[0]) / 2}" y="${-(a[1] + b[1]) / 2}" dy="-0.7em" font-size="${lw * 6}" data-px="14" fill="var(--accent)" stroke="var(--bg)" stroke-width="${lw * 1.5}" paint-order="stroke" text-anchor="middle" font-weight="800" pointer-events="none">${Math.hypot(b[0] - a[0], b[1] - a[1]).toFixed(3)}m</text>`; }
    if (addAt) h += `<circle cx="${addAt[0]}" cy="${-addAt[1]}" r="${lw * 6}" data-r="7" fill="none" stroke="var(--accent)" stroke-width="2.5" vector-effect="non-scaling-stroke"/>`;
    return h;
  };
  const wallRoomSel = (id, cur, guess = []) => { const pr = p.rooms.filter(r => r.src === 'plan'), ids = new Set(guess.map(r => r.id)), order = [...guess, ...pr.filter(r => !ids.has(r.id))];
    return `<select class="in" ${id ? `id="${id}"` : 'data-wk="room"'} style="min-height:40px"><option value="">部屋の壁から引かない</option>${order.map(r => `<option value="${esc(r.id)}" ${r.id === cur ? 'selected' : ''}>${esc(r.name)}${ids.has(r.id) ? '（図で当たった部屋）' : ''}</option>`).join('')}</select>`; };
  const demoList = () => {
    const d = p.drawing; if (!d) return '';
    const W = d.walls || [], H = d.hatsu || [];
    if (!W.length && !H.length) return '';
    const it = id => masterItems().find(i => i.id === id);
    return `<div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--line);display:grid;gap:8px">
      ${W.map(w => `<div class="card" style="padding:10px" data-wall="${w.id}"><div class="row small">
        ${w.itemId ? `<span class="pill bad">解体 ${esc((it(w.itemId) || {}).name || '')}</span>` : ''}${w.baseId ? `<span class="pill info">下地 ${esc((it(w.baseId) || {}).name || '')}</span>` : ''}${(w.more || []).map((id, k) => `<span class="pill bad">下の層${k + 1} ${esc((it(id) || {}).name || '')} <button class="linkbtn" data-act="wMoreDel" data-k="${k}" aria-label="消す">×</button></span>`).join('')}${w.finId ? `<span class="pill acc">仕上げ ${esc((it(w.finId) || {}).name || '')}</span>` : ''}${w.name ? `<b>${esc(w.name)}</b>` : ''}
        <span class="spacer"></span><button class="iconbtn" data-act="wallDel" aria-label="この壁を消す">${icon('trash')}</button></div>
        <div class="row small" style="margin-top:6px"><span>長さ ${r3(w.len)}m × 高さ</span><div class="unitwrap" style="width:120px"><input class="in num" data-wk="h" type="number" inputmode="decimal" step="0.01" value="${w.h}" style="min-height:36px"><span>m</span></div>
        <span>− 開口</span><div class="unitwrap" style="width:120px"><input class="in num" data-wk="open" type="number" inputmode="decimal" step="0.01" value="${w.open || 0}" style="min-height:36px"><span>㎡</span></div><b>＝ ${r3(Math.max(0, w.len * w.h - (Number(w.open) || 0)))}㎡</b></div>
        <div class="row small" style="margin-top:6px"><span class="muted">下の層も解体</span><select class="in" data-wk="more" style="min-height:36px;width:auto"><option value="">＋ 層を足す</option>${masterItems().filter(i => i.cat === 'demoW' && i.unit === '㎡').map(i => `<option value="${esc(i.id)}">${esc(i.name)}</option>`).join('')}</select></div>
        <div class="row small" style="margin-top:6px"><span class="muted">部屋の壁から引く</span><div style="min-width:220px">${wallRoomSel('', w.room || '', wallRooms(p, w))}</div></div></div>`).join('')}
      ${H.map(h => { const c = hatsuCalc(h); return `<div class="card" style="padding:10px" data-hatsu="${h.id}"><div class="row small"><span class="pill acc">カッター</span><b>幅 ${r3(h.w)}m × 長さ ${r3(h.l)}m</b>
        <label class="row muted" style="gap:4px">厚み<div class="unitwrap" style="width:130px"><input class="in num" data-hk="t" type="number" inputmode="numeric" value="${h.t}" style="min-height:36px"><span>mm</span></div></label>
        <label class="row muted" style="gap:4px">掘る深さ<div class="unitwrap" style="width:130px"><input class="in num" data-hk="d" type="number" inputmode="numeric" value="${h.d}" style="min-height:36px"><span>mm</span></div></label>
        <label class="row muted" style="gap:4px"><input type="checkbox" data-hk="cut" ${h.cut !== false ? 'checked' : ''} style="width:18px;height:18px">カッター</label>
        <label class="row muted" style="gap:4px"><input type="checkbox" data-hk="back" ${h.back !== false ? 'checked' : ''} style="width:18px;height:18px">埋め戻し</label>
        <span class="spacer"></span><button class="iconbtn" data-act="hatsuDel" aria-label="このカッターを消す">${icon('trash')}</button></div>
        <div class="chips">${`<span class="chip">はつり <b>${c.a}</b>㎡</span>` + (c.cut ? `<span class="chip">カッター <b>${c.cut}</b>m</span>` : '') + `<span class="chip">ガラ <b>${c.gara}</b>m³</span>` + (c.dig ? `<span class="chip">掘削 <b>${c.dig}</b>m³</span><span class="chip">残土 <b>${c.zando}</b>m³</span>` : '') + (c.back ? `<span class="chip">埋め戻し <b>${c.back}</b>m³</span>` : '')}</div></div>`; }).join('')}
      <div class="small muted">ここで入れた分は、③工事の明細に自動で入ります（変えると明細も変わります）。</div></div>`;
  };
  const paintSel = () => {
    if (!p.drawing || !p.drawing.plan) return;
    $$('#dwgMode button', body).forEach(b => b.classList.toggle('on', b.dataset.mode === mode));
    if (dwgFs) { const on = body.querySelector('#dwgMode button.on'), st = body.querySelector('#dwgMode'); if (on && st && (on.offsetLeft < st.scrollLeft || on.offsetLeft + on.offsetWidth > st.scrollLeft + st.clientWidth)) { const ex = st.querySelector('.fs-exit'); st.scrollLeft = on.offsetLeft - (ex ? ex.offsetWidth + 8 : 0); } }
    /* 部屋を作るで区画を選んでいる間は、選んだ区画の中の「囲まれた所」（机・棚など）を先に見せる（部屋にした後で分かるのではなく、決める前に） */
    let selHoles = '';
    if (mode === 'room' && sel.size) { const key = [...sel].sort((a, b) => a - b).join(',') + '|' + (userCoef(p.drawing) || ''); if (key !== selGeoKey) { selGeoKey = key; selGeo = geoOf(withJoined([...sel])); }
      if (selGeo && selGeo.holes && holesOn) { const cs = selGeo.holes.cs; selHoles = `<path d="${selGeo.holes.runs.map(q => `M${q[0]} ${-(q[2] + cs)}H${q[1]}V${-q[2]}H${q[0]}Z`).join('')}" fill="var(--accent)" fill-opacity=".35" stroke="none" pointer-events="none"/>`; } }
    else { selGeoKey = ''; selGeo = null; }
    if (view) { view.paint(); view.overlay(selHoles + sheetOverlay(p.drawing, view.lw, allTexts()) + demoOverlay() + placeOverlay() + loOverlay() + (mode === 'meas' || addAt ? measOverlay() : '')); }
    const demoBox = body.querySelector('#dwgDemo'); if (demoBox) demoBox.innerHTML = demoList();
    const fxBox = body.querySelector('#dwgFix'); if (fxBox) fxBox.innerHTML = fixSummary(p.drawing);
    const symBox = body.querySelector('#dwgSym'); if (symBox) symBox.innerHTML = symSummary(p.drawing, symSel);
    const roomBox = body.querySelector('#dwgRoom'); if (roomBox) roomBox.innerHTML = roomSummary(p.drawing);
    const zoneBox = body.querySelector('#dwgZone'); if (zoneBox) zoneBox.innerHTML = zoneSummary(p.drawing, zoneSel);
    const dimBox = body.querySelector('#dwgDim'); if (dimBox) dimBox.innerHTML = dimSummary(p.drawing);
    if (mode !== 'room') {
      const bar = body.querySelector('#dwgBar');
      if (mode === 'wall') {
        const len = wway === 'seg' ? [...wsel].reduce((a, i) => a + segLen(p.drawing.plan.segs[i]), 0) : wpts.reduce((a, q, i) => i ? a + Math.hypot(q[0] - wpts[i - 1][0], q[1] - wpts[i - 1][1]) : 0, 0);
        const dh = planCH(p.drawing.plan) || opts().ceilH, M = masterItems(), ls = state.wallSet || (state.wallSet = { demo: 'w-dW-cloth', base: '', fin: '' });
        const sel = (id, list, cur, none) => `<select class="in" id="${id}" style="min-height:40px">${none ? `<option value="">${none}</option>` : ''}${list.map(i => `<option value="${esc(i.id)}" ${i.id === cur ? 'selected' : ''}>${esc(i.name)}${i.spec ? ' ' + esc(i.spec) : ''}（${yen(i.price)}/${esc(i.unit)}）</option>`).join('')}</select>`;
        const has = wway === 'seg' ? wsel.size > 0 : wpts.length > 1;
        bar.innerHTML = `<div class="seg" style="width:100%">${[['seg', '線をタップ'], ['range', 'ここからここまで']].map(t => `<button data-wway="${t[0]}" class="${wway === t[0] ? 'on' : ''}">${t[1]}</button>`).join('')}</div>
          <div class="small" style="width:100%">${wway === 'seg' ? '解体・仕上げをする壁の線をタップして選んでください（何本でも）。' : '壁の始まりと終わりをタップしてください。角を回る時は角もタップ（測るのと同じく、線の端・線の上にくっつきます）。'}
            ${has ? `<b>選んだ長さ ${len.toFixed(3)} m</b>` : ''}</div>
          ${has ? `<div class="grid g4" style="width:100%;align-items:end">
            <label class="f">高さ<div class="unitwrap"><input class="in num" id="wH" type="number" inputmode="decimal" step="0.01" value="${dh}"><span>m</span></div></label>
            <label class="f">引く開口<span class="hint">窓・ドアなど</span><div class="unitwrap"><input class="in num" id="wOpen" type="number" inputmode="decimal" step="0.01" value="0"><span>㎡</span></div></label>
            <label class="f" style="grid-column:span 2">どの部屋の壁か<span class="hint">③工事のその部屋の壁から、同じ種類の分を引きます</span>${wallRoomSel('wRoom', wallRooms(p, wway === 'seg' ? { segs: [...wsel] } : { pts: wpts }).map(r => r.id)[0] || '', wallRooms(p, wway === 'seg' ? { segs: [...wsel] } : { pts: wpts }))}</label>
            <label class="f" style="grid-column:span 4">メモ（どの壁か）<input class="in" id="wName" placeholder="例：LDK 北の壁"></label></div>
          <div class="grid g3" style="width:100%">
            <label class="f">解体${sel('wItem', M.filter(i => i.cat === 'demoW'), ls.demo, '解体しない')}</label>
            <label class="f">下の層も解体<span class="hint">タイルの下のブロックなど</span>${sel('wMore', M.filter(i => i.cat === 'demoW' && i.unit === '㎡'), '', 'なし')}</label>
            <label class="f">下地${sel('wBase', M.filter(i => i.cat === 'board'), ls.base, '下地なし')}</label>
            <label class="f">仕上げ${sel('wFin', M.filter(i => i.cat === 'wall' || i.cat === 'paint'), ls.fin, '仕上げなし')}</label></div>
          <button class="btn sm primary" data-act="wallAdd">${icon('plus')}この壁を明細に入れる</button><button class="btn sm ghost" data-act="wallClear">選び直す</button>
          <div class="small muted" style="width:100%">面積＝長さ×高さ−開口。下地・仕上げはロス込みで入ります。③工事でその部屋の壁全体に入れている解体・下地・仕上げの行からは、ここで入れた分を自動で引きます。</div>` : ''}`;
        return;
      }
      if (mode === 'light') {
        const pr = p.rooms.filter(r => r.src === 'plan');
        const lightItems = masterItems().filter(i => /^e-(dl|clight|bl|base)/.test(i.id));
        const W = lightWires(p), n = (p.drawing.lights || []).length;
        const res = pr.map(r => { const k = (p.drawing.lights || []).filter(x => x.room === r.id).length; if (!k) return ''; const u = r.lightUse || ''; const F = (r.faces || []).map(i => p.drawing.plan.faces.find(f => f.i === i)).filter(Boolean); const lx = u && F[0] ? Math.round(luxOf(F[0].poly, Number(r.h) || planCH(p.drawing.plan) || opts().ceilH, u, r.lightLm || 800, k, Number(r.area) || F.reduce((t, f) => t + (f.area || 0), 0), Number(r.perim) || 0) / 10) * 10 : 0; const tgt = (USES.find(x => x[0] === u) || [])[2]; return `<span class="pill ${lx && tgt && lx < tgt * 0.95 ? 'warn' : 'info'}">${esc(r.name)} ${k}台${lx ? `・約${lx}lx（目標${tgt}）` : ''}</span>`; }).join('');
        const hasOut = (p.drawing.fixtures || []).some(x => x.out || ((x.t === 'toilet' || x.t === 'counter') && x.back));
        if (!pr.length && lset.room !== 'faces') lset.room = 'faces';
        bar.innerHTML = `
          <div class="grid g4" style="width:100%;align-items:end">
            <label class="f">並べる所<select class="in" id="lRoom"><option value="faces" ${lset.room === 'faces' ? 'selected' : ''}>図面の区画 全部${pr.length ? '（部屋にしていない所も）' : ''}</option>${pr.length ? `<option value="all" ${lset.room === 'all' ? 'selected' : ''}>部屋にした所 全部</option>` : ''}${pr.map(r => `<option value="${esc(r.id)}" ${lset.room === r.id ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select></label>
            <label class="f">部屋の用途<select class="in" id="lUse">${USES.map(u => `<option value="${u[0]}" ${lset.use === u[0] ? 'selected' : ''}>${u[1]}${u[2] ? `（${u[2]}lx）` : ''}</option>`).join('')}</select></label>
            <label class="f">照明器具<select class="in" id="lItem">${lightItems.map(i => `<option value="${esc(i.id)}" ${lset.item === i.id ? 'selected' : ''}>${esc(i.name)}</option>`).join('')}</select></label>
            <label class="f">1台の明るさ<span class="hint">カタログの器具光束</span><div class="unitwrap"><input class="in num" id="lLm" type="number" inputmode="numeric" value="${lset.lm}"><span>lm</span></div></label>
            <label class="f">照明の間隔の目安<span class="hint">天井が高い所は自動で詰めます</span><div class="unitwrap"><input class="in num" id="lPitch" type="number" inputmode="decimal" step="0.1" min="0.9" max="6" value="${lset.pitch || 2}"><span>m</span></div></label></div>
          <button class="btn sm primary" data-act="lAuto" data-out="${hasOut ? 1 : ''}">${icon('spark')}${hasOut ? '照明を自動で並べる（便器・洗面台などのコンセントも置きます）' : '照明を自動で並べる'}</button>
          ${hasOut ? `<button class="btn sm" data-act="oAuto">コンセントだけ置き直す</button>` : ''}
          ${n ? `<button class="btn sm ghost danger" data-act="lClear">照明を全部消す</button>` : ''}${(p.drawing.outlets || []).length ? `<button class="btn sm ghost danger" data-act="oClear">コンセントを全部消す</button>` : ''}
          <div class="seg" style="width:100%" id="lTool">${[['light', '照明'], ['sw', 'スイッチ'], ['out', 'コンセント'], ['panel', '分電盤'], ['link', 'つなぎ替え']].map(t => `<button data-ltool="${t[0]}" class="${ltool === t[0] ? 'on' : ''}">${t[1]}</button>`).join('')}</div>
          <div class="small" style="width:100%">${{ light: '何も無い所をタップで照明を足す・照明をタップで消す。照明を縦になぞると横一列、横になぞると縦一列がまとめて動きます（長押ししてからなぞると1個だけ）', sw: 'タップでスイッチを置く（その区画は置いたスイッチにつなぐ）・スイッチ（黄・青どちらも）をタップで消す（同じ部屋にほかのスイッチが無ければ、スイッチ無しになります。人感センサー付きの照明など）・なぞって動かす', out: 'タップでコンセントを置く・コンセントをタップで消す・なぞって動かす', panel: '何も無い所をタップで分電盤を置く（何個でも）・分電盤をタップで向きを90°回す（消す時は知らせの「消す」）・なぞって動かす', link: linkSel ? 'つなぐスイッチか照明をタップしてください（照明をタップすると、その照明から線を引きます）' : '照明をタップしてから、つなぎたいスイッチか照明をタップ' }[ltool]}${ltool === 'out' ? `　<select class="in" id="oItem" style="display:inline-block;width:auto;min-height:34px">${masterItems().filter(i => /^e-con/.test(i.id)).map(i => `<option value="${esc(i.id)}" ${(lset.out || 'e-cone') === i.id ? 'selected' : ''}>${esc(i.name)}</option>`).join('')}</select>` : ''}${ltool === 'link' && Object.values(p.drawing.link || {}).some(v => v !== 'none') ? `　<button class="btn sm ghost" data-act="linkClear">つなぎ替え ${Object.values(p.drawing.link).filter(v => v !== 'none').length} 件を元に戻す</button>` : ''}</div>
          ${(() => { const ws = wireSetOf(p.drawing), M = masterItems(), cab = M.filter(i => i.cat === 'wire' && i.unit === 'm'), sws = M.filter(i => i.cat === 'elec' && /スイッチ/.test(i.name));
            const sel = (k, list) => `<select class="in" data-wset="${k}" style="min-height:36px">${list.map(i => `<option value="${esc(i.id)}" ${ws[k] === i.id ? 'selected' : ''}>${esc(i.name)}${i.spec ? ' ' + esc(i.spec) : ''}</option>`).join('')}</select>`;
            return `<details style="width:100%"><summary class="small">配線の設定（ケーブル・スイッチの種類・余り）</summary><div class="row" style="flex-wrap:wrap;gap:8px;margin-top:6px">
              <label class="f" style="flex:1;min-width:180px">照明の線${sel('cL', cab)}</label><label class="f" style="flex:1;min-width:180px">コンセント・分電盤からの線${sel('cO', cab)}</label>
              <label class="f" style="flex:1;min-width:180px">自動で置くスイッチ${sel('sw', sws)}</label>
              <label class="f" style="width:110px">余りを足す<div class="unitwrap"><input class="in num" data-wset="extra" type="number" inputmode="numeric" min="0" max="100" step="5" value="${p.drawing.wireExtra ?? 10}"><span>%</span></div></label>
              <label class="row small" style="gap:6px;width:100%"><input type="checkbox" data-wset="out" ${ws.out ? 'checked' : ''} style="width:20px;height:20px">コンセントの線も長さに入れる（図には描きません）</label></div></details>`; })()}
          <div class="small muted" style="width:100%">照明 ${n} 台・スイッチ ${W.sw} 個（黄＝自動・青＝置いた物）・コンセント ${(p.drawing.outlets || []).length} 個・ケーブル ${W.mL + W.mH} m（余り${W.extra}%込み）。スイッチは入口のそばに自動で置きます${W.booths ? `。トイレのブース ${W.booths} か所は、外の部屋のスイッチで点けます` : ''}。${W.far ? `<b>分電盤から離れた所（別の階の図など）の ${W.far} 区画は、分電盤からの線を入れていません。その階にも分電盤を置いてください。</b>` : ''}${W.dropped && W.dropped.length ? ` <b style="color:var(--bad,#c33)">区画の外にある照明 ${W.dropped.length} 台は、配線・スイッチに入っていません（器具の数には入ります）。区画の中へ動かしてください。</b>` : ''}</div>
          ${res ? (n && (p.drawing.lights || []).length && res.split('<span').length > 7 ? `<details style="width:100%"><summary class="small">部屋ごとの台数と明るさを見る${res.includes('pill warn') ? '（目標に届かない部屋あり）' : ''}</summary><div class="row" style="margin-top:6px">${res}</div></details>` : `<div class="row" style="width:100%">${res}</div>`) : ''}`;
        return;
      }
      if (mode === 'place') {
        const d = p.drawing, G = groupsOf(masterItems());
        const itemSel = (id, cur) => `<select class="in" id="${id}" style="min-height:40px">${G.map(([g, its]) => `<optgroup label="${esc(g)}">${its.map(i => `<option value="${esc(i.id)}" ${i.id === cur ? 'selected' : ''}>${esc(i.name)}${i.spec ? ' ' + esc(i.spec) : ''}</option>`).join('')}</optgroup>`).join('')}</select>`;
        const one = pset.where === 'pt', line = pset.where === 'line', pv = pPreview(), selN = line ? psegs.size : pfaces.size;
        const x = psel && (d.places || []).find(q => q.id === psel);
        const C = {}; (d.places || []).filter(q => q.where === 'pt').forEach(q => { C[q.item] = (C[q.item] || 0) + 1; });
        const desc = q => q.how === 'grid' ? (q.where === 'line' ? `線1本に${q.n}個` : `${q.cols}列×${q.rows}行`) : `間隔 ${q.gap}mm${q.edge !== '' && q.edge != null ? `・${q.where === 'line' ? '端' : '壁'}から ${q.edge}mm` : ''}`;
        const list = Object.entries(C).map(([it, n]) => `<div class="row small" style="gap:8px"><span style="width:12px;height:12px;border-radius:50%;background:${placeColor(it)}"></span><b>${esc(itemName(it))}</b><span class="muted">1個ずつ置いた物</span><span class="spacer"></span><b>${n}個</b><button class="linkbtn" data-act="pDelItem" data-item="${esc(it)}" aria-label="消す">×</button></div>`).join('')
          + (d.places || []).filter(q => q.where !== 'pt').map(q => `<div class="row small" style="gap:8px"><span style="width:12px;height:12px;border-radius:50%;background:${placeColor(q.item)}"></span><b>${esc(itemName(q.item))}</b><span class="muted">${q.where === 'line' ? '壁に沿って' : '部屋に並べた'}・${esc(desc(q))}</span><span class="spacer"></span><b>${placePts(q).length}個</b><button class="linkbtn" data-act="pDel" data-id="${q.id}" aria-label="消す">×</button></div>`).join('');
        bar.innerHTML = `<div class="seg" style="width:100%">${[['pt', '1個ずつ置く'], ['area', '部屋に並べる'], ['line', '壁に沿って']].map(t => `<button data-pwhere="${t[0]}" class="${pset.where === t[0] ? 'on' : ''}">${t[1]}</button>`).join('')}</div>
          <div class="grid g4" style="width:100%;align-items:end"><label class="f" style="grid-column:span 2">置く品目${itemSel('pItem', pset.item)}</label>
          ${one ? '' : `<label class="f">並べ方<select class="in" id="pHow"><option value="grid" ${pset.how === 'grid' ? 'selected' : ''}>${line ? '個数で' : '列×行で'}</option><option value="gap" ${pset.how === 'gap' ? 'selected' : ''}>間隔で</option></select></label>`}</div>
          ${one ? '' : `<div class="grid g4" style="width:100%;align-items:end">${pset.how === 'grid' ? (line ? `<label class="f">線1本に置く個数<input class="in num" id="pN" type="number" inputmode="numeric" min="1" value="${pset.n}"></label>`
            : `<label class="f">列（横）<input class="in num" id="pCols" type="number" inputmode="numeric" min="1" value="${pset.cols}"></label><label class="f">行（縦）<input class="in num" id="pRows" type="number" inputmode="numeric" min="1" value="${pset.rows}"></label>`)
            : `<label class="f">間隔<div class="unitwrap"><input class="in num" id="pGap" type="number" inputmode="numeric" min="100" step="50" value="${pset.gap}"><span>mm</span></div></label><label class="f">${line ? '端から' : '壁から'}<div class="unitwrap"><input class="in num" id="pEdge" type="number" inputmode="numeric" min="0" step="50" value="${pset.edge}" placeholder="間隔の半分"><span>mm</span></div></label>`}</div>`}
          <div class="small" style="width:100%">${one ? (x ? '選んだ記号は、指でなぞると動かせます。' : '置きたい所をタップしてください（長押しすると虫めがねで細かく置けます）。置いた記号をタップすると選べます。')
            : selN ? `<b>${line ? selN + '本' : selN + '区画'} 選択中</b>${pv.length ? `　→ <b>${pv.length}個</b>` : '　→ 並べる位置がありません'}` : (line ? '並べる壁の線をタップしてください（何本でも）。' : '並べる区画をタップしてください（何個でも。まとめた範囲に均一に並びます）。')}</div>
          ${one ? '' : `<button class="btn sm primary" data-act="pAdd" ${pv.length ? '' : 'disabled'}>${icon('plus')}${pv.length ? `この${pv.length}個を並べる` : '並べる'}</button>${selN ? '<button class="btn sm ghost" data-act="pSelClear">選択を解除</button>' : ''}`}
          ${x ? `<div class="card" style="padding:10px;width:100%"><div class="row small" style="gap:8px"><b>${esc(itemName(x.item))} を選択中</b></div>
            <div class="row" style="margin-top:6px;gap:8px"><label class="f" style="min-width:220px">品目を変える${itemSel('pSelItem', x.item)}</label><button class="btn sm" data-act="pRot">向きを変える（90°）</button><button class="btn sm danger" data-act="pDelOne">${icon('trash')}この1個を消す</button><button class="btn sm ghost" data-act="pSelNone">閉じる</button></div></div>` : ''}
          ${list ? `<div style="width:100%;display:grid;gap:6px;padding-top:8px;border-top:1px solid var(--line)"><b class="small">置いた品目</b>${list}</div>` : ''}
          <div class="small muted" style="width:100%">電気・設備・建築付属の品目を図面に置けます。置いた数は③工事の明細に入ります（取付の手間も付きます）。</div>`;
        return;
      }
      if (mode === 'lineoff') {
        const d = p.drawing, LO = d.lineOff || { keys: [], segs: [] }, nOff = (LO.keys || []).length + (LO.segs || []).length, Z = d.outZones || [];
        const tabs = `<div class="seg" style="width:100%">${[['line', '線を外す'], ['out', '工事対象外の範囲']].map(t => `<button data-loway="${t[0]}" class="${loway === t[0] ? 'on' : ''}">${t[1]}</button>`).join('')}</div>`;
        if (loway === 'line') {
          const plan = d.plan, k = loSel >= 0 && plan.sg ? plan.sg[loSel] : -1, same = k >= 0 ? plan.sg.filter(v => v === k).length : 0;
          bar.innerHTML = tabs + `<div class="small" style="width:100%">${loSel >= 0 ? `<b>選んだ線</b>：長さ ${segLen(plan.segs[loSel]).toFixed(2)}m${same ? `・同じ種類（同じレイヤー・色・線種）の線 ${same}本を橙で出しています` : ''}` : '寸法線・ビニールカーテンなど、部屋の区切りではない線をタップしてください。'}</div>
            ${loSel >= 0 ? `<button class="btn" data-act="loOne">この線だけ外す</button>${same > 1 ? `<button class="btn" data-act="loKind">同じ種類を全部外す（${same}本）</button>` : ''}<button class="btn sm ghost" data-act="loCancel">選ぶのをやめる</button>` : ''}
            ${nOff ? `<div class="small" style="width:100%">外す線：種類 ${(LO.keys || []).length}・1本ずつ ${(LO.segs || []).length}${d.lineOffDirty ? '（まだ区画に効いていません）' : ''}</div><button class="btn primary" data-act="loApply" ${d.lineOffDirty ? '' : 'disabled'}>外した線で区画を作り直す</button><button class="btn sm ghost" data-act="loClear">外した線を全部戻す</button>` : ''}`;
        } else {
          bar.innerHTML = tabs + `<div class="small" style="width:100%">${outA ? 'もう1つの角をタップしてください。' : '工事しない範囲（ビニールカーテンの中など）の、四角の角を2か所タップしてください。部屋の床・天井からその広さを、壁・巾木から範囲の中の壁の長さを引きます。'}</div>
            ${outA ? '<button class="btn sm ghost" data-act="outCancel">やめる</button>' : ''}${Z.length ? `<div class="small" style="width:100%">工事対象外の範囲 ${Z.length}か所</div>${Z.map((z, i) => `<button class="btn sm" data-outdel="${z.id}">範囲${i + 1}を消す</button>`).join('')}` : ''}`;
        }
        return;
      }
      if (mode === 'cut') {
        bar.innerHTML = `<span class="small muted">${cutA ? 'もう1つの角をタップしてください。' : 'カッターで切る範囲の、四角の角を2か所タップしてください。'}</span>${cutA ? '<button class="btn sm ghost" data-act="cutCancel">やめる</button>' : ''}`;
        return;
      }
      if (mode === 'zsplit') {
        const z = ((p.drawing.zones || []).find(q => q.id === (zsplit && zsplit.id))) || {};
        bar.innerHTML = `<span class="small muted">「${esc(z.name || '名前なし')}」を分ける線を引きます。境目にしたい所を順番にタップしてください${zsplit && zsplit.pts.length ? `（${zsplit.pts.length}点）` : ''}。線の両側で区画が分かれます。</span><span class="spacer"></span><button class="btn primary" data-act="zsplitGo" ${!zsplit || zsplit.pts.length < 2 ? 'disabled' : ''}>ここで分ける</button>${zsplit && zsplit.pts.length ? '<button class="btn sm" data-act="zsplitUndo">1つ戻す</button>' : ''}<button class="btn sm ghost" data-act="zsplitCancel">やめる</button>`;
        return;
      }
      if (mode === 'meas') {
        const P = meas.pts; let last = 0, total = 0;
        for (let k = 1; k < P.length; k++) { const d = Math.hypot(P[k][0] - P[k - 1][0], P[k][1] - P[k - 1][1]); total += d; last = d; }
        bar.innerHTML = `<span class="small muted">${P.length ? '' : '測りたい所を2点タップしてください。線の端・交点・線の上にくっつきます。長押しすると虫めがねで大きく見えます（指を動かして、離した所に決まります）。'}</span>
          ${P.length > 1 ? `<span class="pill acc" style="font-size:15px">長さ ${last.toFixed(3)} m</span>${meas.cont && P.length > 2 ? `<span class="pill info" style="font-size:15px">合計 ${total.toFixed(3)} m</span><span class="pill ok" style="font-size:15px">囲んだ広さ ${polyArea(P).toFixed(2)} ㎡</span><button class="btn sm primary" data-act="measFace" title="壁の線で囲まれていない部屋（広い事務室・つながった部屋など）を、タップした角で囲んで区画にします">${icon('plus')}この形を区画にする</button>` : ''}` : ''}
          <span class="spacer"></span><label class="row small muted" style="gap:6px"><input type="checkbox" data-meas-cont ${meas.cont ? 'checked' : ''} style="width:20px;height:20px">続けて測る（合計・囲んだ広さを出す。区画にもできます）</label>
          <button class="btn sm" data-act="measBack" title="最後に打った点だけ消します" ${P.length ? '' : 'disabled'}>${icon('undo')}1つ戻す</button><button class="btn sm" data-act="measFwd" title="「1つ戻す」で消した点を戻します" ${meas.redo.length ? '' : 'disabled'}>${icon('redo')}1つ進む</button><button class="btn sm" data-act="measClear">全部やり直す</button>`;
      } else {
        const fx = fxList();
        const x = fx[fsel];
        const types = Object.entries(FIX_NAMES);
        const tfSel = x ? typeFixMap(p.drawing)[fsel] : null;
        bar.innerHTML = x ? `<b class="small">選んだ器具</b>${tfSel ? `<span class="small" style="color:var(--warn)">${tfSel.shown ? `表示は「${esc(FIX_NAMES[tfSel.shown] || tfSel.shown)}」に補正中です。ここで種類を変えると、その判断が優先されます` : `要確認：${esc(tfSel.reason)}`}</span>` : ''}
            <select class="in" data-fx="t" style="width:auto;min-height:40px">${types.map(([k, n]) => `<option value="${k}" ${x.t === k ? 'selected' : ''}>${n}</option>`).join('')}</select>
            <label class="row small muted" style="gap:6px">壁側<select class="in" data-fx="back" style="width:auto;min-height:40px"><option value="">—</option>${BACKS.map(([k, n]) => `<option value="${k}" ${x.back === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
            ${(x.t === 'toilet' || x.t === 'counter') ? `<button class="btn sm" data-act="fxFlip">コンセントを反対側へ${x.flip ? '（反対側にしています）' : ''}</button>` : ''}
            <button class="btn sm danger" data-act="fxDel">${icon('trash')}消す</button><button class="btn sm ghost" data-act="fxDone">選ぶのをやめる</button>`
          : addAt ? `<b class="small">ここに器具を足す</b>
            <select class="in" id="fxNewT" style="width:auto;min-height:40px">${types.filter(([k]) => FIX_SIZE[k]).map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select>
            <label class="row small muted" style="gap:6px">壁側<select class="in" id="fxNewB" style="width:auto;min-height:40px">${BACKS.map(([k, n]) => `<option value="${k}">${n}</option>`).join('')}</select></label>
            <button class="btn sm primary" data-act="fxAdd">${icon('plus')}足す</button>${p.drawing.plan.faces.some(f => pip(addAt[0], addAt[1], f.poly)) ? `<button class="btn sm" data-act="fxVirtual">この区画をトイレにする</button>` : ''}<button class="btn sm ghost" data-act="fxDone">やめる</button>
            <span class="small muted" style="width:100%">「この区画をトイレにする」：便器が描いていないトイレに、扉の反対側の壁へ便器を置きます。</span>`
          : `<span class="small muted">器具をタップすると、種類を変えたり消したりできます。何も無い所をタップすると、そこに器具を足せます。</span>`;
      }
      return;
    }
    const own = owner();
    /* 床を拾った所・まだの所の数と広さ（図面の斜線と同じ数え方。図枠の内側・除外・保留・隣にまとめた区画は数えない） */
    const pickedRow = () => { const d = p.drawing, F = d.plan.faces, mk = faceMarks() || {}, j = d.faceJoin || {}, off = d.faceOff || {};
      const pin = (x, y, P) => { let c = false; for (let i = 0, k = P.length - 1; i < P.length; k = i++) { if (((P[i][1] > y) !== (P[k][1] > y)) && x < (P[k][0] - P[i][0]) * (y - P[i][1]) / (P[k][1] - P[i][1]) + P[i][0]) c = !c; } return c; };
      let nd = 0, ad = 0, nt = 0, at = 0;
      F.forEach(f => { if (own.has(f.i)) { nd++; ad += f.area || 0; return; } if (mk[f.i] || j[f.i] != null || off[f.i] || !f.poly || f.poly.length < 3) return;
        let k = 0; for (const o of F) { if (o !== f && o.area < f.area && pin(o.cx, o.cy, f.poly) && ++k >= 2) break; } if (k >= 2) return; nt++; at += f.area || 0; });
      const r2 = v => Math.round(v * 100) / 100;
      return `<span class="small" style="width:100%;display:flex;gap:10px;flex-wrap:wrap;align-items:center"><span><span style="display:inline-block;width:12px;height:12px;border-radius:3px;background:var(--accent);opacity:.5;vertical-align:-2px"></span> 部屋にした所 <b>${nd}</b>区画・${r2(ad)}㎡</span><span><span style="display:inline-block;width:12px;height:12px;border-radius:3px;border:1.5px dashed #ff8a3d;background:repeating-linear-gradient(45deg,rgba(255,138,61,.5) 0 2px,transparent 2px 5px);vertical-align:-2px"></span> まだの所 <b>${nt}</b>区画・${r2(at)}㎡</span></span>`; };
    const fl = body.querySelector('#dwgFaces');
    if (fl) fl.innerHTML = [...p.drawing.plan.faces].sort((a, b) => a.no - b.no).map(f => `<button data-face="${f.i}" class="${sel.has(f.i) ? 'on' : ''} ${own.has(f.i) && !sel.has(f.i) ? 'used' : ''}">区画${f.no}${f.name ? ' ' + esc(f.name) : ''} ${Math.round(f.area * 100) / 100}㎡</button>`).join('');
    const bar = body.querySelector('#dwgBar');
    if (bar) bar.innerHTML = sel.size
      ? `<span class="small"><b>${sel.size} 区画</b>を選んでいます${selGeo ? `（床 ${Math.round((selGeo.area - (selGeo.holes && !holesOn ? selGeo.holes.area : 0)) * 100) / 100}㎡）` : ''}。続けてタップで足す・もう一度で外す。</span>${sel.size === 1 && (p.drawing.faceFix || {})[[...sel][0]] ? '<span class="pill info">辺を手直し済み</span>' : ''}${[...sel].some(i => ((p.drawing.plan || {}).split || {})[i]) ? '<span class="pill info">机・棚などの線を外してまとめた区画</span>' : ''}${selGeo && selGeo.holes ? `<label class="row small" style="gap:6px;width:100%;cursor:pointer"><input type="checkbox" data-holes ${holesOn ? 'checked' : ''} style="width:20px;height:20px">中の机・棚などで囲まれた所 ${selGeo.holes.area}㎡ も床に入れる（図面で橙に塗った所）</label>` : ''}<span class="spacer"></span><button class="btn primary" data-act="mkOne">${icon('check')}1部屋にする</button>${sel.size > 1 ? `<button class="btn" data-act="mkEach">1区画ずつ部屋にする</button>` : ''}<button class="btn" data-act="selSame" title="選んだ区画と同じ広さ・同じ周りの長さの区画（トイレのブースなど）を、まとめて選びます">同じ大きさの区画も選ぶ</button>${[...sel].some(i => own.has(i)) ? `<button class="btn" data-act="unassign">部屋から外す</button>` : ''}<button class="btn" data-act="faceJoin" title="棚や机で割れた小さい区画を、接している長さがいちばん長い隣の区画（部屋）の床に入れます">隣の部屋にまとめる</button><button class="btn" data-act="faceOff" title="部屋ではない所（表・家具・外など）を、灰色にして数えないようにします">区画ではない</button>${sel.size === 1 ? `<button class="btn" data-act="faceFix" title="壁の段差などを区画の辺が読み取れていない時、この区画の辺だけを、図面の実線に沿うように直します（直せる所が無い時は、何も変わりません）">辺を実線に直す</button>` : ''}${[...sel].some(i => ((p.drawing.plan || {}).split || {})[i]) ? `<button class="btn" data-act="faceSplit" title="家具の線を外して1つにまとめた区画を、読み取った時の細かい区画に戻します">細かい区画に分ける</button>` : ''}${[...sel].some(i => (p.drawing.faceOff || {})[i] || (p.drawing.faceJoin || {})[i] != null || (p.drawing.faceFix || {})[i]) ? `<button class="btn" data-act="faceBack">元に戻す</button>` : ''}<button class="btn ghost" data-act="selClear">選ぶのをやめる</button>`
      : `${pickedRow()}<span class="small muted">部屋にする区画を順番にタップして、選び終わったら「1部屋にする」。続けて次の部屋の区画を選べます。仕上げは、知らせの「仕上げを決める」か部屋の一覧から決められます。</span><span class="spacer"></span><button class="btn sm" data-act="selRest">まだ部屋にしていない区画を全部選ぶ</button>`;
  };
  /* コンセントを器具に合わせて置く（自分で置いた物は残す）。「反対側へ」にした器具は器具の真ん中で反対側 */
  const placeOutlets = () => {
    const d = p.drawing, item = lset.out || 'e-cone';
    const pts = (d.fixtures || []).map(x => { const q = x.out || outFallback(x); if (!q || !x.flip || !x.b) return q; const hor = x.back === 'N' || x.back === 'S';
      return hor ? [r3(x.b[0] + x.b[2] - q[0]), q[1]] : [q[0], r3(x.b[1] + x.b[3] - q[1])]; }).filter(Boolean);
    d.outlets = (d.outlets || []).filter(o => !o.auto).concat(pts.map(q => ({ id: uid('O'), x: q[0], y: q[1], item, auto: true })));
    return pts.length;
  };
  /* 照明・コンセント・置いたスイッチ・分電盤を指でなぞって動かす。
   * 照明：縦になぞると同じ横一列（同じ部屋・区画で高さがそろっている物）が上下に、横になぞると縦一列が左右に動く。長押ししてからなぞると1個だけ。5cm単位にそろえる */
  const dragStart = (x, y, sc) => {
    if (mode === 'place' && pset.where === 'pt') {
      const d = p.drawing, tol = Math.min(Math.max(0.15, sc * 14), 0.35);
      let one = null, bd = tol; (d.places || []).filter(q => q.where === 'pt').forEach(q => { const dd = Math.hypot(q.p[0] - x, q.p[1] - y); if (dd < bd) { bd = dd; one = q; } });
      if (!one) return null;
      const o = one.p.slice();
      return { move: (dx, dy) => { one.p = [r3(o[0] + dx), r3(o[1] + dy)]; paintSel(); },
        end: c => { if (c) { one.p = o; paintSel(); return; } psel = one.id; syncDemoLines(p); touch(p); paintSel(); toast('動かしました', { action: '元に戻す', onAction: () => { one.p = o; touch(p); paintSel(); } }); } };
    }
    if (mode !== 'light' || linkSel) return null;
    const d = p.drawing, tol = Math.max(0.2, sc * 14);
    const near = list => (list || []).findIndex(q => Math.hypot(q.x - x, q.y - y) < tol);
    const g5 = v => Math.round(v * 20) / 20;
    const done = (msg, back) => { syncDemoLines(p); touch(p); paintSel(); toast(msg, { action: '元に戻す', onAction: () => { back(); syncDemoLines(p); touch(p); paintSel(); } }); };
    if (ltool === 'panel') { const P = panelsOf(d, true), one = P.find(q => Math.hypot(q.x - x, q.y - y) < tol * 1.5);
      if (one) { const o = { x: one.x, y: one.y };
        return { move: (dx, dy) => { one.x = r3(o.x + dx); one.y = r3(o.y + dy); paintSel(); }, end: c => { if (c) { Object.assign(one, o); paintSel(); return; } done('分電盤を動かしました', () => Object.assign(one, o)); } }; } }
    const list = ltool === 'out' ? d.outlets : ltool === 'sw' ? d.switches : ltool === 'light' ? d.lights : null;
    /* 自動で置いたスイッチ（黄）をなぞった時：その場で置いたスイッチ（青）に変えて動かす。
       そのスイッチにつながっていた照明は、動かした先のスイッチにつないだままにする（部屋の外へ動かしても配線が付いてくる） */
    if (ltool === 'sw' && near(d.switches) < 0) {
      const W = lightWires(p), s0 = W.sws.find(q => q.auto && Math.hypot(q.l[0] - x, q.l[1] - y) < tol);
      if (s0) {
        d.switches = d.switches || []; d.link = d.link || {};
        const ns = { id: uid('S'), x: r3(s0.l[0]), y: r3(s0.l[1]) }, keys = Object.keys(W.assign).filter(q => W.assign[q] === s0.key);
        const linkWas = {}; keys.forEach(q => { linkWas[q] = d.link[q]; });
        d.switches.push(ns); keys.forEach(q => { d.link[q] = ns.id; });
        const back = () => { d.switches = d.switches.filter(q => q !== ns); keys.forEach(q => { if (linkWas[q] == null) delete d.link[q]; else d.link[q] = linkWas[q]; }); };
        return { move: (dx, dy) => { ns.x = r3(s0.l[0] + dx); ns.y = r3(s0.l[1] + dy); paintSel(); },
          end: c => { if (c) { back(); paintSel(); return; } done('スイッチを動かしました（自動のスイッチを、置いたスイッチに変えました）', back); } };
      }
    }
    const k = near(list); if (k < 0) return null;
    const one = list[k], o0 = { x: one.x, y: one.y };
    if (ltool !== 'light') return { move: (dx, dy) => { one.x = r3(o0.x + dx); one.y = r3(o0.y + dy); paintSel(); },
      end: c => { if (c) { Object.assign(one, o0); paintSel(); return; } one.auto = false; done(ltool === 'out' ? 'コンセントを動かしました' : 'スイッチを動かしました', () => Object.assign(one, o0)); } };
    const same = q => one.room ? q.room === one.room : (q.face != null && q.face === one.face) || (!q.room && one.face == null);
    let axis = null, group = null;
    const orig = new Map();
    const h = {
      move: (dx, dy, px, py) => {
        if (!group) {
          if (h.long) { axis = 'xy'; group = [one]; }
          else if (Math.abs(py) >= Math.abs(px)) { axis = 'y'; group = d.lights.filter(q => same(q) && Math.abs(q.y - one.y) < 0.06); }
          else { axis = 'x'; group = d.lights.filter(q => same(q) && Math.abs(q.x - one.x) < 0.06); }
          group.forEach(q => orig.set(q, { x: q.x, y: q.y }));
        }
        group.forEach(q => { const o = orig.get(q); if (axis !== 'y') q.x = g5(o.x + dx); if (axis !== 'x') q.y = g5(o.y + dy); });
        paintSel();
      },
      end: c => {
        const back = () => orig.forEach((o, q) => Object.assign(q, o));
        if (c || !group) { back(); paintSel(); return; }
        done(group.length > 1 ? `照明 ${group.length} 台（${axis === 'y' ? '横一列' : '縦一列'}）を動かしました` : '照明を1台動かしました', back);
      },
      onLong: () => toast('この照明だけ動かします', { ms: 1200 })
    };
    return h;
  };
  /* 寸法で間取りを作る・なぞって拾う（file を渡すと、その図を下に敷いて始める） */
  const openSk = file => openSketch(p, { file, onSave: () => touch(p), onApply: async sk => {
    const had = p.rooms.some(r => r.src === 'plan');
    if (had && !(await ask('間取りを入れ替えますか？', '今の図面と、図面から作った部屋を、この間取りに入れ替えます。手で足した部屋はそのままです。', { ok: '入れ替える' }))) return false;
    const keep = p.drawing && p.drawing.sketch ? p.drawing : null;
    const plan = sketchPlan(sk.rooms); orderFacesOf(plan); plan.order = 2;
    p.drawing = { fileName: sk.img && sk.rooms.some(r => r.photo) ? 'なぞって作った間取り' : '寸法で作った間取り', bg: sk.img && sk.rooms.some(r => r.photo) ? { s: sk.s } : null, at: Date.now(), plan, fixtures: [], open: {}, doors: [], fixG: '', fixGd: '', sketch: true,
      lights: [], walls: [], hatsu: [], panel: null, wireExtra: keep ? keep.wireExtra : undefined };
    /* 間取りを直しただけなら、置いた照明・器具・壁などはそのまま */
    if (keep) ['lights', 'outlets', 'switches', 'link', 'panel', 'panels', 'walls', 'hatsu', 'places', 'win3d'].forEach(k => { if (keep[k] != null) p.drawing[k] = keep[k]; });
    const old = new Map(p.rooms.filter(r => r.src === 'plan' && r.sk).map(r => [r.sk, r]));
    p.rooms = p.rooms.filter(r => r.src !== 'plan');
    plan.faces.slice().sort((a, b) => a.no - b.no).forEach((f, k) => {
      const o = old.get(f.sk);
      p.rooms.push({ ...(o || { id: uid('r'), qty: 1, doors: 0, winCount: 0, windows: [], h: '' }), name: f.name || `区画 ${f.no}`, shape: 'free', area: f.area, perim: f.peri, faces: [f.i], src: 'plan', sk: f.sk, color: o ? o.color : k, openRuns: [] });
    });
    syncDemoLines(p); touch(p); draw(); toast(`${plan.faces.length} 部屋の間取りを図面にしました`);
    return true;
  } });
  const makeRooms = each => {
    const plan = p.drawing.plan;
    const zn = zoneNameOnce; zoneNameOnce = '';
    const ids = [...sel];
    /* 選んだ区画が別の部屋に入っていたら、その部屋から外す */
    p.rooms.forEach(r => {
      if (!r.faces) return;
      const keep = r.faces.filter(i => !sel.has(i));
      if (keep.length !== r.faces.length) {
        r.faces = keep;
        if (keep.length) setGeo(r);
      }
    });
    p.rooms = p.rooms.filter(r => !(r.src === 'plan' && r.faces && !r.faces.length));
    const used = new Set(p.rooms.map(r => r.color));
    const nextColor = () => { for (let c = 0; c < 99; c++) if (!used.has(c)) { used.add(c); return c; } return 0; };
    const byNo = (a, b) => plan.faces.find(f => f.i === a).no - plan.faces.find(f => f.i === b).no;
    const groups = (each ? ids.sort(byNo).map(i => [i]) : [ids.sort(byNo)]).map(g => withJoined(g));
    const defCH = planCH(plan);
    groups.forEach(g => {
      const F = g.map(i => plan.faces.find(f => f.i === i)).filter(Boolean);
      const geo = geoOf(g);
      /* 新しい読み取りを選んだ図面では、名前の無い区画に「つないだ文字」からの名前の提案を使う */
      const r2n = (p.drawing.reader === 'v2' && p.drawing.analysis && p.drawing.analysis.names) || {};
      const names = [...new Set(F.map(f => f.name || r2n[f.i] || r2n[String(f.i)]).filter(Boolean))];
      const chs = F.map(f => +f.ch || 0).filter(v => v > 0);
      const runs = p.drawing.open ? roomOpenRuns(g, plan, p.drawing.open) : [];
      p.rooms.push({ id: uid('r'), name: zn || names.join('・') || `区画 ${F.map(f => f.no).join('・')}`, shape: 'free', area: geo.area, perim: geo.perim,
        h: chs.length ? Math.max(...chs) : (defCH || ''), qty: 1, doors: 0, winCount: 0, windows: [], faces: g, src: 'plan', color: nextColor(), openRuns: runs, ...(geo.holes ? { holes: geo.holes, ...(holesOn ? {} : { noHoles: true }) } : {}), ...(geo.out ? { out: geo.out } : {}) });
      if (geo.holes && !holesOn) p.rooms[p.rooms.length - 1].area = Math.round((geo.area - geo.holes.area) * 100) / 100;
    });
    /* 区画を外した部屋の開口も決め直す */
    if (p.drawing.open) p.rooms.forEach(r => { if (r.src === 'plan' && r.faces) r.openRuns = roomOpenRuns(r.faces, plan, p.drawing.open); });
    const n = groups.length;
    const made = p.rooms.slice(-n);
    const od = made.reduce((s, r) => s + (r.openRuns || []).filter(x => x.ty === 'd').length, 0), og = made.reduce((s, r) => s + (r.openRuns || []).filter(x => x.ty !== 'd').length, 0);
    sel.clear(); touch(p); draw();
    /* 続けて次の区画を部屋にできるように、仕上げの画面は自動では開かない（かつ「連続してやりたい。毎回終了なるとめんどくさい」・2026-11-24）。知らせのボタンか、部屋の一覧から決める */
    const fin = () => openRoomFin(p, made.map(r => r.id), { title: n > 1 ? `${n} 部屋の仕上げ（同じにする）` : `「${made[0].name}」の仕上げ`, usePreset: true, onDone: () => { syncWaste(p); touch(p); draw(); } });
    toast((od + og ? `${n} 部屋を作りました。図面のドア ${od} か所・開口 ${og} か所を壁の面積から引きました` : `${n} 部屋を作りました`) + '。続けて次の区画を選べます', { ms: 6000, action: '仕上げを決める', onAction: fin });
  };
  const draw = () => {
    /* 解析の作りを直した後に開いた図面は、覚えておいた文字・線から解析を作り直す（読み直さなくても図の分け方・工事名称が出る） */
    { const d = p.drawing; if (d && d.plan && d.analysis && d.src2 && d.analysis.ver !== R2VER) { try {
      const mk = (faces, shapes) => analyzeFrame({ segs: d.src2.segs.length ? d.src2.segs : d.plan.segs, faces, texts: d.src2.texts, fixtures: d.fixtures || [], doors: d.src2.doors || [], shapes });
      if (d.reader === 'v2' && d.v1) { d.analysis = mk(d.plan.faces, true); d.v1.analysis = mk(d.v1.faces, false); }
      else { d.analysis = mk(d.plan.faces, false); if (d.v2 && d.v2.faces) d.v2.analysis = mk(d.v2.faces, true); }
      touch(p); rebaseUndo(p); } catch (e) { console.warn('解析を作り直せませんでした', e); } } }   // 自動で直しただけなので、元に戻すの控えには積まない
    body.innerHTML = drawingCard(p) + `<div class="rooms">${p.rooms.map((r, i) => roomCard(r, i, p)).join('') || `<div class="card empty"><b>まだ部屋がありません</b>下のボタンで部屋を足してください。</div>`}</div>
      <div class="addbar" style="margin-top:12px"><button class="btn primary" id="addRoom">${icon('plus')}部屋を足す</button>
      </div>`;
    const keepV = view && view.keep ? view.keep() : keep0; keep0 = null;   // 描き直しても拡大・位置をそのままに（かつ「戻す・進むを押すと全体に戻る」）
    view = null;
    /* 前の版で読み込んだ図面は、区画の番号を前のKAKUと同じ付け方に直す（部屋とのつながりは区画の i なので変わらない） */
    if (p.drawing && p.drawing.plan && p.drawing.plan.order !== 2) { orderFacesOf(p.drawing.plan); p.drawing.plan.order = 2; touch(p); rebaseUndo(p); }
    if (p.drawing && p.drawing.plan) {
      view = planView(body.querySelector('#dwgView'), p.drawing.plan, {
        keep: keepV,
        selected: () => sel, owner, unpicked: () => (mode === 'room' ? (f => { const d = p.drawing; return (d.faceJoin || {})[f.i] == null && !(d.faceOff || {})[f.i]; }) : null), fixtures: fxDisplayList, symbols: () => symList(p.drawing).map(s => ({ b: s.b, color: SYM_VERDICTS[s.verdict].color, label: s.verdict === 'hit' ? s.category : s.verdict === 'near' ? '類似' : '不明', on: s.k === symSel })), roomJudge: () => roomJudgeEntries(p.drawing), bg: p.drawing.bg && p.sketch && p.sketch.img ? { ...p.sketch.img, s: p.drawing.bg.s } : null, fixSel: () => (mode === 'fix' ? fsel : -1), mode: () => mode, fixG: p.drawing.fixG || '', fixGd: p.drawing.fixGd || '',
        extraTools: `<button class="iconbtn" data-act="dwgFs" title="${dwgFs ? '全画面をやめる' : '全画面で編集する'}" aria-label="${dwgFs ? '全画面をやめる' : '全画面で編集する'}">${icon(dwgFs ? 'shrink' : 'full')}</button>`,
        marks: () => faceMarks(),
        /* 部屋にした区画は、区画ごとの番号を消して、部屋に1つだけ名前と広さを出す（かつ「まとめたら細かい区画の数字消して真ん中にまとめた数字に」） */
        rooms: () => { const J = (p.drawing && p.drawing.faceJoin) || {}; return p.rooms.filter(r => r.src === 'plan' && (r.faces || []).length).map(r => {
          const fs = new Set(r.faces); Object.entries(J).forEach(([a, b]) => { if (fs.has(b)) fs.add(+a); });
          return { faces: [...fs], color: r.color, name: r.name || '部屋', area: r.area }; }); },
        dtexts: () => textMarksOf(faceMarks()),
        onTap: (i, how) => { if (how && how.around && !sel.has(i) && !owner().has(i)) { const f = p.drawing.plan.faces.find(z => z.i === i); toast(`区画の無い所（机・棚などの所）を押したので、まわりの区画${f ? f.no : ''} を選びました`, { ms: 4000 }); }
          if (!sel.has(i) && owner().has(i)) {
            /* もう部屋に入っている区画は、タップしただけでは選ばない（まとめた後に触ってしまっても崩れないように）。選び直す時は知らせのボタンで */
            const r = p.rooms.find(q => (q.faces || []).includes(i) || (q.faces || []).includes(joinRoot(i))), f = p.drawing.plan.faces.find(z => z.i === i);
            toast(`区画${f ? f.no : ''} は部屋「${r ? r.name : ''}」に入っています。選び直す時は「選ぶ」を押してください`, { ms: 5000, action: '選ぶ', onAction: () => { sel.add(i); paintSel(); } }); return; }
          if (sel.has(i)) sel.delete(i); else { sel.add(i); const fm = faceMarks(), m = fm && (fm[i] || fm[String(i)]); if (m) toast((m.type === 'off' || m.type === 'join') ? m.why : (m.s === 'out' ? '部屋ではないと見ている区画です：' : '決めきれない区画です：') + m.why + '。部屋にする時は、このまま選んで進められます', { ms: 7000 }); } paintSel(); },
        onDragStart: (x, y, sc) => dragStart(x, y, sc),
        /* 虫めがねの吸い付き：測る・カッター・壁の範囲・照明の置き場所で、線の端や線の上に吸い付く */
        snap: (x, y, sc) => (mode === 'meas' || mode === 'cut' || mode === 'zsplit' || (mode === 'wall' && wway === 'range') || (mode === 'lineoff' && loway === 'out')) ? snapPt(p.drawing.plan, x, y, sc * 40) : [x, y],
        onPoint: (x, y, sc, lp) => {
          const snapAt = (t) => lp ? [x, y] : snapPt(p.drawing.plan, x, y, t);
          if (mode === 'fix') {
            const k = fxList().findIndex(f => x >= f.b[0] - 0.03 && x <= f.b[2] + 0.03 && y >= f.b[1] - 0.03 && y <= f.b[3] + 0.03);
            if (k >= 0) { fsel = fsel === k ? -1 : k; addAt = null; } else { fsel = -1; addAt = [x, y]; }
            paintSel(); return;
          }
          if (mode === 'light') {
            const d = p.drawing; d.lights = d.lights || []; d.switches = d.switches || []; d.outlets = d.outlets || []; d.link = d.link || {};
            const tol = Math.min(Math.max(0.2, sc * 14), 0.6), near = list => { let b = -1, bd = tol; list.forEach((q, k) => { const dd = Math.hypot(q.x - x, q.y - y); if (dd < bd) { bd = dd; b = k; } }); return b; };   // 広い図面の全体表示で許容が何mにもならないように（上限60cm）。いちばん近い物
            const redo = () => { syncDemoLines(p); touch(p); paintSel(); };
            const undoT = (msg, fn) => toast(msg, { action: '元に戻す', onAction: () => { fn(); redo(); } });
            /* 分電盤は何個でも置ける（前のKAKUと同じ。かつ「分電盤連続で置けなくなった？」）：何も無い所をタップで置く・分電盤をタップで消す・なぞって動かす。各部屋は同じ階のまとまりのいちばん近い分電盤から引く */
            if (ltool === 'panel') { const P = panelsOf(d, true), k = P.findIndex(q => Math.hypot(q.x - x, q.y - y) < tol * 1.5);
              /* 分電盤をタップ：向きを90°回す（前のKAKUと同じ。かつ「向き変えたいな」）。消す時は知らせの［消す］ */
              if (k >= 0) { const one = P[k], r0 = one.rot || 0; one.rot = (r0 + 90) % 360; redo();
                toast(`分電盤の向きを変えました（${one.rot}°）`, { action: '消す', onAction: () => { const Q = panelsOf(d, true), j = Q.indexOf(one); if (j >= 0) Q.splice(j, 1); one.rot = r0; redo(); toast('分電盤を消しました', { action: '元に戻す', onAction: () => { panelsOf(d, true).push(one); redo(); } }); } }); return; }
              P.push({ id: uid('P'), x: r3(x), y: r3(y) }); redo(); undoT(`分電盤を置きました（${P.length} 個目）`, () => { const Q = panelsOf(d, true), j = Q.length - 1; if (j >= 0) Q.splice(j, 1); }); return; }
            if (ltool === 'link') {
              if (!linkSel) { const k = near(d.lights); if (k < 0) { toast('照明をタップしてください', { bad: true }); return; } linkSel = d.lights[k].id; paintSel(); return; }
              const W = lightWires(p), all = [...W.sws, ...d.switches.map(q => ({ key: q.id, l: [q.x, q.y] }))];
              let best = null, bd = tol; all.forEach(s0 => { const dd = Math.hypot(s0.l[0] - x, s0.l[1] - y); if (dd < bd) { bd = dd; best = s0; } });
              /* 2つ目に照明をタップした時：その照明と同じスイッチにつなぎ、線はその照明から引く（渡り。かつ「配線も照明同時タップで繋ぎ直したい」） */
              let viaL = null;
              if (!best) { const k2 = near(d.lights); const lt = k2 >= 0 ? d.lights[k2] : null;
                if (lt && lt.id !== linkSel && W.assign[lt.id]) { viaL = lt; best = /^n:/.test(W.assign[lt.id]) ? { key: 'none' } : all.find(s0 => s0.key === W.assign[lt.id]) || { key: W.assign[lt.id] }; } }   // スイッチ無しの照明にタップした時は、スイッチ無しにする
              if (!best) { linkSel = null; paintSel(); toast('スイッチか照明をタップしてください。やめました'); return; }
              const id = linkSel, was = d.link[id], wasV = (d.linkVia || {})[id]; d.link[id] = best.key; d.linkVia = d.linkVia || {}; if (viaL) d.linkVia[id] = 1; else delete d.linkVia[id];   // 渡り（照明から引く）は照明をタップして選んだ時だけ
              linkSel = null; redo(); undoT(viaL ? '照明から線を引くようにつなぎ替えました' : 'つなぎ替えました', () => { if (was) d.link[id] = was; else delete d.link[id]; if (wasV) d.linkVia[id] = 1; else delete d.linkVia[id]; }); return;
            }
            if (ltool === 'sw') {
              /* スイッチ（黄＝自動・青＝置いた物のどちらも）をタップで消す。つながっていた照明は、残っているスイッチのうちいちばん近い物につなぎ直す
                 （かつ「いらないスイッチは消したい。消したら配線自動でしてくれるよね」）。ほかにスイッチが無ければ消さない */
              const W = lightWires(p), shown = [...W.sws, ...d.switches.filter(q => !W.sws.some(s0 => s0.key === q.id)).map(q => ({ key: q.id, l: [q.x, q.y] }))];
              let hit = null, hd = tol; shown.forEach(s0 => { const dd = Math.hypot(s0.l[0] - x, s0.l[1] - y); if (dd < hd) { hd = dd; hit = s0; } });
              if (hit) {
                const rest = shown.filter(s0 => s0.key !== hit.key), mine = Object.keys(W.assign).filter(k2 => W.assign[k2] === hit.key);
                                const sw0 = d.switches.map(q => ({ ...q })), link0 = { ...d.link };
                d.switches = d.switches.filter(q => q.id !== hit.key); Object.keys(d.link).forEach(q => { if (d.link[q] === hit.key) delete d.link[q]; });
                /* つなぎ直し先：同じ部屋（図面から作った部屋は、その部屋の区画・まとめた区画ぜんぶ。部屋にしていなければその区画）の、ほかの照明がつながっているスイッチ（いちばん近い照明の物）。
                   無ければスイッチ無し（'none'。電源だけを部屋の中の照明どうしでつなぐ）。ほかの部屋の照明・スイッチにはつながない
                   （かつ「女子トイレと男子トイレが配線つながる。人感センサーのダウンライトだとおかしい」。前は区画から35cm以内のスイッチを見ていたので、隣の部屋のスイッチを拾うことがあった） */
                const L = new Map(d.lights.map(q => [q.id, q])), F = d.plan.faces;
                const fOf = q => { let b = null; F.forEach(f => { if (pip(q[0], q[1], f.poly) && (!b || f.area < b.area)) b = f; }); return b; };
                const J = d.faceJoin || {}, roomFaces = lt => { const f = fOf([lt.x, lt.y]); const r = lt.room ? p.rooms.find(rr => rr.id === lt.room) : f ? p.rooms.find(rr => rr.src === 'plan' && (rr.faces || []).includes(f.i)) : null;
                  const S0 = new Set(r && r.faces ? r.faces : f ? [f.i] : []); Object.keys(J).forEach(k => { if (S0.has(J[k])) S0.add(+k); }); return S0; };
                let nNone = 0;
                mine.forEach(k2 => { const lt = L.get(k2); if (!lt) return; const RF = roomFaces(lt); let b = null, bd = 1e9;
                  d.lights.forEach(o => { if (o.id === k2 || mine.includes(o.id)) return; const sk = W.assign[o.id]; if (!sk || /^n:/.test(sk) || sk === hit.key) return; const fo = fOf([o.x, o.y]); if (!fo || !RF.has(fo.i)) return;
                    const dd = Math.abs(o.x - lt.x) + Math.abs(o.y - lt.y); if (dd < bd) { bd = dd; b = sk; } });
                  if (b) d.link[k2] = b; else { d.link[k2] = 'none'; nNone++; } if (d.linkVia) delete d.linkVia[k2]; });
                redo(); undoT(mine.length ? (nNone ? `スイッチを消しました（照明 ${nNone} 台はスイッチ無しで、同じ部屋の照明どうしだけでつなぎます）` : `スイッチを消しました（照明 ${mine.length} 台を、同じ部屋のほかのスイッチにつなぎました）`) : 'スイッチを消しました', () => { d.switches = sw0; d.link = link0; }); return;
              }
              d.switches.push({ id: uid('S'), x: r3(x), y: r3(y) }); redo(); return;
            }
            if (ltool === 'out') {
              const k = near(d.outlets);
              if (k >= 0) { const was = d.outlets.splice(k, 1)[0]; redo(); undoT('コンセントを消しました', () => d.outlets.push(was)); return; }
              d.outlets.push({ id: uid('O'), x: r3(x), y: r3(y), item: lset.out || 'e-cone' }); redo(); return;
            }
            const k = near(d.lights);
            if (k >= 0) { const was = d.lights.splice(k, 1)[0]; delete d.link[was.id]; redo(); undoT('照明を消しました', () => d.lights.push(was)); return; }
            const r = p.rooms.find(rr => rr.src === 'plan' && (rr.faces || []).some(i => { const f = d.plan.faces.find(z => z.i === i); return f && pip(x, y, f.poly); }));
            const fc = r ? null : d.plan.faces.find(f => pip(x, y, f.poly));
            if (!r && !fc) { toast('区画の中をタップしてください', { bad: true }); return; }
            const nl = { id: uid('L'), x: Math.round(x * 20) / 20, y: Math.round(y * 20) / 20, item: lset.item, room: r ? r.id : null, face: fc ? fc.i : undefined };
            /* 同じ部屋（区画）の照明が全部スイッチ無しなら、足した照明もスイッチ無し（自動のスイッチが戻ってこないように） */
            const same = d.lights.filter(o => r ? o.room === r.id || (r.faces || []).some(i => { const f = d.plan.faces.find(z => z.i === i); return f && pip(o.x, o.y, f.poly); }) : fc && pip(o.x, o.y, fc.poly));
            d.lights.push(nl); if (same.length && same.every(o => d.link[o.id] === 'none')) d.link[nl.id] = 'none';
            redo(); return;
          }
          if (mode === 'place') {
            const d = p.drawing; d.places = d.places || [];
            if (pset.where === 'area') { const f = d.plan.faces.find(z => pip(x, y, z.poly)); if (f) { if (pfaces.has(f.i)) pfaces.delete(f.i); else pfaces.add(f.i); paintSel(); } return; }
            if (pset.where === 'line') { const i = nearestSeg(d.plan, x, y, sc * 18); if (i >= 0) { if (psegs.has(i)) psegs.delete(i); else psegs.add(i); paintSel(); } return; }
            const tol = Math.min(Math.max(0.15, sc * 14), 0.35);
            let hit = null, bd = tol; d.places.filter(q => q.where === 'pt').forEach(q => { const dd = Math.hypot(q.p[0] - x, q.p[1] - y); if (dd < bd) { bd = dd; hit = q; } });
            if (hit) { psel = psel === hit.id ? null : hit.id; paintSel(); return; }
            if (psel) { psel = null; paintSel(); return; }
            const np = { id: uid('P'), item: pset.item, where: 'pt', p: [r3(x), r3(y)] }; d.places.push(np);
            syncDemoLines(p); touch(p); paintSel();
            toast(itemName(np.item) + ' を置きました', { action: '元に戻す', onAction: () => { d.places = d.places.filter(q => q !== np); syncDemoLines(p); touch(p); paintSel(); } });
            return;
          }
          if (mode === 'lineoff') {
            const d = p.drawing;
            if (loway === 'line') { const i = nearestSeg(d.plan, x, y, sc * 18); loSel = i >= 0 && i !== loSel ? i : -1; paintSel(); return; }
            const q = snapAt(sc * 44);
            if (!outA) { outA = q; paintSel(); return; }
            const R = [Math.min(outA[0], q[0]), Math.min(outA[1], q[1]), Math.max(outA[0], q[0]), Math.max(outA[1], q[1])].map(r3); outA = null;
            if (R[2] - R[0] < 0.1 || R[3] - R[1] < 0.1) { toast('範囲が小さすぎます。もう一度、四角の角を2か所タップしてください', { bad: true }); paintSel(); return; }
            const z = { id: uid('o'), poly: [[R[0], R[1]], [R[2], R[1]], [R[2], R[3]], [R[0], R[3]]] };
            d.outZones = [...(d.outZones || []), z]; outRegeo(); touch(p); paintSel();
            toast('工事対象外の範囲を入れました。部屋の床・天井・壁から引いています', { action: '元に戻す', onAction: () => { d.outZones = (d.outZones || []).filter(o => o !== z); outRegeo(); touch(p); paintSel(); } });
            return;
          }
          if (mode === 'wall' && wway === 'range') { wpts.push(snapAt(sc * 44)); paintSel(); return; }
          if (mode === 'wall') {
            const i = nearestSeg(p.drawing.plan, x, y, sc * 18);
            if (i >= 0) { if (wsel.has(i)) wsel.delete(i); else wsel.add(i); paintSel(); }
            return;
          }
          if (mode === 'zsplit') { if (zsplit) { zsplit.pts.push(snapAt(sc * 44)); paintSel(); } return; }
          if (mode === 'cut') {
            const q = snapAt(sc * 44);
            if (!cutA) { cutA = q; paintSel(); return; }
            const rect = [Math.min(cutA[0], q[0]), Math.min(cutA[1], q[1]), Math.max(cutA[0], q[0]), Math.max(cutA[1], q[1])].map(r3);
            cutA = null;
            if (rect[2] - rect[0] < 0.05 || rect[3] - rect[1] < 0.05) { toast('範囲が小さすぎます。もう一度、四角の角を2か所タップしてください', { bad: true }); paintSel(); return; }
            p.drawing.hatsu = p.drawing.hatsu || [];
            p.drawing.hatsu.push({ id: uid('h'), rect, w: r3(rect[2] - rect[0]), l: r3(rect[3] - rect[1]), t: 100, d: 300, cut: true, back: true });
            syncDemoLines(p); touch(p); paintSel(); toast('カッターの範囲を明細に入れました（厚みと深さを確かめてください）', { ms: 4000 });
            return;
          }
          if (mode === 'meas') {
            const q = snapAt(sc * 44);
            if (!meas.cont && meas.pts.length >= 2) meas.pts = [];
            meas.pts.push(q); meas.redo = []; paintSel();
          }
        }
      });
      /* 図を大きく出していた時は、描き直しても同じ図のまま */
      if (sheetZoom) { const x = sheetsOf(p.drawing).find(q => q.key === sheetZoom); if (!x) sheetZoom = ''; else if (!keepV && view.zoomTo) view.zoomTo(x.box); }   // 前の拡大を引き継いだ時はそちらが先
      paintSel();
    }
    const fi = body.querySelector('#dwgFile');
    if (fi) fi.onchange = async e => {
      const files = [...e.target.files]; if (!files.length) return;
      const cad0 = files.find(f => /\.(jww|jwc|dxf)$/i.test(f.name)); if (cad0) cadFiles.set(p.id, files);
      /* 同じ図面を読み直す時は、外した線・工事対象外の範囲を引き継ぐ */
      const sameFile = !!(cad0 && p.drawing && p.drawing.fileName === cad0.name), keepLO = sameFile ? (p.drawing.lineOff || null) : null, keepOut = sameFile ? (p.drawing.outZones || null) : null;
      if (p.drawing && p.rooms.some(r => r.src === 'plan') && !(await ask('図面を読み直しますか？', '今の図面から作った部屋は残りますが、図面とのつながりは外れます。', { ok: '読み直す' }))) { e.target.value = ''; return; }
      const st = body.querySelector('#dwgStatus');
      /* 読み込み中の表示：くるくる（計算で画面が止まっていても回る）と、今どの段階か */
      const t0 = Date.now();
      const showStep = msg => { if (!st) return; st.innerHTML = `<span class="kspin" aria-hidden="true"></span><span>${esc(msg)}…</span><span class="muted">（${Math.round((Date.now() - t0) / 1000)}秒）</span><div class="small muted">大きい図面は少し時間がかかります。そのままお待ちください。</div>`; };
      showStep('図面を読み込んでいます');
      try {
        const cad = files.find(f => /\.(jww|jwc|dxf)$/i.test(f.name));
        let res;
        const pic = !cad && files.find(f => /^image\//.test(f.type) || /\.(png|jpe?g|heic|webp|gif)$/i.test(f.name));
        if (pic) { if (st) st.textContent = ''; openSk(pic); e.target.value = ''; return; }
        if (cad) {
          /* 新しい読み取り・段階3：壁ではなさそうな線のまとまり（細かい線・寸法・表や図枠）を外して、区画を探し直した結果も一緒にもらう（別に覚えるだけ） */
          res = await readWithFixtures(cad, { step: showStep, lineOff: keepLO, regroup: (out, raw) => {
            try { const A1 = analyzeFrame({ segs: out.longSegs && out.longSegs.length ? out.longSegs : out.plan.segs, faces: out.plan.faces, texts: out.texts || [], fixtures: out.fixtures || [], doors: out.doorList || [] });
              const g = groupRoles({ segs: raw.segs, groups: raw.groups, texts: out.texts || [], regions: A1.regions });
              out.roles = {}; Object.keys(g.off).forEach(i => { const r = g.off[i], o = g.stats.find(x => x.gi === +i); out.roles[r] = (out.roles[r] || 0) + (o ? o.n : 0); });
              return Object.keys(g.off).map(Number);
            } catch (e2) { console.warn('線の役割を見分けられませんでした', e2); return []; } } });
          /* 家具で割れた区画をまとめる：試しの区画（家具の線を外して壁の線だけで探した区画）1つの中に、今の区画が2つ以上入る所だけ置き換える（js/facemerge.js）。
           * 元の区画は plan.split に覚えるので「分ける」で戻せる */
          if (res.v2 && res.v2.faces && res.v2.faces.length) { try {
            const M = mergeSplitFaces({ faces: res.plan.faces, open: res.open || {}, v2faces: res.v2.faces, v2open: res.v2.open || {}, fixtures: res.fixtures || [], doors: res.doorList || [], segs: res.allSegs || res.plan.segs || [], texts: res.texts || [] });
            if (M.merged.length) { res.plan = { ...res.plan, faces: M.faces, split: M.split }; res.open = M.open; }
          } catch (e2) { console.warn('家具で割れた区画をまとめられませんでした', e2); } }
          /* 部屋の中の小さい箱（ロッカー・自販機・棚など）は、まわりの部屋の区画に入れる（js/facemerge.js の absorbBoxes） */
          try { const B = absorbBoxes({ faces: res.plan.faces, open: res.open || {}, fixtures: res.fixtures || [], doors: res.doorList || [], segs: res.plan.segs || [] });
            if (B.merged.length) { res.plan = { ...res.plan, faces: B.faces, split: { ...(res.plan.split || {}), ...B.split } }; res.open = B.open; }
          } catch (e2) { console.warn('部屋の中の箱をまとめられませんでした', e2); }
          orderFacesOf(res.plan); res.plan.order = 2;
        } else res = await importDrawing(files);
        if (!res.plan || !res.plan.faces.length) { const msg = res.message || '部屋の区画が見つかりませんでした'; if (st) st.textContent = msg;
          const img = !cad && files.find(f => /\.(pdf|png|jpe?g|heic|webp|gif)$/i.test(f.name) || /^image\/|pdf/.test(f.type));
          if (img && await ask('区画が見つかりませんでした', 'この図を下に敷いて、部屋の角をなぞって拾いますか？（写真・スキャンのPDFは、なぞって拾えます）', { ok: 'なぞって拾う' })) { openSk(img); return; }
          toast(msg, { bad: true }); return; }
        /* DXF の寸法はエンジンが拾わないので、同じファイルから別に抜いて覚える（表示だけ。区画・器具・見積には使わない）。JWW は寸法が線と文字で出るので空のまま */
        let dims = [];
        if (cad && /\.dxf$/i.test(cad.name)) { try { dims = extractDxfDims(await cad.arrayBuffer()); } catch (e2) { console.warn('寸法の読み取りに失敗', e2); } }
        /* 寸法の答え合わせ（寸法の値と図形の距離の比率）。これも表示だけ：縮尺を自動で直すことはしない */
        let dimCheck = null;
        if (dims.length) { try { dimCheck = checkDimensions(dims); } catch (e2) { console.warn('寸法の答え合わせに失敗', e2); } }
        p.rooms.forEach(r => { if (r.src === 'plan') { r.src = 'plan-old'; delete r.faces; } });
        /* 手入力の換算係数は、同じ名前の図面を読み直した時だけ引き継ぐ（別の図面には持ち込まない） */
        const prevScaleUser = (p.drawing && p.drawing.fileName === (cad ? [cad] : files).map(f => f.name).join('、')) ? userCoef(p.drawing) : null;
        p.drawing = { fileName: (cad ? [cad] : files).map(f => f.name).join('、'), at: Date.now(), plan: res.plan, fixtures: cad ? res.fixtures : null, open: cad ? res.open : null, doors: cad ? (res.doorList || []) : [], fixG: cad ? res.fixG : '', fixGd: cad ? res.fixGd : '', dims, dimCheck,
          ...(keepLO && ((keepLO.keys || []).length || (keepLO.segs || []).length) ? { lineOff: keepLO } : {}), ...(keepOut && keepOut.length ? { outZones: keepOut } : {}) };
        if (prevScaleUser !== null) p.drawing.scaleUser = prevScaleUser;
        /* 器具の救済：壁も器具も同じレイヤーに描く図面では、読み取りが壁のレイヤーごと外して器具が消える。
         * 読み取りには触らず、ここでだけ救済分（src:'rescue'）を足す。読み取りが拾った器具と重なる物は出さない（そちらが優先） */
        let allFixtures = res.fixtures || [];
        if (cad && res.rescue && res.rescue.ents && res.rescue.ents.length) {
          try {
            const rescued = rescueFixtures(res.rescue.ents, res.plan, res.rescue.rot || 0, res.fixtures || [], res.rescue.roles || {});
            if (rescued.length) { allFixtures = mergeFixtures(res.fixtures || [], rescued); p.drawing.fixtures = allFixtures; }
          } catch (e2) { console.warn('器具の救済に失敗', e2); }
        }
        /* 器具の形の特徴：輪郭の線（グループのON/OFFに関係ない全線。取れなければ plan の線）
         * から特徴だけを取り出して器具に付け足す（sf）。使うのは表示の辞書判定だけで、
         * 器具の種類・見積は変えない。線そのものは案件に覚えない */
        if (cad) { try {
          const pool = (res.allSegs && res.allSegs.length) ? res.allSegs : [...(res.plan.segs || []), ...(res.plan.dsegs || [])];
          const sidx = createShapeIndex(pool);
          allFixtures.forEach(x => { if (!x || !x.b) return; const f = sidx.featuresFor(x.b); if (f) x.sf = { short: f.short, long: f.long, arcShare: f.arcShare, closed: f.closed, innerClosed: f.innerClosed, innerShapes: (f.innerShapes || []).slice(0, 3), dividers: f.dividers, n: f.n, tankBand: f.tankBand != null ? f.tankBand : null }; });
        } catch (e2) { console.warn('器具の形の取り出しに失敗', e2); } }
        /* 机・椅子などの家具：線の集まりから形の候補を切り出して覚える（判定はシンボル辞書。器具・見積の数字は変えない） */
        if (cad) { try { p.drawing.furn = detectFurniture(res.plan.segs || [], allFixtures, res.doorList || []); } catch (e2) { console.warn('家具の検出に失敗', e2); p.drawing.furn = []; } }
        /* シンボルの大きさの自動補正：寸法の答え合わせと、拾った器具・家具の候補から倍率を推定して覚える。
         * 効くのは辞書の寸法判定だけ（図面の線・区画・部屋・見積は変えない）。証拠が弱い時は補正なし（factor 1） */
        if (cad) { try { p.drawing.symScale = estimateSymScale({ dimCheck, fixtures: allFixtures, clusters: p.drawing.furn || [] }); } catch (e2) { console.warn('シンボルの大きさの推定に失敗', e2); } }
        /* 新しい読み取り（js/reader2）：図枠・表の印を作って覚えておく。今の読み取りの結果（区画・器具）は変えない。画面に出すのは「新しい読み取り」を選んだ時だけ */
        /* 解析を後で作り直せるように、文字・長い線・ドアを覚えておく（解析の作りを直した時、開いただけで新しい解析になる） */
        if (cad) p.drawing.src2 = { texts: res.texts || [], rawTexts: res.rawTexts || null, segs: res.longSegs && res.longSegs.length ? res.longSegs : [], doors: res.doorList || [] };
        if (cad) { try { p.drawing.analysis = analyzeFrame({ segs: res.longSegs && res.longSegs.length ? res.longSegs : res.plan.segs, faces: res.plan.faces, texts: res.texts || [], fixtures: allFixtures, doors: res.doorList || [] }); } catch (e2) { console.warn('新しい読み取りの解析に失敗', e2); } }
        /* ゾーン分けは解析の後（表・表題欄・図枠と確定した区画を候補に入れないため、印を渡す） */
        if (cad) { try { p.drawing.zones = computeZones({ segs: res.plan.segs || [], faces: res.plan.faces || [], texts: res.texts || [], doors: res.doorList || [], marks: (p.drawing.analysis && p.drawing.analysis.marks) || null, fixtures: allFixtures }).map(z => ({ id: uid('z'), fixed: false, ...z })); } catch (e2) { console.warn('ゾーン分けに失敗', e2); p.drawing.zones = []; } }
        /* 補足区画：区画として拾えなかった床を、自前の輪郭化（js/polygonize.js）で線そのものから作る。
         * エンジンの区画と重なる物は作らない（エンジン優先）。表示と部屋の見分けだけに使い、部屋・ゾーン・見積には入れない。
         * 表・仕上げ表のラベル帯の中の輪は、表の検出（detectTableAreas）と解析の領域（table/title）を使って最初から作らない */
        if (cad) { try {
          const tb = detectTableAreas({ faces: res.plan.faces || [], texts: res.texts || [], fixtures: allFixtures, doors: res.doorList || [] }).boxes;
          const rb = ((p.drawing.analysis && p.drawing.analysis.regions) || []).filter(r => r.type === 'table' || r.type === 'title').map(r => r.box);
          p.drawing.polyFaces = supplementFaces({ segs: res.plan.segs || [], faces: res.plan.faces || [], fixtures: allFixtures, texts: res.texts || [], doors: res.doorList || [], tableBoxes: [...tb, ...rb] });
        } catch (e2) { console.warn('補足区画の作成に失敗', e2); p.drawing.polyFaces = []; } }
        if (cad && res.v2) { try { const P2 = { faces: res.v2.faces }; orderFacesOf(P2);
          /* 扉の無い開口は「区画の辺に壁の線が無い所」で決めるので、区画の形が壁の線に沿っていないと、辺のほとんどが開口になる。
           * 開口が周りの3割以上になる区画は、形が合っていないと見て、扉の無い開口を引かない（分からない物を引かない。ドアは残す） */
          const op2 = {}; let drop = 0;
          Object.keys(res.v2.open || {}).forEach(k => { const f = P2.faces.find(x => String(x.i) === k), runs = res.v2.open[k], g = runs.filter(r => r.ty !== 'd').reduce((t, r) => t + r.len, 0);
            const keep = f && g >= (Number(f.peri) || 0) * 0.3 ? (drop++, runs.filter(r => r.ty === 'd')) : runs; if (keep.length) op2[k] = keep; });
          /* 今の読み取りと同じ所を指している区画は、今の読み取りの数字（形・広さ・周り・開口）をそのまま使う（かつ「ほぼ同じじゃあかん」）。
             同じ所＝お互いの形の中の点がお互いの形の中にあり、広さの差が 5% 以内。探し直しで変わった所（机でまとまった所など）だけ新しい数字になる */
          /* 形の中に必ず入る点（L字の区画は真ん中が形の外に出るので、横の線で切った一番広い所のまん中を使う） */
          const inPt = (P) => { let ya = Infinity, yb = -Infinity; P.forEach(q => { ya = Math.min(ya, q[1]); yb = Math.max(yb, q[1]); }); let best = null, bw = -1;
            for (let t = 1; t < 8; t++) { const y = ya + (yb - ya) * t / 8, xs = []; for (let i = 0, j = P.length - 1; i < P.length; j = i++) { const a = P[i], b = P[j]; if ((a[1] > y) !== (b[1] > y)) xs.push(a[0] + (y - a[1]) * (b[0] - a[0]) / (b[1] - a[1])); }
              xs.sort((u, v) => u - v); for (let k = 0; k + 1 < xs.length; k += 2) if (xs[k + 1] - xs[k] > bw) { bw = xs[k + 1] - xs[k]; best = [(xs[k] + xs[k + 1]) / 2, y]; } }
            return best || [P[0][0], P[0][1]]; };
          let same = 0; const V1 = res.plan.faces || [], O1 = res.open || {}, used = new Set();
          P2.faces.forEach(f2 => { if (!f2.poly || f2.poly.length < 3) return;
            const q2 = inPt(f2.poly), f1 = V1.find(o => { if (used.has(o.i) || !o.poly || o.poly.length < 3 || Math.abs(o.area - f2.area) > Math.max(o.area, f2.area) * 0.05) return false; const q1 = inPt(o.poly); return pip(q1[0], q1[1], f2.poly) && pip(q2[0], q2[1], o.poly); });
            if (!f1) return; used.add(f1.i); same++;
            ['area', 'peri', 'poly', 'cx', 'cy', 'ch', 'name'].forEach(k => { if (f1[k] !== undefined) f2[k] = f1[k]; });
            if (f2.xc !== undefined) delete f2.xc;
            const k2 = String(f2.i), r1 = O1[String(f1.i)]; if (r1 && r1.length) op2[k2] = r1; else delete op2[k2]; });
          p.drawing.v2 = { faces: P2.faces, open: op2, openDrop: drop, same, roles: res.roles || {}, single: res.single || 0, analysis: analyzeFrame({ segs: res.longSegs && res.longSegs.length ? res.longSegs : res.plan.segs, faces: P2.faces, texts: res.texts || [], fixtures: allFixtures, doors: res.doorList || [], shapes: true }) }; } catch (e2) { console.warn('探し直した区画の解析に失敗', e2); } }
        sel.clear(); touch(p); draw();
        toast(`区画を ${res.plan.faces.length} 個${cad ? `、器具を ${allFixtures.filter(x => x.t !== 'other').length} 個` : ''}見つけました`);
      } catch (err) {
        if (st) st.textContent = '読み込めませんでした：' + err.message;
        toast('図面を読み込めませんでした：' + err.message, { bad: true });
      }
    };
    $('#addRoom').onclick = () => {
      p.rooms.push({ id: uid('r'), name: `部屋 ${String(p.rooms.length + 1).padStart(2, '0')}`, shape: 'rect', w: '', d: '', h: '', qty: 1, doors: 1, winCount: 1, windows: [] });   // 前のKAKUと同じ：手で作る部屋はドア1・窓1から（壁から 3.2㎡ 引く）。無い部屋は 0 に直す
      touch(p); draw(); refresh();
      const last = body.querySelector('.roomc:last-child [data-rk="w"]'); if (last) last.focus();
    };
    refresh();
  };
  body.addEventListener('input', e => {
    const card = e.target.closest('[data-room]'); if (!card) return;
    const r = p.rooms.find(x => x.id === card.dataset.room); if (!r) return;
    if (e.target.dataset.rk) r[e.target.dataset.rk] = e.target.dataset.rk === 'name' ? e.target.value : e.target.value === '' ? '' : Number(e.target.value);
    if (e.target.dataset.wk) { const w = r.windows[+e.target.dataset.wi]; w[e.target.dataset.wk] = e.target.value === '' ? '' : Number(e.target.value); }
    if (e.target.dataset.pk) { const x = (r.parts || [])[+e.target.dataset.pi]; if (x) { const k = e.target.dataset.pk, v = e.target.value;
      if (k === 's') { x.s = v.startsWith('-') ? -1 : 1; x.k = v === '-1w' ? 'wall' : v === '-1c' ? 'col' : undefined; } else x[k] = v === '' ? '' : Number(v); } }
    touch(p); refresh();
  });
  body.addEventListener('change', e => {
    if (e.target.matches('[data-holes]')) { holesOn = e.target.checked; paintSel(); return; }
    if (e.target.matches('[data-sheet]')) {
      const d = p.drawing; d.sheetUse = { ...(d.sheetUse || {}), [e.target.dataset.sheet]: e.target.checked };
      /* 使わない図にした時は、その図の中に自動で並べた照明もすぐ消す（並べ直さなくても消えるように）。元に戻すで戻せる */
      let gone = [];
      if (!e.target.checked) { const sh = sheetsOf(d).find(x => x.key === e.target.dataset.sheet), b = sh && sh.box;
        if (b) { const inB = x => x.x >= b[0] && x.x <= b[2] && x.y >= b[1] && x.y <= b[3]; gone = (d.lights || []).filter(x => x.auto && !x.room && inB(x)); if (gone.length) { d.lights = d.lights.filter(x => !gone.includes(x)); syncDemoLines(p); } } }
      touch(p); draw();
      if (gone.length) toast(`この図の区画は使いません（灰色になります）。この図の中に自動で並べた照明 ${gone.length} 台も消しました`, { ms: 6000, action: '照明を戻す', onAction: () => { d.lights = [...(d.lights || []), ...gone]; syncDemoLines(p); touch(p); draw(); } });
      else toast(e.target.checked ? 'この図を使います' : 'この図の区画は使いません（灰色になります）'); return;
    }
    if (e.target.matches('[data-reader2]')) {
      /* 入れる：表題欄・表の中の「器具」を「器具ではない」にする（元の種類は r2 に覚える）。外す：元の種類に戻す */
      const d = p.drawing, fxs = d.fixtures || [], on = e.target.checked;
      /* 探し直した区画がある図面は、区画ごと入れ替える（今までの区画は v1 に取っておく）。区画が変わるので、この図面から作った部屋のつながりは外す */
      const swap = on ? !!(d.v2 && !d.v1) : !!d.v1;
      if (swap && p.rooms.some(r => r.src === 'plan') && !confirm('区画が入れ替わるので、この図面から作った部屋は残りますが、図面とのつながりは外れます。切り替えますか？')) { e.target.checked = !on; return; }
      if (!on) fxs.forEach(x => { if (x.r2) { if (x.t === 'other') x.t = x.r2; delete x.r2; } });
      if (swap) {
        p.rooms.forEach(r => { if (r.src === 'plan') { r.src = 'plan-old'; delete r.faces; } }); sel.clear();
        /* 手で囲んで足した区画（hand）は、どちらの読み取りにも持って行く（切り替えで黙って消えないように） */
        const hands = d.plan.faces.filter(f => f.hand), withHand = F => F.filter(f => !f.hand).concat(hands);
        if (on) { d.v1 = { faces: d.plan.faces.filter(f => !f.hand), open: d.open, analysis: d.analysis }; d.plan = { ...d.plan, faces: withHand(d.v2.faces) }; d.open = d.v2.open; d.analysis = d.v2.analysis; }
        else { d.v2 = { ...d.v2, faces: d.plan.faces.filter(f => !f.hand) }; d.plan = { ...d.plan, faces: withHand(d.v1.faces) }; d.open = d.v1.open; d.analysis = d.v1.analysis; delete d.v1; }
      }
      const outs = (d.analysis && d.analysis.fxOut) || [];
      if (on) { p.drawing.reader = 'v2'; outs.forEach(o => { const x = fxs[o.k]; if (x && x.t === o.t && !x.edited) { x.r2 = x.t; x.t = 'other'; } }); }
      else delete p.drawing.reader;
      touch(p); if (swap) { resetUndo(p); toast('読み取りを切り替えました。区画が入れ替わったので、これより前には「元に戻す」で戻せません', { ms: 5000 }); } draw(); return;
    }
    if (e.target.matches('[data-wset]')) { const k = e.target.dataset.wset, d = p.drawing;
      if (k === 'extra') d.wireExtra = Math.max(0, Math.min(100, Number(e.target.value) || 0));
      else { d.wireSet = { ...wireSetOf(d), [k]: k === 'out' ? e.target.checked : e.target.value }; }
      syncDemoLines(p); touch(p); paintSel(); toast('配線の設定を変えました（明細も直しました）'); return; }
    if (e.target.matches('[data-meas-cont]')) { meas.cont = e.target.checked; meas.pts = []; meas.redo = []; paintSel(); return; }
    if (e.target.id === 'oItem') { lset.out = e.target.value; return; }
    if (e.target.id === 'pItem') { pset.item = e.target.value; paintSel(); return; }
    if (e.target.id === 'pHow') { pset.how = e.target.value; paintSel(); return; }
    if (e.target.id === 'pEdge') { pset.edge = e.target.value === '' ? '' : Math.max(0, Number(e.target.value) || 0); paintSel(); return; }
    if (/^p(N|Cols|Rows|Gap)$/.test(e.target.id || '')) { const k = { pN: 'n', pCols: 'cols', pRows: 'rows', pGap: 'gap' }[e.target.id]; pset[k] = Math.max(k === 'gap' ? 100 : 1, Number(e.target.value) || 0); paintSel(); return; }
    if (e.target.id === 'pSelItem') { const q = (p.drawing.places || []).find(z => z.id === psel); if (q) { q.item = e.target.value; syncDemoLines(p); touch(p); paintSel(); } return; }
    if (e.target.id === 'lPitch') { lset.pitch = Math.max(0.9, Math.min(6, Number(e.target.value) || 2)); return; }
    if (e.target.id === 'lItem') { lset.item = e.target.value; lset.lm = DEF_LM[lset.item] || 800; const i = $('#lLm', body); if (i) i.value = lset.lm; return; }
    const wr = e.target.closest('[data-wall]'), hr = e.target.closest('[data-hatsu]');
    if (wr && e.target.dataset.wk) { const w = (p.drawing.walls || []).find(x => x.id === wr.dataset.wall); if (w) { const k = e.target.dataset.wk; if (k === 'more') { if (e.target.value) (w.more = w.more || []).push(e.target.value); } else if (k === 'room') w.room = e.target.value; else w[k === 'open' ? 'open' : 'h'] = Math.max(0, Number(e.target.value) || 0); syncDemoLines(p); touch(p); paintSel(); } return; }
    if (hr && e.target.dataset.hk) { const h = (p.drawing.hatsu || []).find(x => x.id === hr.dataset.hatsu); if (h) { const k = e.target.dataset.hk; h[k] = e.target.type === 'checkbox' ? e.target.checked : Math.max(0, Number(e.target.value) || 0); syncDemoLines(p); touch(p); paintSel(); } return; }
    const k = e.target.dataset.fx;
    if (k && fsel >= 0) { const x = fxList()[fsel]; if (!x) return; x[k] = e.target.value; x.edited = true; if (k === 'back' || k === 't') x.out = null; touch(p); paintSel(); }
  });
  body.addEventListener('click', async e => {
    const fsb = e.target.closest('[data-act="dwgFs"]');
    if (fsb) { dwgFs = !dwgFs; document.body.classList.toggle('dwg-fs-on', dwgFs); draw();
      /* 初めて全画面にした時だけ、操作の仕方を知らせる */
      if (dwgFs) { let seen = 0; try { seen = +localStorage.getItem('kakugen-fs-tip') || 0; localStorage.setItem('kakugen-fs-tip', String(seen + 1)); } catch (er) { /* 覚えられなくても続ける */ }
        if (seen < 2) toast('2本の指で広げる・ずらす、1本の指でタップして選べます。上の道具の列は横にずらせます。左上の「戻る」で元の画面に戻ります', { ms: 6500 }); }
      return; }
    const symb = e.target.closest('[data-sym]');
    if (symb) { const k = +symb.dataset.sym, s = symList(p.drawing).find(q => q.k === k);
      symSel = symSel === k ? -1 : k;
      if (s && view) { view.symShow(); view.paint(); if (symSel >= 0) { const pd = 0.6; view.zoomTo([s.b[0] - pd, s.b[1] - pd, s.b[2] + pd, s.b[3] + pd]); } }
      const symBox = body.querySelector('#dwgSym'); if (symBox) symBox.innerHTML = symSummary(p.drawing, symSel); return; }
    const scb = e.target.closest('[data-scalecheck]');
    if (scb) { const tg = scaleTargetFor(p.drawing);
      if (view && tg) { window.scrollTo({ top: 0, behavior: 'smooth' }); view.zoomTo(tg); }
      const done = () => { const dimBox = body.querySelector('#dwgDim'); if (dimBox) dimBox.innerHTML = dimSummary(p.drawing); const symBox = body.querySelector('#dwgSym'); if (symBox) symBox.innerHTML = symSummary(p.drawing, symSel); paintSel(); };
      setTimeout(() => openScaleEditor(p, done), view && tg ? 350 : 0);
      return; }
    const sreg = e.target.closest('[data-symreg]');
    if (sreg) { const s = symList(p.drawing).find(q => q.k === +sreg.dataset.symreg);
      if (s) openSymEditor({ name: s.mine ? s.category : '', short: Math.round(s.short), long: Math.round(s.long), feat: s.learnFeat || null }, () => { symSel = s.k; paintSel(); }); return; }
    const sed = e.target.closest('[data-symedit]');
    if (sed) { const u = userSyms().find(q => q.id === sed.dataset.symedit); if (u) openSymEditor(u, () => paintSel()); return; }
    const sdel = e.target.closest('[data-symdel]');
    if (sdel) { saveUserSyms(userSyms().filter(q => q.id !== sdel.dataset.symdel)); paintSel(); toast('自分の辞書から消しました'); return; }
    const zb = e.target.closest('[data-zsel],[data-zroom],[data-zsplit],[data-zname],[data-zmerge],[data-zdel],[data-zmake]');
    if (zb) {
      const d = p.drawing, Z = d.zones || (d.zones = []);
      const zref = () => { const zbox = body.querySelector('#dwgZone'); if (zbox) zbox.innerHTML = zoneSummary(d, zoneSel); };
      if (zb.dataset.zmake != null) {
        const fixed = Z.filter(z => z.fixed);
        const usedF = new Set(fixed.flatMap(z => z.faces));
        try {
          const fresh = computeZones({ segs: d.plan.segs || [], faces: d.plan.faces || [], texts: (d.src2 && d.src2.texts) || [], doors: d.doors || [], marks: (d.analysis && d.analysis.marks) || null, fixtures: d.fixtures || [] })
            .map(z => ({ ...z, faces: z.faces.filter(i => !usedF.has(i)) }))
            .filter(z => z.faces.length || z.area >= 20)
            .map(z => ({ id: uid('z'), fixed: false, ...z }));
          d.zones = [...fixed, ...fresh];
          zoneSel = ''; touch(p); zref(); paintSel();
          toast(fresh.length ? `ゾーン分けしました（全部で${d.zones.length}件）` : 'ゾーンにできる範囲が見つかりませんでした', fresh.length ? {} : { bad: true });
        } catch (e2) { console.warn('ゾーン分けに失敗', e2); toast('ゾーン分けに失敗しました', { bad: true }); }
        return;
      }
      const zid = zb.dataset.zsel || zb.dataset.zroom || zb.dataset.zsplit || zb.dataset.zname || zb.dataset.zmerge || zb.dataset.zdel;
      if (zb.dataset.zsel != null) { zoneSel = zoneSel === zid ? '' : zid; zref(); paintSel(); return; }
      const z = Z.find(q => q.id === zid);
      if (!z) return;
      if (zb.dataset.zroom != null) { zoneNameOnce = z.name || ''; sel.clear(); z.faces.forEach(i => sel.add(i)); zoneSel = ''; makeRooms(false); return; }
      if (zb.dataset.zsplit != null) { mode = 'zsplit'; zsplit = { id: z.id, pts: [] }; paintSel(); window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
      if (zb.dataset.zname != null) { openZoneEditor(z, () => { touch(p); zref(); paintSel(); }); return; }
      if (zb.dataset.zmerge != null) {
        const t = Z.find(q => q.id === zoneSel);
        if (t && t !== z) { t.faces = [...new Set([...t.faces, ...z.faces])]; t.area = Math.round((t.area + z.area) * 10) / 10; t.fixed = true; d.zones = Z.filter(q => q !== z); touch(p); zref(); paintSel(); toast(`「${t.name || '名前なし'}」に合体しました`); }
        return;
      }
      if (zb.dataset.zdel != null) { d.zones = Z.filter(q => q !== z); if (zoneSel === z.id) zoneSel = ''; touch(p); zref(); paintSel(); return; }
    }
    const sz = e.target.closest('[data-sheetzoom]');
    if (sz) { sheetZoom = sz.dataset.sheetzoom; const x = sheetsOf(p.drawing).find(q => q.key === sheetZoom); if (view && view.zoomTo) view.zoomTo(x ? x.box : null); return; }
    const mb = e.target.closest('[data-mode]');
    const ww = e.target.closest('[data-wway]');
    if (ww) { wway = ww.dataset.wway; wsel.clear(); wpts.length = 0; paintSel(); return; }
    const lw2 = e.target.closest('[data-loway]');
    if (lw2) { loway = lw2.dataset.loway; loSel = -1; outA = null; paintSel(); return; }
    const od = e.target.closest('[data-outdel]');
    if (od) { const d = p.drawing, was = d.outZones || []; d.outZones = was.filter(z => z.id !== od.dataset.outdel); outRegeo(); touch(p); paintSel(); toast('範囲を消しました', { action: '元に戻す', onAction: () => { d.outZones = was; outRegeo(); touch(p); paintSel(); } }); return; }
    const lt = e.target.closest('[data-ltool]');
    if (lt) { ltool = lt.dataset.ltool; linkSel = null; paintSel(); return; }
    const pw = e.target.closest('[data-pwhere]');
    if (pw) { pset.where = pw.dataset.pwhere; pfaces.clear(); psegs.clear(); psel = null; paintSel(); return; }
    if (mb) { mode = mb.dataset.mode; loSel = -1; outA = null; psel = null; pfaces.clear(); psegs.clear(); fsel = -1; addAt = null; cutA = null; linkSel = null; zsplit = null; wsel.clear(); wpts.length = 0; if (mode !== 'meas') { meas.pts = []; meas.redo = []; } paintSel(); return; }
    const fb = e.target.closest('[data-face]');
    if (fb) { const i = +fb.dataset.face; if (sel.has(i)) sel.delete(i); else sel.add(i); paintSel(); return; }
    const da = e.target.closest('[data-act]');
    if (da && !da.closest('[data-room]')) {
      const a = da.dataset.act;
      if (a === 'fixLines') return fixLinesDialog(p, () => {});
      if (a === 'r2name') { const v = (((p.drawing.analysis || {}).title || {}).project || [])[0]; if (v) { p.name = v; touch(p); refresh(); toast(`案件の名前を「${v}」にしました`); } return; }
      if (a === 'measClear') { meas.pts = []; meas.redo = []; paintSel(); return; }
      if (a === 'measBack') { const q = meas.pts.pop(); if (q) meas.redo.push(q); paintSel(); return; }
      if (a === 'measFwd') { const q = meas.redo.pop(); if (q) meas.pts.push(q); paintSel(); return; }   // 「1つ戻す」で消した点を1つ戻す（かつ「一つ進むボタンもよろしく」）
      if (a === 'measFace') {
        /* 壁の線で囲まれていなくて区画として拾えなかった部屋を、タップした角で囲んで区画にする（読み取りは変えない。図面に区画を1つ足すだけ）。
         * 図面の中身（plan）は「元に戻す」が同じ物を指しているので、書き換えずに新しい入れ物に替える */
        const P = meas.pts.map(q => [r3(q[0]), r3(q[1])]); if (P.length < 3) return;
        const area = r3(polyArea(P)); if (!(area > 0.05)) { toast('囲んだ広さが小さすぎます。角を3つ以上、ぐるっと一周するようにタップしてください', { bad: true }); return; }
        const peri = r3(P.reduce((s, q, k) => { const n = P[(k + 1) % P.length]; return s + Math.hypot(n[0] - q[0], n[1] - q[1]); }, 0));
        const old = p.drawing.plan, i = Math.max(-1, ...old.faces.map(f => f.i)) + 1, no = Math.max(0, ...old.faces.map(f => f.no || 0)) + 1;
        const face = { i, no, name: '', area, peri, ch: 0, poly: P, cx: r3(P.reduce((s, q) => s + q[0], 0) / P.length), cy: r3(P.reduce((s, q) => s + q[1], 0) / P.length), hand: true };
        p.drawing.plan = { ...old, faces: [...old.faces, face] };
        meas.pts = []; meas.redo = []; mode = 'room'; sel.clear(); sel.add(i);
        touch(p); resetUndo(p); draw();   // 区画を足すと図面の線（plan）が変わる。plan は元に戻すの控えに写していないので、ここが境目
        toast(`区画${no}（${fmt(area, 2)}㎡・周り ${fmt(peri, 2)}m）を足しました。選んであるので、そのまま「1部屋にする」で部屋にできます（区画を足す前には「元に戻す」で戻せません）`, { ms: 6000 });
        return;
      }
      if (a && a[0] === 'p' && /^p(Add|Del|DelItem|DelOne|Rot|SelNone|SelClear)$/.test(a)) {
        const d = p.drawing; d.places = d.places || [];
        const redo = () => { syncDemoLines(p); touch(p); paintSel(); }, was = d.places.slice(), undo = msg => toast(msg, { action: '元に戻す', onAction: () => { d.places = was; redo(); } });
        if (a === 'pSelNone') { psel = null; paintSel(); return; }
        if (a === 'pSelClear') { pfaces.clear(); psegs.clear(); paintSel(); return; }
        if (a === 'pAdd') { const pts = pPreview(); if (!pts.length) return; d.places.push({ id: uid('P'), item: pset.item, where: pset.where, ...pOpts(), ...(pset.where === 'line' ? { segs: [...psegs] } : { faces: [...pfaces] }), pts });
          pfaces.clear(); psegs.clear(); redo(); undo(`${itemName(pset.item)} を ${pts.length} 個並べました`); return; }
        if (a === 'pDel') { d.places = d.places.filter(q => q.id !== da.dataset.id); redo(); undo('消しました'); return; }
        if (a === 'pDelItem') { d.places = d.places.filter(q => !(q.where === 'pt' && q.item === da.dataset.item)); psel = null; redo(); undo('消しました'); return; }
        const q = d.places.find(z => z.id === psel); if (!q) return;
        if (a === 'pRot') { q.rot = ((+q.rot || 0) + 90) % 360; touch(p); paintSel(); return; }
        if (a === 'pDelOne') { d.places = d.places.filter(z => z !== q); psel = null; redo(); undo('1個消しました'); return; }
      }
      if (a === 'wallClear') { wsel.clear(); wpts.length = 0; paintSel(); return; }
      if (a === 'sketch') { openSk(); return; }
      if (a === 'elec') { openElec(p, { onApply: () => { syncDemoLines(p); touch(p); draw(); } }); return; }
      if (a === 'elecOff') { const was = p.elec; delete p.elec; syncDemoLines(p); touch(p); draw(); toast('電気の図面から入れた分を外しました', { action: '元に戻す', onAction: () => { p.elec = was; syncDemoLines(p); touch(p); draw(); } }); return; }
      if (a === 'cadOut') { cadExport(p); return; }

      if (a === 'open3d') {
        const onClose = wins => {
          if (!wins || JSON.stringify(wins) === JSON.stringify(p.drawing.win3d || [])) return;
          const n = applyWin3d(p, wins); touch(p); draw(); if (wins.length) toast(`3Dの窓 ${wins.length} か所を、面している部屋の窓に入れました（${n} 部屋）`, { ms: 4000 });
        };
        /* 図が2つ以上ある図面は、どの図を3Dにするか選ぶ（使う印の図を先に。かつ「複数図面がある時に3Dにすると全部出ちゃう」） */
        const SH = sheetsOf(p.drawing).filter(x => x.kind !== 'table'), list = [...SH.filter(x => x.use), ...SH.filter(x => !x.use)];
        const go3 = sheet => { flush(); toast('3Dを用意しています…'); open3D(p, { onClose, sheet, sheets: list }).catch(e => showError(e)); };
        if (list.length < 2) { go3(null); return; }
        const m = modal({ title: 'どの図を3Dにしますか', body: `<div class="small muted" style="margin-bottom:8px">選んだ図だけを3Dにします。3Dの上の帯で、ほかの図に切り替えられます。「印刷・PDF」は出している図だけになります。</div>
          <div style="display:grid;gap:8px">${list.map((x, k) => `<button class="btn" data-sh3="${k}" style="justify-content:flex-start">${icon('cube')}${esc(x.title || `図 ${k + 1}`)}${x.use ? '' : '<span class="small muted">（使わない図）</span>'}</button>`).join('')}
          <button class="btn ghost" data-sh3="all" style="justify-content:flex-start">${icon('cube')}全部まとめて</button></div>` });
        m.el.querySelectorAll('[data-sh3]').forEach(bt => bt.onclick = () => { const v = bt.dataset.sh3; m.close(); go3(v === 'all' ? null : list[+v]); });
        return; }
      if (a === 'linkClear') { const was = p.drawing.link, wasV = p.drawing.linkVia; p.drawing.link = Object.fromEntries(Object.entries(was || {}).filter(([, v]) => v === 'none')); delete p.drawing.linkVia;   // スイッチ無し（消したスイッチ）は残す
        syncDemoLines(p); touch(p); paintSel(); toast('つなぎ替えを元に戻しました（スイッチを消した照明はスイッチ無しのまま）', { action: '取り消す', onAction: () => { p.drawing.link = was; p.drawing.linkVia = wasV; syncDemoLines(p); touch(p); paintSel(); } }); return; }
      if (a === 'oClear') { const was = p.drawing.outlets; p.drawing.outlets = []; syncDemoLines(p); touch(p); paintSel(); toast('コンセントを全部消しました', { action: '元に戻す', onAction: () => { p.drawing.outlets = was; syncDemoLines(p); touch(p); paintSel(); } }); return; }
      if (a === 'oAuto') { const k = placeOutlets(); syncDemoLines(p); touch(p); paintSel(); toast(`コンセントを ${k} 個置きました（便器の横・洗面台の背面）`); return; }
      if (a === 'lClear') { const before = p.drawing.lights; p.drawing.lights = []; syncDemoLines(p); touch(p); paintSel(); toast('照明を全部消しました', { action: '元に戻す', onAction: () => { p.drawing.lights = before; syncDemoLines(p); touch(p); paintSel(); } }); return; }
      if (a === 'lAuto') {
        lset.room = $('#lRoom', body).value; lset.use = $('#lUse', body).value; lset.item = $('#lItem', body).value; lset.lm = Number($('#lLm', body).value) || DEF_LM[lset.item] || 800;
        lset.pitch = Math.max(0.9, Math.min(6, Number($('#lPitch', body).value) || 2));
        const withOut = !!da.dataset.out;
        const d = p.drawing, pr = p.rooms.filter(r => r.src === 'plan'), own = owner();
        /* 並べる所：部屋（部屋の区画をまとめて）と、部屋にしていない区画（0.6㎡以上） */
        let groups;
        /* 部屋にしていない区画のうち、照明を並べない所：
           ほかの区画を2つ以上中に含む区画（図面の枠の内側・建物の外まわり。並べると図面じゅうが照明で埋まる）、
           図面の表・表題欄と見た区画（新しい読み取りの解析で「除外」の物） */
        const marks = { ...((d.analysis && d.analysis.marks) || {}), ...sheetMarks(d), ...handMarks() };
        const wraps = (f) => { if (!f.poly || f.poly.length < 3) return false; let k = 0; for (const o of d.plan.faces) { if (o !== f && o.area < f.area && pip(o.cx, o.cy, f.poly) && ++k >= 2) return true; } return false; };
        let skipped = 0;
        const freeFaces = lset.room !== 'faces' ? [] : d.plan.faces.filter(f => !own.has(f.i) && f.area >= 0.6).filter(f => { const m = marks[f.i] || marks[String(f.i)]; if ((m && m.s === 'out') || wraps(f)) { skipped++; return false; } return !(p.drawing.faceJoin && p.drawing.faceJoin[f.i] != null); });
        if (lset.room === 'faces') groups = [...pr.map(r => ({ r, faces: r.faces || [] })), ...freeFaces.map(f => ({ r: null, faces: [f.i] }))];
        else groups = pr.filter(r => lset.room === 'all' || r.id === lset.room).map(r => ({ r, faces: r.faces || [] }));
        const facesOf = new Set(groups.flatMap(g => g.faces));
        const skipSet = new Set(lset.room !== 'faces' ? [] : d.plan.faces.filter(f => !own.has(f.i) && f.area >= 0.6 && !freeFaces.includes(f)).map(f => f.i));
        d.lights = (d.lights || []).filter(x => x.room ? !groups.some(g => g.r && g.r.id === x.room) : !(x.auto && skipSet.has(x.face)) && !d.plan.faces.some(f => facesOf.has(f.i) && pip(x.x, x.y, f.poly)));
        let n = 0;
        (async () => {
          toast('照明を並べています…');
          for (const g of groups) {
            if (g.r) { g.r.lightUse = lset.use; g.r.lightLm = lset.lm; }
            const ch = (g.r && Number(g.r.h)) || planCH(d.plan) || opts().ceilH;
            const faces = g.faces.map(i => d.plan.faces.find(z => z.i === i)).filter(Boolean);
            const res = await oldFaceLights(faces, d.fixtures, { base: lset.use ? lset.pitch : pitchFor(ch, lset.pitch), need: f => lset.use ? needCount(f.poly, ch, lset.use, lset.lm) : 0 });
            res.forEach(o => o.pts.forEach(q => { d.lights.push({ id: uid('L'), x: q[0], y: q[1], item: lset.item, room: g.r ? g.r.id : null, face: g.r ? undefined : o.i, auto: true }); n++; }));
          }
          const no = withOut ? placeOutlets() : 0;
          syncDemoLines(p); touch(p); paintSel(); toast(`照明 ${n} 台${withOut ? `・コンセント ${no} 個` : ''}を並べました。スイッチと配線も明細に入れました${skipped ? `（図面の枠・表・使わない図など ${skipped} か所には並べていません）` : ''}`, { ms: 4000 });
        })().catch(e => showError(e));
        return;
      }
      if (a === 'cutCancel') { cutA = null; paintSel(); return; }
      if (a === 'outCancel') { outA = null; paintSel(); return; }
      if (a === 'loCancel') { loSel = -1; paintSel(); return; }
      if (a === 'loOne' || a === 'loKind') {
        const d = p.drawing, plan = d.plan, LO = d.lineOff = d.lineOff || { keys: [], segs: [] };
        if (a === 'loKind' && plan.gk && plan.sg) { const key = plan.gk[plan.sg[loSel]]; if (key && !LO.keys.includes(key)) LO.keys.push(key); }
        else { const sg = plan.segs[loSel]; if (sg) LO.segs.push(sg.slice(0, 4)); }
        d.lineOffDirty = true; loSel = -1; touch(p); paintSel(); return;
      }
      if (a === 'loClear') { const d = p.drawing; d.lineOff = { keys: [], segs: [] }; d.lineOffDirty = true; touch(p); paintSel(); return; }
      if (a === 'loApply') {
        const files = cadFiles.get(p.id), inp = body.querySelector('#dwgFile');
        if (files && inp && inp.onchange) { inp.onchange({ target: { files, value: '' } }); return; }
        toast('図面のファイルをもう一度選んでください（外した線を除いて、区画を作り直します）', { ms: 6000 }); if (inp) inp.click(); return;
      }
      if (a === 'zsplitGo') {
        const d = p.drawing, Z = d.zones || [];
        const z = Z.find(q => q.id === (zsplit && zsplit.id));
        if (z && zsplit && zsplit.pts.length >= 2) {
          const byI = new Map(d.plan.faces.map(f => [f.i, f]));
          const F = z.faces.map(i => byI.get(i)).filter(Boolean);
          const [A, B] = splitFacesByLine(F, zsplit.pts);
          if (!A.length || !B.length) { toast('線の両側に区画が分かれませんでした。線を長めに引いてください', { bad: true }); return; }
          const areaB = Math.round(z.area * B.length / (A.length + B.length) * 10) / 10;
          const cB = B.map(i => byI.get(i)).filter(Boolean);
          const nz = { id: uid('z'), name: z.name ? z.name + ' 2' : '', faces: B, area: areaB, x: Math.round(cB.reduce((s, f) => s + f.cx, 0) / Math.max(1, cB.length) * 100) / 100, y: Math.round(cB.reduce((s, f) => s + f.cy, 0) / Math.max(1, cB.length) * 100) / 100, fixed: true };
          z.faces = A; z.area = Math.round((z.area - areaB) * 10) / 10; z.fixed = true;
          Z.push(nz); zoneSel = nz.id;
          toast(`2つのゾーンに分けました（新しい方は「${nz.name || '名前なし'}」）`);
        }
        mode = 'room'; zsplit = null; touch(p); paintSel(); return;
      }
      if (a === 'zsplitUndo') { if (zsplit) zsplit.pts.pop(); paintSel(); return; }
      if (a === 'zsplitCancel') { mode = 'room'; zsplit = null; paintSel(); return; }
      if (a === 'wallAdd') {
        const segs = wway === 'seg' ? [...wsel] : null, pts = wway === 'range' ? wpts.map(q => [r3(q[0]), r3(q[1])]) : null;
        const len = segs ? segs.reduce((s2, i) => s2 + segLen(p.drawing.plan.segs[i]), 0) : pts.reduce((s2, q, i) => i ? s2 + Math.hypot(q[0] - pts[i - 1][0], q[1] - pts[i - 1][1]) : 0, 0);
        if (!(len > 0)) return;
        const h = Number($('#wH', body).value) || opts().ceilH, open = Math.max(0, Number($('#wOpen', body).value) || 0);
        const itemId = $('#wItem', body).value, baseId = $('#wBase', body).value, finId = $('#wFin', body).value, name = $('#wName', body).value.trim(), room = $('#wRoom', body).value, more = $('#wMore', body).value;
        if (!itemId && !baseId && !finId) { toast('解体・下地・仕上げのどれかを選んでください', { bad: true }); return; }
        state.wallSet = { demo: itemId, base: baseId, fin: finId };
        p.drawing.walls = p.drawing.walls || [];
        p.drawing.walls.push({ id: uid('w'), ...(segs ? { segs } : { pts }), len: r3(len), h, open, itemId, baseId, finId, name, room, more: more ? [more] : [] });
        wsel.clear(); wpts.length = 0; syncDemoLines(p); touch(p); paintSel();
        const rn = room && p.rooms.find(x => x.id === room);
        toast(`壁を明細に入れました（${r3(len)}m × ${h}m${open ? ` − ${open}㎡` : ''}）${rn ? `。「${rn.name}」の壁の行から同じ分を引きます` : ''}`, { ms: 4000 });
        return;
      }
      if (a === 'wMoreDel') { const el = da.closest('[data-wall]'), w = el && (p.drawing.walls || []).find(x => x.id === el.dataset.wall); if (w && w.more) { w.more.splice(+da.dataset.k, 1); syncDemoLines(p); touch(p); paintSel(); } return; }
      if (a === 'wallDel' || a === 'hatsuDel') {
        const key = a === 'wallDel' ? 'walls' : 'hatsu', el = da.closest(a === 'wallDel' ? '[data-wall]' : '[data-hatsu]');
        const id = el && (el.dataset.wall || el.dataset.hatsu);
        const before = [...(p.drawing[key] || [])];
        p.drawing[key] = before.filter(x => x.id !== id); syncDemoLines(p); touch(p); paintSel();
        toast('消しました', { action: '元に戻す', onAction: () => { p.drawing[key] = before; syncDemoLines(p); touch(p); paintSel(); } });
        return;
      }
      if (a === 'fxDone') { fsel = -1; addAt = null; paintSel(); return; }
      if (a === 'faceSplit') {
        /* 家具の線を外してまとめた区画（js/facemerge.js）を、読み取った時の細かい区画に戻す。plan は「元に戻す」の控えに写していないので、ここが境目 */
        const d = p.drawing, ids = [...sel].filter(i => (d.plan.split || {})[i]), own = owner();
        if (ids.some(i => own.has(i))) { toast('部屋に入っている区画です。先に「部屋から外す」をしてから分けてください', { bad: true, ms: 5000 }); return; }
        ids.forEach(i => { const r = splitMerged(d.plan, d.open, i); if (!r) return; d.plan = r.plan; d.open = r.open;
          if (d.faceOff) delete d.faceOff[i]; if (d.faceFix) { delete d.faceFix[i]; if (!Object.keys(d.faceFix).length) delete d.faceFix; } if (d.faceJoin) { delete d.faceJoin[i]; Object.keys(d.faceJoin).forEach(k => { if (d.faceJoin[k] === i) delete d.faceJoin[k]; }); } });
        sel.clear(); touch(p); resetUndo(p); draw();
        toast(`細かい区画に分けました。分ける前には「元に戻す」で戻せません`, { ms: 5000 });
        return;
      }
      if (a === 'faceFix') {
        /* 辺を実線に直す（手動のみ・選んだ1区画だけ。js/facerepair.js）。
         * 自動では絶対にかけない：全区画にかけると他の図面で判定まで変わる事が回帰で分かっているため、
         * 村中さんの決定（2026-11-22）でボタンだけにした。直せる所が無ければ何も変えない */
        const d = p.drawing, i = [...sel][0], f = (d.plan.faces || []).find(x => x.i === i);
        const r = applyEdgeFix(d, i);
        if (!r.ok) { toast('この区画は、実線に沿う直し方が見つかりませんでした（辺はそのままです）', { ms: 5000 }); return; }
        /* その区画が入っている部屋は、床の広さを新しい形で計算し直す */
        p.rooms.forEach(rm => { if (rm.src === 'plan' && (rm.faces || []).includes(i)) regeo(rm); });
        syncDemoLines(p); touch(p); draw();
        toast(`区画${f ? f.no : ''} の辺を実線に直しました（床 ${r.before}㎡ → ${r.area}㎡）。選んだまま「元に戻す」で戻せます`, { ms: 6000 });
        return;
      }
      if (a === 'faceOff' || a === 'faceJoin' || a === 'faceBack') {
        const d = p.drawing, ids = [...sel]; d.faceOff = { ...(d.faceOff || {}) }; d.faceJoin = { ...(d.faceJoin || {}) };
        const before = { off: { ...(p.drawing.faceOff || {}) }, join: { ...(p.drawing.faceJoin || {}) } };
        /* まず選んだ区画を、入っている部屋から外す（まとめ直し・外しのため） */
        const pull = (set) => { p.rooms.forEach(r => { if (!r.faces || !r.faces.some(i => set.has(i))) return; r.faces = r.faces.filter(i => !set.has(i)); if (r.faces.length) regeo(r); });
          const empty = p.rooms.filter(r => r.src === 'plan' && r.faces && !r.faces.length).map(r => r.id); p.rooms = p.rooms.filter(r => !empty.includes(r.id)); };
        let n = 0, miss = 0; const pairs = [];
        if (a === 'faceOff') { const S = new Set(ids); pull(S); ids.forEach(i => { d.faceOff[i] = true; delete d.faceJoin[i]; Object.keys(d.faceJoin).forEach(k => { if (d.faceJoin[k] === i) delete d.faceJoin[k]; }); n++; }); }
        if (a === 'faceBack') { const S = new Set(ids.filter(i => d.faceJoin[i] != null)); pull(S); const reverted = []; ids.forEach(i => { let had = false; if (d.faceOff[i] || d.faceJoin[i] != null) had = true; delete d.faceOff[i]; delete d.faceJoin[i]; if (revertEdgeFix(d, i).ok) { had = true; reverted.push(i); } if (had) n++; });
          /* 辺の手直しを戻した区画が入っている部屋は、床の広さを元の形で計算し直す */
          reverted.forEach(i => p.rooms.forEach(rm => { if (rm.src === 'plan' && (rm.faces || []).includes(i)) regeo(rm); })); }
        if (a === 'faceJoin') {
          const F = d.plan.faces, S = new Set(ids); pull(S);
          ids.forEach(i => { const f = F.find(o => o.i === i); const nb = f && f.poly && f.poly.length >= 3 ? nbOf(f) : null;
            if (nb == null || joinRoot(nb) === i) { miss++; return; }
            d.faceJoin[i] = nb; delete d.faceOff[i]; n++; pairs.push(`区画${f.no}→区画${(F.find(o => o.i === nb) || {}).no}`);
            /* まとめ先が部屋になっていれば、その部屋の床に入れる */
            const r = p.rooms.find(q => (q.faces || []).includes(joinRoot(nb))); if (r) { r.faces = withJoined(r.faces); regeo(r); } });
        }
        if (!Object.keys(d.faceOff).length) delete d.faceOff; if (!Object.keys(d.faceJoin).length) delete d.faceJoin;
        sel.clear(); syncDemoLines(p); touch(p); draw();
        const msg = a === 'faceOff' ? `${n} 区画を「区画ではない」にしました（灰色。数えません）` : a === 'faceBack' ? `${n} 区画を元に戻しました` : `${n} 区画を隣の部屋にまとめました（${pairs.slice(0, 4).join('・')}${pairs.length > 4 ? ' ほか' : ''}。床の広さに入ります）${miss ? `。${miss} 区画は隣が見つかりませんでした` : ''}`;
        toast(msg, { ms: 5000 });
        return;
      }
      if (a === 'unassign') {
        const plan = p.drawing.plan, ids = new Set([...sel]);
        p.rooms.forEach(r => { if (!r.faces || !r.faces.some(i => ids.has(i))) return; r.faces = r.faces.filter(i => !ids.has(i));
          if (r.faces.length) { setGeo(r); if (p.drawing.open) r.openRuns = roomOpenRuns(r.faces, plan, p.drawing.open);
            if (/^区画 [\d・]+$/.test(r.name || '')) r.name = `区画 ${r.faces.map(i => (plan.faces.find(f => f.i === i) || {}).no).sort((x, y) => x - y).join('・')}`; } });
        const empty = p.rooms.filter(r => r.src === 'plan' && r.faces && !r.faces.length).map(r => r.id);
        p.rooms = p.rooms.filter(r => !empty.includes(r.id));
        p.lines.forEach(l => { if (l.basis && Array.isArray(l.basis.rooms)) l.basis.rooms = l.basis.rooms.filter(id => !empty.includes(id)); });
        sel.clear(); syncDemoLines(p); touch(p); draw(); toast(`${ids.size} 区画を部屋から外しました${empty.length ? `（区画が無くなった ${empty.length} 部屋は消しました）` : ''}`); return;
      }
      if (a === 'fxVirtual') {
        /* 前のKAKUと同じ：扉が区画の近く（25cm以内）にあれば、扉に一番近い辺の反対側の壁に便器（幅46・奥行80cm）。無ければ長い方の向きの壁 */
        const f = p.drawing.plan.faces.find(z => pip(addAt[0], addAt[1], z.poly)); if (!f) return;
        let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity; f.poly.forEach(q => { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); });
        const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2; let door = null, bd = Infinity;
        (p.drawing.doors || []).forEach(d => { const dx = Math.max(x0 - d.c[0], 0, d.c[0] - x1), dy = Math.max(y0 - d.c[1], 0, d.c[1] - y1), dist = Math.hypot(dx, dy); if (dist < 0.25 && dist < bd) { bd = dist; door = d; } });
        let back;
        if (door) { const q = door.c, dd = { W: q[0] - x0, E: x1 - q[0], S: q[1] - y0, N: y1 - q[1] }; back = { N: 'S', S: 'N', E: 'W', W: 'E' }[Object.entries(dd).sort((a2, b2) => a2[1] - b2[1])[0][0]]; }
        else back = (x1 - x0) > (y1 - y0) ? 'E' : 'N';
        const hor = back === 'N' || back === 'S', W = 0.46, D = 0.8;
        const bx = hor ? (back === 'N' ? [cx - W / 2, y1 - D - 0.02, cx + W / 2, y1 - 0.02] : [cx - W / 2, y0 + 0.02, cx + W / 2, y0 + D + 0.02])
          : (back === 'E' ? [x1 - D - 0.02, cy - W / 2, x1 - 0.02, cy + W / 2] : [x0 + 0.02, cy - W / 2, x0 + D + 0.02, cy + W / 2]);
        const L = p.drawing.fixtures = p.drawing.fixtures || [];
        for (let k = L.length - 1; k >= 0; k--) if (L[k].v && pip((L[k].b[0] + L[k].b[2]) / 2, (L[k].b[1] + L[k].b[3]) / 2, f.poly)) L.splice(k, 1);
        L.push({ t: 'toilet', b: bx.map(r3), back, v: true, edited: true });
        addAt = null; touch(p); paintSel(); toast(`区画${f.no}に便器を置きました（${door ? '扉の反対側の壁' : '扉が見つからないので長い方の壁'}）。種類と向きはタップで直せます`, { ms: 4000 }); return;
      }
      if (a === 'fxFlip') {
        const x = fxList()[fsel]; if (!x) return;
        x.flip = !x.flip; x.edited = true;
        const had = (p.drawing.outlets || []).some(o => o.auto);
        if (had) placeOutlets();
        syncDemoLines(p); touch(p); paintSel();
        toast(had ? 'コンセントを反対側にしました' : '反対側にしました。「照明・配線」でコンセントを置くと反対側に付きます');
        return;
      }
      if (a === 'fxDel') {
        const fx = fxList(), x = fx[fsel]; if (!x) return;
        fx.splice(fsel, 1); fsel = -1; touch(p); paintSel();
        toast(`${FIX_NAMES[x.t] || '器具'}を消しました`, { action: '元に戻す', onAction: () => { fxList().push(x); touch(p); paintSel(); } });
        return;
      }
      if (a === 'fxAdd' && addAt) {
        const t = $('#fxNewT', body).value, bk = $('#fxNewB', body).value;
        let [w, h] = FIX_SIZE[t] || [0.5, 0.5]; if (bk === 'E' || bk === 'W') [w, h] = [h, w];
        const q3 = v => Math.round(v * 1000) / 1000;
        if (!p.drawing.fixtures) p.drawing.fixtures = [];
        p.drawing.fixtures.push({ t, b: [q3(addAt[0] - w / 2), q3(addAt[1] - h / 2), q3(addAt[0] + w / 2), q3(addAt[1] + h / 2)], back: bk, added: true });
        addAt = null; fsel = -1; touch(p); paintSel(); toast(`${FIX_NAMES[t]}を足しました`);
        return;
      }
      if (a === 'mkOne') return makeRooms(false);
      if (a === 'mkEach') return makeRooms(true);
      if (a === 'selClear') { sel.clear(); paintSel(); return; }
      if (a === 'lMakeAll') { const own = owner(), mk = faceMarks() || {}; p.drawing.plan.faces.forEach(f => { if (!own.has(f.i) && !mk[f.i]) sel.add(f.i); }); return makeRooms(true); }
      if (a === 'selSame') {
        /* 選んだ区画と同じ大きさ（面積も周りの長さも 2% 以内か 0.02 以内）の、まだ部屋にしていない区画を足す。トイレのブースなどをまとめて選ぶ */
        const own = owner(), F = p.drawing.plan.faces, base = [...sel].map(i => F.find(f => f.i === i)).filter(Boolean);
        const near = (x, y) => Math.abs(x - y) <= Math.max(0.02, Math.abs(y) * 0.02);
        let k = 0; F.forEach(f => { if (sel.has(f.i) || own.has(f.i)) return; if (base.some(b => near(f.area, b.area) && near(f.peri, b.peri))) { sel.add(f.i); k++; } });
        paintSel(); toast(k ? `同じ大きさの区画を ${k} 個足しました（全部で ${sel.size} 区画）` : '同じ大きさで、まだ部屋にしていない区画はありませんでした'); return;
      }
      if (a === 'selRest') { const own = owner(), mk = faceMarks() || {}; p.drawing.plan.faces.forEach(f => { if (!own.has(f.i) && !mk[f.i]) sel.add(f.i); }); paintSel(); return; }
      if (a === 'dwgClear') {
        if (!(await ask('図面を消しますか？', '図面から作った部屋は残ります（図面とのつながりだけ外れます）。', { ok: '消す', danger: true }))) return;
        const old = p.drawing; p.drawing = null; p.rooms.forEach(r => { if (r.src === 'plan') r.src = 'plan-old'; });
        touch(p); draw(); toast('図面を消しました', { action: '元に戻す', onAction: () => { p.drawing = old; p.rooms.forEach(r => { if (r.src === 'plan-old' && r.faces) r.src = 'plan'; }); touch(p); draw(); } });
        return;
      }
    }
    const card = e.target.closest('[data-room]'); if (!card) return;
    const r = p.rooms.find(x => x.id === card.dataset.room); if (!r) return;
    if (e.target.matches('[data-open-toggle]')) { r.openOff = !e.target.checked; touch(p); refresh(); return; }
    const sh = e.target.closest('[data-shape]');
    if (sh) {
      r.shape = sh.dataset.shape;
      if (r.shape === 'free' && !(r.area > 0) && r.w > 0 && r.d > 0) { r.area = Math.round(r.w * r.d * 1000) / 1000; r.perim = Math.round(2 * (r.w + r.d) * 1000) / 1000; }
      touch(p); draw(); return;
    }
    const a = e.target.closest('[data-act]'); if (!a) return;
    if (a.dataset.act === 'holeToggle' && r.holes) { r.noHoles = !r.noHoles; const ha = r.holes.area; r.area = Math.round((r.area + (r.noHoles ? -ha : ha)) * 100) / 100; touch(p); draw(); toast(r.noHoles ? `囲まれた所 ${ha}㎡ を床から外しました` : `囲まれた所 ${ha}㎡ を床に足しました`); return; }
    if (a.dataset.act === 'addWin') { r.windows = r.windows || []; r.windows.push({ w: 1690, h: 1800, n: 1 }); }
    if (a.dataset.act === 'delWin') r.windows.splice(+a.dataset.wi, 1);
    if (a.dataset.act === 'addPart') { (r.parts = r.parts || []).push({ s: 1, w: '', h: '' }); touch(p); draw(); return; }
    if (a.dataset.act === 'delPart') { r.parts.splice(+a.dataset.pi, 1); touch(p); draw(); return; }
    if (a.dataset.act === 'roomFin') { openRoomFin(p, [r.id], { title: `「${r.name}」の仕上げ`, onDone: () => { syncWaste(p); touch(p); draw(); } }); return; }
    if (a.dataset.act === 'dupRoom') { const c = JSON.parse(JSON.stringify(r)); c.id = uid('r'); c.name = r.name + '（コピー）'; p.rooms.splice(p.rooms.indexOf(r) + 1, 0, c); }
    if (a.dataset.act === 'delRoom') {
      const used = p.lines.filter(l => l.basis && Array.isArray(l.basis.rooms) && l.basis.rooms.includes(r.id));
      const idx = p.rooms.indexOf(r);
      p.rooms.splice(idx, 1);
      used.forEach(l => { l.basis.rooms = l.basis.rooms.filter(id => id !== r.id); });
      touch(p); draw();
      toast(`「${r.name}」を消しました`, { action: '元に戻す', onAction: () => { p.rooms.splice(idx, 0, r); used.forEach(l => l.basis.rooms.push(r.id)); touch(p); draw(); } });
      return;
    }
    touch(p); draw();
  });
  draw();
}

/* ---------- ③ 工事 ---------- */
function roomSel(l, rooms) {
  const b = l.basis || {};
  const v = b.rooms === 'all' || !Array.isArray(b.rooms) ? 'all' : b.rooms.length === 1 ? b.rooms[0] : 'multi';
  return `<select class="in" data-lk="rooms"><option value="all" ${v === 'all' ? 'selected' : ''}>全部の部屋</option>
    ${rooms.map(r => `<option value="${esc(r.id)}" ${v === r.id ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}
    <option value="multi" ${v === 'multi' ? 'selected' : ''}>${v === 'multi' ? `${b.rooms.length}部屋を選択中…` : '部屋をいくつか選ぶ…'}</option></select>`;
}
function pipePanel(l, lines) {
  const set = l.pipeSet || {};
  const opts2 = sysOptions(l.pipe);
  const sys = set.sys || opts2[0];
  const kids = lines.filter(x => x.parent === l.id).length;
  return `<div class="pipeset" style="grid-column:1/-1">
    <div class="row"><span class="small muted">系統</span><div class="seg">${opts2.map(k => `<button data-sys="${k}" class="${sys === k ? 'on' : ''}">${SYS[k]}</button>`).join('')}</div>
    <label class="row small muted" style="gap:6px">継手の多さ<select class="in" data-pk="many" style="width:auto;min-height:38px">${MANY.map(([v, n]) => `<option value="${v}" ${String(set.many || 1) === v ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    ${sys === 'w' || sys === 'h' ? `<label class="row small muted" style="gap:6px"><input type="checkbox" data-pk="hoon" ${set.hoon ? 'checked' : ''} style="width:20px;height:20px">保温する</label>` : ''}
    <span class="spacer"></span>
    <button class="btn sm ${kids ? '' : 'primary'}" data-act="pipeKids">${icon('plus')}${kids ? `継手などを付け直す（今 ${kids} 行）` : '継手・支持金具・手間を付ける'}</button></div>
  </div>`;
}
function lineCard(l, rooms, lines = []) {
  const link = l.basis && l.basis.measure === 'link';
  const waste = !!(l.basis && l.basis.measure === 'waste');
  const auto = isRoomBased(l) || link || waste;
  const catName = (categories().find(c => c[0] === l.cat) || [])[1] || '';
  return `<div class="linec ${l.parent ? 'child' : ''} ${l.pipe ? 'pipe' : ''}" data-line="${l.id}">
    <div class="name"><span class="cat">${l.sys || (l.pipeSet && l.pipeSet.sys) ? `<span class="pill info" style="padding:1px 7px">${SYS[l.sys || l.pipeSet.sys]}</span> ` : ''}${l.parent ? '↳ 配管に付く行・' : ''}${esc(catName)}${catName ? '・' : ''}${KINDS[l.kind] || 'その他'}</span>
      <input class="in" data-lk="name" value="${esc(l.name)}" placeholder="工事項目" aria-label="工事項目">
      <input class="in" data-lk="spec" value="${esc(l.spec || '')}" placeholder="規格・仕様（なくても可）" aria-label="規格・仕様" style="min-height:40px;font-size:14px">
      ${hasCode(l) ? `<input class="in" data-lk="code" value="${esc(l.code || '')}" placeholder="品番・色（例：SP-2801）" aria-label="品番・色" autocapitalize="characters" autocomplete="off" style="min-height:44px">` : ''}</div>
    <label class="f">数え方<select class="in" data-lk="measure">${Object.entries(MEASURES).filter(([k]) => (k !== 'link' || link) && (k !== 'waste' || waste)).map(([k, m]) => `<option value="${k}" ${(auto ? l.basis.measure : 'manual') === k ? 'selected' : ''}>${k === 'manual' && l.pipe ? '長さを手で入れる' : m.label}</option>`).join('')}</select>
      ${auto && !link && !waste ? roomSel(l, rooms) : ''}</label>
    <label class="f">${l.pipe ? '長さ（m）・単位' : '数量・単位'}<div class="qtybox">
      ${auto ? `<div class="in num" style="display:flex;align-items:center;justify-content:flex-end;background:var(--panel2)" data-out="qty:${l.id}"></div>` : `<input class="in num" type="number" inputmode="decimal" step="any" min="0" data-lk="qty" value="${esc(l.qty)}">`}
      <input class="in" data-lk="unit" value="${esc(l.unit || '')}" style="width:62px;padding:10px 6px;text-align:center" aria-label="単位"></div></label>
    <label class="f">単価（円）<input class="in num" type="number" inputmode="numeric" step="any" min="0" data-lk="price" value="${esc(l.price)}"></label>
    <div class="amt" data-out="amt:${l.id}"></div>
    <button class="iconbtn del" data-act="delLine" title="この行を消す" aria-label="この行を消す">${icon('trash')}</button>
    ${auto || l.applyLoss ? `<div class="qtyinfo" data-out="qinfo:${l.id}"></div>` : ''}
    ${l.pipe ? pipePanel(l, lines) : ''}
    <div class="basisrow"><button class="btn sm" data-act="basis">${icon('search')}数量の根拠・確認</button>${srcPill(lineSource(l, rooms, lines))}<span data-out="ok:${l.id}"></span>${hasCode(l) ? `<span class="mk" data-out="mk:${l.id}"></span>` : ''}</div>
    <details class="more" style="grid-column:1/-1"><summary>くわしく（区分・ロス率・原価・コピー）</summary>
      <div class="opts" style="margin-top:10px">
        <label class="f">区分<select class="in" data-lk="kind">${Object.entries(KINDS).map(([k, n]) => `<option value="${k}" ${(l.kind || 'other') === k ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
        <label class="f">ロス率<span class="hint">空なら ${opts().loss}%（材料だけ）</span><div class="unitwrap"><input class="in num" type="number" inputmode="decimal" data-lk="loss" value="${esc(l.loss ?? '')}"><span>%</span></div></label>
        <label class="f">原価（1単位）<span class="hint">外注・その他だけ</span><input class="in num" type="number" inputmode="numeric" data-lk="cost" value="${esc(l.cost ?? '')}"></label>
        <div class="f" style="justify-content:flex-end"><button class="btn sm" data-act="dupLine">${icon('copy')}この行をコピー</button></div>
      </div></details>
  </div>`;
}

function stepLines(ctx) {
  const { p, body, refresh } = ctx;
  const draw = () => {
    body.innerHTML = `
      <div class="addbar" style="margin-bottom:12px"><button class="btn primary" data-act="pick">${icon('list')}一覧から選ぶ</button><button class="btn" data-act="free">${icon('plus')}自由に入れる</button>
        <span class="spacer"></span><span class="pill">行 <b data-out="linecount"></b></span><span class="pill acc">小計 <b data-out="subtotal"></b></span></div>
      <div class="lines">${p.lines.map(l => lineCard(l, p.rooms, p.lines)).join('') || `<div class="card empty"><b>まだ工事の品目がありません</b>「一覧から選ぶ」で、床・壁・天井の仕上げや解体などを選んでください。</div>`}</div>
      ${p.lines.length > 3 ? `<div class="addbar" style="margin-top:12px"><button class="btn primary" data-act="pick">${icon('list')}一覧から選ぶ</button><button class="btn" data-act="free">${icon('plus')}自由に入れる</button></div>` : ''}`;
    refresh();
  };
  ctx.redraw = draw;
  body.addEventListener('input', e => {
    const card = e.target.closest('[data-line]'); if (!card) return;
    const l = p.lines.find(x => x.id === card.dataset.line); const k = e.target.dataset.lk; if (!l || !k) return;
    if (k === 'measure' || k === 'rooms' || k === 'kind') return;
    l[k] = ['qty', 'price', 'loss', 'cost'].includes(k) ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value;
    touch(p); refresh();
  });
  body.addEventListener('change', async e => {
    const card = e.target.closest('[data-line]'); if (!card) return;
    const l = p.lines.find(x => x.id === card.dataset.line); const k = e.target.dataset.lk; if (!l) return;
    if (k === 'measure') {
      const m = e.target.value;
      if (m === 'manual') { l.qty = lineQty(l, p.rooms, opts(), p.lines) || l.qty || 1; l.basis = null; delete l.parent; }
      else l.basis = { measure: m, rooms: l.basis && l.basis.rooms ? l.basis.rooms : 'all' };
      touch(p); draw(); return;
    }
    if (k === 'rooms') {
      const v = e.target.value;
      if (v === 'multi') { await pickRooms(p, l); draw(); return; }
      l.basis.rooms = v === 'all' ? 'all' : [v];
      touch(p); refresh(); return;
    }
    if (k === 'kind') { l.kind = e.target.value; touch(p); draw(); return; }
    const pk = e.target.dataset.pk;
    if (pk && l.pipe) {
      l.pipeSet = { ...(l.pipeSet || {}), [pk]: pk === 'hoon' ? e.target.checked : Number(e.target.value) };
      if (p.lines.some(x => x.parent === l.id)) rebuild(p, l, masterItems());
      touch(p); draw();
    }
  });
  body.addEventListener('click', e => {
    const sb = e.target.closest('[data-sys]');
    if (sb) {
      const l = p.lines.find(x => x.id === sb.closest('[data-line]').dataset.line);
      if (l && l.pipe) {
        l.pipeSet = { ...(l.pipeSet || {}), sys: sb.dataset.sys };
        if (p.lines.some(x => x.parent === l.id)) rebuild(p, l, masterItems());
        touch(p); draw();
      }
      return;
    }
    const a = e.target.closest('[data-act]'); if (!a) return;
    if (a.dataset.act === 'pick') return openPicker(p, draw);
    if (a.dataset.act === 'free') {
      p.lines.push({ id: uid('l'), name: '', spec: '', unit: '式', kind: 'other', qty: 1, price: '', cost: '', loss: '', sheet: 0, basis: null, cat: '' });
      touch(p); draw();
      const ins = body.querySelectorAll('[data-lk="name"]'); ins[ins.length - 1].focus();
      return;
    }
    const card = a.closest('[data-line]'); if (!card) return;
    const l = p.lines.find(x => x.id === card.dataset.line); if (!l) return;
    const idx = p.lines.indexOf(l);
    if (a.dataset.act === 'delLine') {
      const before = [...p.lines];
      const kids = p.lines.filter(x => x.parent === l.id);
      p.lines = p.lines.filter(x => x !== l && x.parent !== l.id);
      const wk = l.basis && l.basis.measure === 'waste' ? (l.basis.kind || 'w-waste') : null;   // 自分で消した廃材の行は、勝手に入れ直さない
      if (wk) (p.noWaste = p.noWaste || {})[wk] = true;
      touch(p); draw();
      toast(kids.length ? `「${l.name}」と付いていた ${kids.length} 行を消しました` : `「${l.name || '行'}」を消しました`, { action: '元に戻す', onAction: () => { p.lines = before; if (wk && p.noWaste) delete p.noWaste[wk]; touch(p); draw(); } });
    }
    if (a.dataset.act === 'basis') return basisDialog(p, l, refresh);
    if (a.dataset.act === 'pipeKids') {
      const n = rebuild(p, l, masterItems());
      touch(p); draw(); toast(`継手・支持金具・手間など ${n} 行を付けました`);
    }
    if (a.dataset.act === 'dupLine') { const c = JSON.parse(JSON.stringify(l)); c.id = uid('l'); p.lines.splice(idx + 1, 0, c); touch(p); draw(); toast('行をコピーしました'); }
  });
  draw();
}

function pickRooms(p, l) {
  return new Promise(res => {
    const cur = new Set(Array.isArray(l.basis.rooms) ? l.basis.rooms : p.rooms.map(r => r.id));
    const m = modal({
      title: '使う部屋を選ぶ',
      body: `<p class="muted small" style="margin-top:0">「${esc(l.name)}」の数量に入れる部屋にチェックを付けてください。</p>` + p.rooms.map(r => `<label class="pick" style="cursor:pointer"><input type="checkbox" value="${esc(r.id)}" ${cur.has(r.id) ? 'checked' : ''} style="width:22px;height:22px"><span class="nm">${esc(r.name)}<small>床 ${fmt(roomGeom(r, opts()).floor)}㎡</small></span></label>`).join(''),
      foot: `<button class="btn primary" data-ok>決める</button>`,
      onClose: res
    });
    m.el.querySelector('[data-ok]').onclick = () => {
      const ids = $$('input[type=checkbox]', m.el).filter(c => c.checked).map(c => c.value);
      l.basis.rooms = ids.length === p.rooms.length ? 'all' : ids;
      touch(p); m.close();
    };
  });
}

export function openPicker(p, after) {
  const items = masterItems();
  const cats = categories();
  let cat = state.pickCat || 'all', q = '', added = 0;
  const m = modal({
    title: '工事の品目を選ぶ', wide: true,
    body: `<div class="unitwrap"><input class="in" id="pq" type="search" placeholder="品目で探す（例：クロス、石膏ボード 12.5、HIVP 20）" enterkeyhint="search"><span>${icon('search')}</span></div>
      <div class="catchips" id="pc"></div><div class="small muted" id="pn" style="margin:2px 0 6px"></div><div class="picklist" id="pl"></div>`,
    foot: `<span class="small muted" id="padded" style="margin-right:auto"></span><button class="btn primary" data-close>終わる</button>`,
    onClose: () => { after(); if (added) toast(`${added} 件の品目を足しました`); }
  });
  const draw = () => {
    $('#pc', m.el).innerHTML = [['all', 'すべて'], ...cats].map(([k, n]) => `<button data-c="${k}" class="${cat === k ? 'on' : ''}">${esc(n)}</button>`).join('');
    const qq = q.trim().toLowerCase();
    const list = items.filter(i => (cat === 'all' || (i.custom ? 'custom' : i.cat) === cat) && matchItem(i, qq)).slice(0, 300);
    const have = new Set(p.lines.map(l => l.itemId));
    $('#pn', m.el).textContent = `${list.length} 件${cat === 'all' && !qq ? '（種類を選ぶか、名前で探すと絞れます）' : ''}`;
    $('#pl', m.el).innerHTML = list.map(i => `<button class="pick ${have.has(i.id) ? 'added' : ''}" data-id="${esc(i.id)}">
      <span class="nm">${esc(i.name)}<small>${esc(i.spec || '')}${i.measure !== 'manual' ? `・${MEASURES[i.measure].label}から自動` : ''}${i.changed ? '・単価変更あり' : ''}</small></span>
      <span class="pr">${i.price ? yen(i.price) : '単価なし'}/${esc(i.unit)}</span>${have.has(i.id) ? `<span class="pill ok">追加済</span>` : `<span class="pill acc">${icon('plus').replace('<svg', '<svg style="width:14px;height:14px"')}足す</span>`}</button>`).join('') || '<div class="empty">見つかりません。「自由に入れる」で自分で入れられます。</div>';
  };
  m.el.addEventListener('click', e => {
    const c = e.target.closest('[data-c]'); if (c) { cat = state.pickCat = c.dataset.c; draw(); return; }
    const b = e.target.closest('.pick'); if (!b) return;
    const it = items.find(i => i.id === b.dataset.id); if (!it) return;
    const auto = it.measure && it.measure !== 'manual';
    const line = { id: uid('l'), itemId: it.id, name: it.name, spec: it.spec || '', unit: it.unit, kind: it.kind || 'mat', price: it.price || '', cost: '', loss: '', sheet: it.sheet || 0, cat: it.custom ? 'custom' : it.cat, qty: auto ? '' : 1, basis: auto ? { measure: it.measure, rooms: 'all' } : null };
    if (it.pipe) {
      const sys = sysOptions(it.pipe)[0];
      Object.assign(line, { pipe: { ...it.pipe }, applyLoss: true, loss: PIPE_LOSS, qty: '', pipeSet: { sys, many: 1, hoon: sys === 'h' } });
    }
    p.lines.push(line);
    if (isDemoArea(line)) added += syncWaste(p);
    added++; touch(p);
    $('#padded', m.el).textContent = `${added} 件 足しました`;
    draw();
  });
  $('#pq', m.el).oninput = e => { q = e.target.value; draw(); };
  draw();
}

/* 数量の根拠（どの部屋から何㎡か）を見せて、「確認済み」の印を付ける */
function basisDialog(p, l, after) {
  const o = opts(), B = lineBasis(l, p.rooms, o, p.lines), u = esc(l.unit || ''), price = Math.max(0, Number(l.price) || 0);
  const mu = B.unit || '';
  const src = l.itemId ? masterItems().find(i => i.id === l.itemId && i.src) : null;   // 単価の出どころ（分かっている品目だけ）
  const hasOff = B.rows.some(r => r.off > 0);
  const S = lineSource(l, p.rooms, p.lines);
  const srcTxt = `<p class="small" style="margin:0 0 8px">数量の出どころ：${srcPill(S)}${B.type === 'room' && S.src === 'mixed' ? `　図面の部屋 ${S.nDraw}・手で作った部屋 ${S.nMan}` : ''}</p>`;
  let how;
  if (B.type === 'room') {
    how = `<p class="small muted" style="margin:0 0 8px">${esc(MEASURES[B.measure].label)}を、部屋ごとに足しています。</p>
      ${B.rows.length ? `<div style="overflow-x:auto"><table class="sum basis"><tr><th>部屋</th>${hasOff ? '<th>部屋の数量</th><th>図面で壁ごとに入れた分</th>' : ''}<th>この行に入る分</th></tr>
      ${B.rows.map(r => `<tr><td>${esc(r.name || '名前なし')}</td>${hasOff ? `<td>${fmt(r.raw, 3)}${mu}</td><td>${r.off > 0 ? '−' + fmt(r.off, 3) + mu : '—'}</td>` : ''}<td>${fmt(r.v, 3)}${mu}</td></tr>`).join('')}
      <tr class="tot"><td>正味の合計（${B.rows.length} 部屋）</td>${hasOff ? '<td></td><td></td>' : ''}<td>${fmt(B.net, 3)}${mu}</td></tr></table></div>` : '<p class="muted">この行に入る部屋がありません。</p>'}`;
  } else if (B.type === 'waste') {
    how = `<p class="small muted" style="margin:0 0 8px">解体した面積に、廃材の厚み（品目の名前の「厚○」mm、無ければ 1㎡あたり ${fmt(o.waste, 3)}m³）を掛けています。</p>
      ${B.waste.length ? `<div style="overflow-x:auto"><table class="sum basis"><tr><th>解体の行</th><th>面積</th><th>厚み</th><th>廃材</th></tr>
      ${B.waste.map(x => `<tr><td>${esc(x.name)}</td><td>${fmt(x.area, 2)}㎡</td><td>${fmt(x.t, 3)}m</td><td>${fmt(x.v, 3)}m³</td></tr>`).join('')}
      <tr class="tot"><td>合計（0.01 単位）</td><td></td><td></td><td>${fmt(B.net, 2)}m³</td></tr></table></div>` : '<p class="muted">もとになる解体の行がありません。</p>'}`;
  } else if (B.type === 'link') {
    how = B.parent ? `<p style="margin:0">元の配管「${esc(B.parent.name)}」の長さ ${fmt(B.parent.len, 3)}m × 1mあたり ${fmt(B.rate, 3)} ＝ ${fmt(B.net, 3)}${u}${l.why ? `（${esc(l.why)}）` : ''}</p>` : '<p class="muted" style="margin:0">元の配管の行がありません。</p>';
  } else {
    const src = l.fromFix ? `図面の器具（${esc(FIX_NAMES[l.fromFix] || '')}）の数から入れた行です。`
      : l.fromDemo ? '図面で入れた物から自動で作った行です（図面を直すと数量も変わります）。' : '数量は手で入れた数です。';
    how = `<p style="margin:0">${src}</p><p style="margin:6px 0 0">入れた数量：<b>${fmt(B.net, 3)}</b>${u}</p>`;
  }
  const lossTxt = B.lossPct == null ? (l.kind === 'labor' && B.type !== 'manual' ? '手間なので、ロスは足さず正味のままです。' : 'ロスは足していません。')
    : `ロス ${fmt(B.lossPct, 1)}% を足して${B.sheet ? `、1枚 ${fmt(B.sheet, 3)}㎡ の板 ${Math.round(B.qty / B.sheet)} 枚に切り上げ` : '、0.1 単位で切り上げ'}ています。`;
  const st = okState(l, p.rooms, o, p.lines);
  const m = modal({
    title: `「${l.name || '名前のない行'}」の数量の根拠`, wide: true,
    body: `${srcTxt}${how}
      <p class="small muted" style="margin:10px 0 0">${lossTxt}</p>
      <table class="sum" style="margin-top:10px">
        <tr><td>見積もりの数量</td><td>${fmt(B.qty, 3)} ${u}</td></tr>
        <tr><td>単価${src ? `<br><span class="small muted">出どころ：${esc(src.src)}${src.asOf ? `（${esc(src.asOf)} 時点）` : ''}${src.changed ? '。単価マスターの値段は自分で変えてあります' : ''}${Number(src.price) !== price ? `。この行の単価は、一覧の ${yen(src.price)} から変えてあります` : ''}</span>` : ''}</td><td>${yen(price)}</td></tr>
        <tr class="tot"><td>金額</td><td>${yen(Math.round(B.qty * price))}</td></tr></table>
      ${st === 'changed' ? `<div class="chk warn" style="margin-top:12px">${icon('alert')}<span>前に確認した時は ${fmt(l.ok.qty, 3)}${u} × ${yen(l.ok.price)} でした。その後で数量か単価が変わっています。</span></div>` : ''}
      ${st === 'ok' ? `<div class="chk" style="margin-top:12px;border-color:var(--ok)">${icon('checkc')}<span>確認済みです。数量か単価が変わると、印は「変わりました」になります。</span></div>` : ''}`,
    foot: `${st ? '<button class="btn" id="bsOff">確認の印を外す</button>' : ''}<button class="btn" data-close>閉じる</button><button class="btn primary" id="bsOk">${icon('check')}${st === 'changed' ? 'この数量で確認し直す' : st === 'ok' ? '確認済み' : '確認済みにする'}</button>`
  });
  $('#bsOk', m.el).onclick = () => { l.ok = okMark(l, p.rooms, o, p.lines); touch(p); m.close(); after && after(); };
  const off = $('#bsOff', m.el); if (off) off.onclick = () => { delete l.ok; touch(p); m.close(); after && after(); };
}

/* 数量の出どころの札（図面から／手入力／図面＋手入力） */
function srcPill(S) {
  const cls = S.src === 'drawing' ? 'info' : S.src === 'mixed' ? 'acc' : '';
  return `<span class="pill ${cls} srcpill" title="数量の出どころ">${SOURCE_LABEL[S.src]}</span>`;
}
/* ④の数量の確認：出どころごとの行数と金額（金額は小計の内訳。足すと小計になる） */
function srcSum(p, o) {
  const t = totals(p, o), g = { drawing: [0, 0], manual: [0, 0], mixed: [0, 0] };
  p.lines.forEach((l, i) => { const k = lineSource(l, p.rooms, p.lines).src; g[k][0]++; g[k][1] += t.lines[i].amount; });
  const cell = k => g[k][0] ? `<span>${srcPill({ src: k })} ${g[k][0]} 行・${yen(g[k][1])}</span>` : '';
  return `<div class="row small" style="gap:12px;flex-wrap:wrap;margin-bottom:10px"><span class="muted">数量の出どころ</span>${cell('drawing')}${cell('mixed')}${cell('manual')}</div>`;
}

/* ---------- ④ 確認 ---------- */
function stepCheck({ p, body, refresh }) {
  const o = opts();
  const draw = () => {
    const c = check(p, o), t = totals(p, o);
    const errs = c.filter(x => x.level === 'error'), warns = c.filter(x => x.level === 'warn');
    const W = workChecks(p, o), wOn = W.filter(x => !x.off), wOff = W.filter(x => x.off);
    const oks = p.lines.map(l => okState(l, p.rooms, o, p.lines)), nOk = oks.filter(x => x === 'ok').length, chg = p.lines.filter((l, i) => oks[i] === 'changed');
    const wRow = x => `<div class="chk ${x.off ? '' : x.level === 'warn' ? 'warn' : 'tip'}" ${x.off ? 'style="opacity:.6"' : ''}>${icon(x.level === 'warn' ? 'alert' : 'info')}<span style="flex:1">${esc(x.msg)}</span>
      ${x.off ? `<button class="btn sm" data-won="${esc(x.key)}">戻す</button>` : `${x.key === 'waste' ? '<button class="btn sm primary" data-wfix="waste">処分の行を入れる</button>' : ''}<button class="btn sm" data-wgo="${x.step}" data-wid="${esc(x.lineId || x.roomId || '')}">見る</button><button class="btn sm" data-woff="${esc(x.key)}" title="この案件では要らない（一覧から外す）">要らない</button>`}</div>`;
    const mx = Math.max(1, ...Object.values(t.byKind).map(k => k.amount));
    const inp = (k, unit, w = 120) => `<div class="unitwrap" style="width:${w}px;display:inline-block"><input class="in num" style="min-height:40px" type="number" inputmode="decimal" data-k="${k}" value="${esc(p[k] ?? '')}" ${k === 'taxRate' ? `placeholder="${o.taxRate}"` : ''}><span>${unit}</span></div>`;
    body.innerHTML = `
      ${errs.length || warns.length ? '' : `<div class="okbig" style="margin-bottom:14px">${icon('shield')}<div><b style="font-size:17px">検算OK</b><div class="small muted">別の計算方法でも小計 ${yen(t.subtotal)} で一致しました。単価や数量の抜けもありません。</div></div></div>`}
      ${errs.length || warns.length ? `<div class="card" style="margin-bottom:14px"><h2>確認が必要な所</h2><div class="sub">赤：このままだと金額が間違います ／ 黄：念のため確かめてください</div>
        <div class="checks">${[...errs, ...warns].map(x => `<div class="chk ${x.level}">${icon(x.level === 'error' ? 'alert' : 'info')}<span style="flex:1">${esc(x.msg)}</span>${x.lineId || x.roomId ? `<button class="btn sm" data-fix="${esc(x.lineId || x.roomId)}" data-step="${x.lineId ? 3 : 2}">直す</button>` : ''}</div>`).join('')}</div></div>` : ''}
      <div class="card" style="margin-bottom:14px" id="workChk"><h2>入れ忘れのチェック</h2><div class="sub">工事の入れ忘れ・確かめ忘れを探します。金額は変わりません。黄：入れ忘れかもしれません ／ 青：工事の内容によっては要りません。要らない物は「要らない」で外せます。</div>
        ${wOn.length ? `<div class="checks">${wOn.map(wRow).join('')}</div>` : `<div class="row">${icon('checkc')}<b>気になる所はありません</b></div>`}
        ${wOff.length ? `<details class="more" style="margin-top:10px"><summary>「要らない」にした物（${wOff.length}）</summary><div class="checks" style="margin-top:8px">${wOff.map(wRow).join('')}</div></details>` : ''}</div>
      ${p.lines.length ? `<div class="card" style="margin-bottom:14px" id="okSum"><h2>数量の確認</h2><div class="sub">③工事の「数量の根拠・確認」で、行ごとに根拠を見て印を付けられます。印を付けた後で数量か単価が変わると、ここに出ます。</div>
        ${srcSum(p, o)}
        <div class="row"><span class="pill ${nOk === p.lines.length ? 'ok' : ''}">確認済み <b>${nOk}</b> ／ ${p.lines.length} 行</span>${chg.length ? `<span class="pill warn">確認の後で変わった ${chg.length} 行</span>` : ''}</div>
        ${chg.length ? `<div class="checks" style="margin-top:10px">${chg.map(l => `<div class="chk warn">${icon('alert')}<span style="flex:1">「${esc(l.name || '名前のない行')}」は、確認した時（${fmt(l.ok.qty, 3)}${esc(l.unit || '')} × ${yen(l.ok.price)}）から変わっています。</span><button class="btn sm" data-fix="${esc(l.id)}" data-step="3">見る</button></div>`).join('')}</div>` : ''}</div>` : ''}
      <div class="grid g2">
        <div class="card"><h2>金額</h2><div class="sub">諸経費と利益は小計に対する割合です</div>
          <table class="sum">
            <tr><td>小計（${p.lines.length} 行）</td><td>${yen(t.subtotal)}</td></tr>
            <tr><td>諸経費 ${inp('overheadPct', '%')}</td><td>${yen(t.overhead)}</td></tr>
            <tr><td>利益 ${inp('profitPct', '%')}</td><td>${yen(t.profit)}</td></tr>
            <tr><td>値引き ${inp('discount', '円', 140)}</td><td>${t.discount ? '−' + yen(t.discount) : yen(0)}</td></tr>
            <tr><td>税抜の合計</td><td>${yen(t.net)}</td></tr>
            <tr><td>消費税 ${inp('taxRate', '%', 120)}</td><td>${yen(t.tax)}</td></tr>
            <tr class="tot"><td>合計（税込）</td><td>${yen(t.grand)}</td></tr>
          </table></div>
        <div class="card"><h2>原価と粗利</h2><div class="sub">材料は定価×${o.matRate}%、手間は単価×${o.laborRate}%で計算（設定で変えられます）。見積書の金額は変わりません。</div>
          <div class="kindbars">${Object.entries(KINDS).map(([k, n]) => { const b = t.byKind[k]; return b.amount ? `<div class="kb"><span>${n}</span><div class="track" title="青：原価 ／ 緑：粗利"><i class="c" style="width:${b.cost / mx * 100}%"></i><i class="g" style="width:${Math.max(0, b.amount - b.cost) / mx * 100}%"></i></div><span class="num r" style="text-align:right">${yen(b.amount)}</span></div>` : ''; }).join('') || '<span class="muted small">まだ明細がありません</span>'}</div>
          <table class="sum" style="margin-top:12px">
            <tr><td>原価の合計</td><td>${yen(t.cost)}</td></tr>
            <tr><td>粗利（税抜の合計 − 原価）</td><td style="color:${t.gross < 0 ? 'var(--bad)' : 'var(--ok)'}">${yen(t.gross)}</td></tr>
            <tr><td>粗利率</td><td>${t.net > 0 ? pct(t.grossPct) : '—'}</td></tr>
          </table></div>
      </div>
      <p class="small muted" style="margin-top:12px">${icon('info').replace('<svg', '<svg style="width:14px;height:14px;vertical-align:-2px"')} この金額は概算です。検算は計算の間違いや入れ忘れを見つけるためのもので、現場に合っているかまでは確かめられません。見積書を出す前に、数量と単価をご自身で確かめてください。</p>`;
    refresh();
  };
  body.addEventListener('change', e => {
    const k = e.target.dataset.k; if (!k) return;
    p[k] = e.target.value === '' ? '' : Number(e.target.value); touch(p); draw();
  });
  body.addEventListener('click', e => {
    const wo = e.target.closest('[data-woff]'), wn = e.target.closest('[data-won]'), wg = e.target.closest('[data-wgo]');
    if (e.target.closest('[data-wfix=waste]')) { p.noWaste = {}; const k = syncWaste(p); touch(p); draw(); toast(k ? `廃材処分の行を ${k} 行入れました（解体の量から数えます）` : '入れられる行がありませんでした'); return; }
    if (wo) { (p.checksOff = p.checksOff || {})[wo.dataset.woff] = true; touch(p); draw(); return; }
    if (wn) { delete p.checksOff[wn.dataset.won]; touch(p); draw(); return; }
    if (wg) { if (+wg.dataset.wgo === 4) { const k = $('[data-k="overheadPct"]', body); if (k) { k.scrollIntoView({ block: 'center' }); k.focus(); } return; } lastFocus.id = wg.dataset.wid || null; go('#/p/' + encodeURIComponent(p.id) + '/' + wg.dataset.wgo); return; }
    const f = e.target.closest('[data-fix]'); if (!f) return;
    lastFocus.id = f.dataset.fix;
    go('#/p/' + encodeURIComponent(p.id) + '/' + f.dataset.step);
  });
  draw();
}

export async function duplicate(p) {
  await flush();
  const { id, number, ...rest } = JSON.parse(JSON.stringify(p));
  void id; void number;
  const n = newProject({ ...rest, name: (p.name || '案件') + '（コピー）', history: [], status: 'draft', issueDate: '', createdAt: Date.now() });
  go('#/p/' + encodeURIComponent(n.id) + '/1');
  toast('案件を複製しました');
}

/* 図面を JWW・DXF で書き出す。寸法で作った間取りは寸法と部屋名・面積も、読み込んだ図面は壁の線と部屋名・面積 */
async function cadExport(p) {
  const d = p.drawing; if (!d || !d.plan) return;
  let G;
  if (d.sketch && p.sketch && p.sketch.rooms.length) G = geomOf(p.sketch.rooms);
  else {
    G = { lines: d.plan.segs.map(s => [s[0], s[1], s[2], s[3], 0]), texts: [] };
    p.rooms.filter(r => r.src === 'plan').forEach(r => {
      const F = (r.faces || []).map(i => d.plan.faces.find(f => f.i === i)).filter(Boolean); if (!F.length) return;
      const P = F[0].poly; let cx = 0, cy = 0; P.forEach(q => { cx += q[0] / P.length; cy += q[1] / P.length; });
      G.texts.push({ s: r.name, x: cx, y: cy + 0.18, h: 4.5, deg: 0, layer: 2 }, { s: (Number(r.area) || 0).toFixed(2) + '㎡', x: cx, y: cy - 0.22, h: 3, deg: 0, layer: 2 });
    });
  }
  const base = (p.name || '間取り').replace(/[\\/:*?"<>|]/g, '_');
  const ch = await new Promise(res => {
    const m = modal({ title: 'JWW・DXF で書き出す', body: `<p class="small muted" style="margin:0">壁の線・寸法・部屋の名前と面積を書き出します（文字は Shift_JIS）。JWW は縮尺 1/50 です。</p>`,
      foot: `<button class="btn" data-fmt="dxf">DXF</button><button class="btn primary" data-fmt="jww">JWW</button>`, onClose: () => res('') });
    m.el.querySelectorAll('[data-fmt]').forEach(b => { b.onclick = () => { res(b.dataset.fmt); m.el.remove(); }; });
  });
  if (!ch) return;
  const u8 = ch === 'jww' ? jwwBytes(G, 50) : dxfBytes(G);
  await share(new Blob([u8], { type: ch === 'jww' ? 'application/octet-stream' : 'application/dxf' }), base + '.' + ch);
  toast(`${ch.toUpperCase()} を書き出しました`);
}

/* 前の読み取りでコンセントの位置が無い器具（前に読んだ図面・自分で足した器具）：背面の壁に沿って
 * 便器は真ん中から33cm横、洗面カウンターは端から20cm、壁から7cm（前のKAKUと同じ寸法。横は右・上の側） */
function outFallback(x) {
  if (!x.b || !x.back || !(x.t === 'toilet' || x.t === 'counter')) return null;
  const S = { N: [0, 1], S: [0, -1], E: [1, 0], W: [-1, 0] }[x.back]; if (!S) return null;
  const b = x.b, hor = !!S[1], wall = hor ? (S[1] > 0 ? b[3] : b[1]) : (S[0] > 0 ? b[2] : b[0]);
  const t = x.t === 'toilet' ? (hor ? (b[0] + b[2]) / 2 : (b[1] + b[3]) / 2) + 0.33 : (hor ? b[2] : b[3]) - 0.2;
  const r = v => Math.round(v * 1000) / 1000;
  return hor ? [r(t), r(wall - S[1] * 0.07)] : [r(wall - S[0] * 0.07), r(t)];
}
export { shownFixType };   // 手元の確かめ（種類の直しが正解に近づくか）で使う（typeFixMap はむぎの sw.53 で関数に export が付いた）
